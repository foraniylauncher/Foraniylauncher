var landing = implement("sind:external/superhero_landing");
var jarvis = implement("sind:external/jarvis");
var iron_man = implement("sind:external/iron_man_base");

function init(hero) {
    hero.setName("Iron Man/Mark 05 (V)");
    hero.setTier(6); 
    hero.setTierOverride(getTierOverride);

    hero.setChestplate("Briefcase");

    hero.addPowers("sind:mk5", "sind:jarvis");
    hero.addAttribute("PUNCH_DAMAGE", 5.5, 0);
    hero.addAttribute("WEAPON_DAMAGE", 1.0, 0);
    hero.addAttribute("FALL_RESISTANCE", 8.0, 0);

    hero.addKeyBind("AIM", "Repulsor Blast", 1);
    hero.addKeyBind("AIM_BRUH_C", "\u00A7eRight-Click \u00A77-\u00A7r Repulsor Blast", 1);
    hero.addKeyBind("CHARGED_BEAM", "Unibeam", 2);
    hero.addKeyBindFunc("func_JARVIS", jarvisKey, "Toggle JARVIS", 5);
    hero.addKeyBindFunc("func_MOBSCAN", mobScan, "Mob Scan", 2);

    hero.addKeyBind("TRANSFORM", "Transform", 3);

    hero.addKeyBind("DISABLE_PUNCH", "Disable Punch", -1);

    hero.setModifierEnabled(isModifierEnabled);
    hero.setHasProperty(hasProperty);
    hero.supplyFunction("canAim", canAim);
    hero.setKeyBindEnabled(isKeyBindEnabled);

    hero.addAttributeProfile("CASE", caseProfile);
    hero.addAttributeProfile("BRIEF", briefProfile);
    hero.addAttributeProfile("DONTMOVE", dontMoveProfile);
    hero.setAttributeProfile(getAttributeProfile);

    hero.addSoundEvent("MASK_OPEN", "fiskheroes:iron_man_mask_open");
    hero.addSoundEvent("MASK_CLOSE", "fiskheroes:iron_man_mask_close");
    hero.addSoundEvent("AIM_START", "fiskheroes:repulsor_charge");
    hero.addSoundEvent("AIM_STOP", "fiskheroes:repulsor_powerdown");
    hero.addSoundEvent("STEP", "sind:mk5walk");

    hero.setTickHandler((entity, manager) => {
        var flying = entity.getData("fiskheroes:flying");
        manager.incrementData(entity, "fiskheroes:dyn/booster_timer", 2, flying);

        var nbt = entity.getWornChestplate().nbt();

        var item = entity.getHeldItem();
        flying &= !entity.as("PLAYER").isUsingItem();
        manager.incrementData(entity, "fiskheroes:dyn/booster_r_timer", 2, flying && item.isEmpty() && !entity.isPunching() && entity.getData("fiskheroes:aiming_timer") == 0);
        manager.incrementData(entity, "fiskheroes:dyn/booster_l_timer", 2, flying && !item.doesNeedTwoHands());

        if (!entity.is("DISPLAY") && entity.is("PLAYER")) {
            if (entity.getData("sind:dyn/another_timer") == 1) {
                landing.tick(entity, manager);
            }
            jarvis.health(entity, manager, "jarvis");
            jarvis.lowhealth(entity, manager, "jarvis");
            jarvis.heatwarning(entity, manager, "jarvis");
            jarvis.timers(entity, manager);

            var between = (entity.getInterpolatedData("sind:dyn/another_timer") > 0 && entity.getInterpolatedData("sind:dyn/another_timer") < 1);
            manager.incrementData(entity, "sind:dyn/tentacles_timer", 5, between);

            if(!entity.getData("sind:dyn/another_boolean") || entity.getData("sind:dyn/another_timer") == 0) {
                if (entity.getData("sind:dyn/jarvis") && PackLoader.getSide() == "SERVER") {
                    entity.as("PLAYER").addChatMessage("\u00A73J.A.R.V.I.S>\u00A7b J.A.R.V.I.S O.S Offline.");
                }
                if (entity.getData("sind:dyn/jarvis")) {
                    manager.setByte(nbt, "jarvis_prev_on", 1);
                }
                manager.setData(entity, "sind:dyn/jarvis", false);
                manager.setInterpolatedData(entity, "sind:dyn/jarvis_timer", 0);
                manager.setData(entity, "sind:dyn/speaking", false);
                manager.setInterpolatedData(entity, "sind:dyn/speaking_timer", 0);
            }
            if (entity.getData("sind:dyn/another_boolean") && entity.getData("sind:dyn/another_timer") == 1 && nbt.hasKey("jarvis_prev_on")) {
                var message = "\u00A73J.A.R.V.I.S>\u00A7b J.A.R.V.I.S O.S Online.";
                if (PackLoader.getSide() == "SERVER") {
                    entity.as("PLAYER").addChatMessage(message);
                } else {
                    entity.playSound("sind:jarvison", 1.0, 1.0);
                }
                manager.removeTag(nbt, "jarvis_prev_on");
                manager.setData(entity, "sind:dyn/jarvis", true);
            }
        }
    });
}

function jarvisKey(player, manager) {
    iron_man.jarvisKey(player, manager);
    return true;
}

function mobScan(entity, manager) {
    iron_man.mobScan(entity, manager, "jarvis");
    return true;
}

function isModifierEnabled(entity, modifier) {
    var transform = entity.getData("sind:dyn/another_timer") == 1;
    var beamshooting = entity.getData("fiskheroes:beam_shooting_timer") > 0;
    switch (modifier.id()) {
        case "flight_normal":
            return !beamshooting && transform;
        case "flight_unibeam": 
            return beamshooting && transform;
    }
    switch (modifier.name()) {
        case "fiskheroes:water_breathing":
            return !entity.getData("fiskheroes:mask_open") && transform;
        case "fiskheroes:transformation":
            return true;
        default:
            return transform;
    }
}

function isKeyBindEnabled(entity, keyBind) {
    var transform = entity.getData("sind:dyn/another_timer") == 1;
    var between = (entity.getData("sind:dyn/another_timer") > 0 && entity.getData("sind:dyn/another_timer") < 1);
    switch (keyBind) {
        case "AIM":
            return (!entity.isInWater()) && canAim(entity) && !entity.getData("fiskheroes:beam_charging") && transform && !(entity.getData("fiskheroes:flying") && entity.isSprinting());
        case "AIM_BRUH_C":
            return entity.getData("fiskheroes:aiming") && (!entity.isInWater()) && canAim(entity) && !entity.getData("fiskheroes:beam_charging") && transform && !(entity.getData("fiskheroes:flying") && entity.isSprinting());
        case "CHARGED_BEAM":
            return (!entity.isInWater()) && !entity.isSneaking() && transform;
        case "func_JARVIS":
            return entity.isSneaking() && transform;
        case "func_MOBSCAN":
            return entity.isSneaking() && entity.getData("sind:dyn/mob_cooldown") == 0 && entity.getData("sind:dyn/jarvis") && transform;
        case "TRANSFORM":
            return entity.getData("sind:dyn/another_timer") == 0 || transform;
        case "DISABLE_PUNCH":
            return entity.getData("fiskheroes:beam_charging") || entity.getData("fiskheroes:aiming") || between;
        default:
            return true;
    }
}

function hasProperty(entity, property) {
    return property == "MASK_TOGGLE" && entity.getData("sind:dyn/another_timer") == 1;
}

function caseProfile(profile) {
    profile.revokeAugments();
    profile.addAttribute("BASE_SPEED", -10.0, 1);
    profile.addAttribute("SPRINT_SPEED", -1.0, 1);
    profile.addAttribute("JUMP_HEIGHT", -5.0, 0);
}

function briefProfile(profile) {
    profile.addAttribute("PUNCH_DAMAGE", 3.5, 0);
    profile.addAttribute("WEAPON_DAMAGE", 1.0, 0);
    profile.addAttribute("FALL_RESISTANCE", 8.0, 0);
}

function getAttributeProfile(entity) {
    if (entity.getData("sind:dyn/another_timer") == 0) {
        return "BRIEF";
    } else if (entity.getData("sind:dyn/another_timer") > 0 && entity.getData("sind:dyn/another_timer") < 1) {
        return "CASE";
    }

    return entity.getData("fiskheroes:beam_shooting_timer") > 0 ? "DONTMOVE" : null;
}

function canAim(entity) {
    return entity.getHeldItem().isEmpty();
}
function dontMoveProfile(profile) {
    profile.inheritDefaults();
    profile.addAttribute("BASE_SPEED", -10.0, 1);
    profile.addAttribute("SPRINT_SPEED", -1.0, 1);
    profile.addAttribute("JUMP_HEIGHT", -5.0, 0);
}

function getTierOverride(entity) {
    return entity.getData("sind:dyn/another_timer") == 1 ? 6 : 0;
}