var jarvis = implement("sind:external/jarvis");
var landing = implement("sind:external/superhero_landing");
var iron_man = implement("sind:external/iron_man_base");
var mk42 = implement("sind:external/mk42");

var helmet_list = ["helmet", "faceplate_flip", "faceplate_catch"];
var chest_list = ["chest_front", "chest_back", "chest_lower_back", "right_shoulder", "left_shoulder", "right_elbow", "left_elbow", "right_gauntlet", "left_gauntlet"];
var pants_list = ["pants_left", "pants_right"];
var boots_list = ["boots_left", "boots_right"];

function init(hero) {
    hero.setName("Iron Man/\u00A74\u00A76\u00A7lMark 42 \u00A74\u00A7l(XLII) \u00A7f\u00A7l- \u00A77\u00A7lProdigal Son");
    hero.setTier(7);

    hero.setHelmet("item.superhero_armor.piece.helmet");
    hero.setChestplate("item.superhero_armor.piece.chestplate");
    hero.setLeggings("item.superhero_armor.piece.leggings");
    hero.setBoots("item.superhero_armor.piece.boots");

    hero.addPowers("sind:mk42", "sind:jarvis", "sind:adv");
    hero.addAttribute("PUNCH_DAMAGE", 7.0, 0);
    hero.addAttribute("WEAPON_DAMAGE", 1.0, 0);
    hero.addAttribute("FALL_RESISTANCE", 8.0, 0);
    hero.addAttribute("BASE_SPEED", 0.05, 1);

    hero.addKeyBind("AIM", "Repulsor Blast", 1);
    hero.addKeyBind("AIM_BRUH_C", "\u00A7eRight-Click \u00A77-\u00A7r Repulsor Blast", 1);
    hero.addKeyBindFunc("func_MOBSCAN", mobScan, "Mob Scan", 2);
    hero.addKeyBind("CHARGED_BEAM", "Unibeam", 2);
    hero.addKeyBindFunc("func_JARVIS", jarvisKey, "Toggle JARVIS", 5);

    hero.addKeyBindFunc("CHEST", (entity, manager) => componentTransform(entity, manager, "chest"), "Summon Torso", 1);
    hero.addKeyBindFunc("HELMET", (entity, manager) => componentTransform(entity, manager, "helmet"), "Summon Helmet", 2);
    hero.addKeyBindFunc("PANTS", (entity, manager) => componentTransform(entity, manager, "pants"), "Summon Legs", 3);
    hero.addKeyBindFunc("BOOTS", (entity, manager) => componentTransform(entity, manager, "boots"), "Summon Boots", 4);
    hero.addKeyBindFunc("FULL", (entity, manager) => componentTransform(entity, manager, "full"), "Summon Full Suit", 5);

    hero.addKeyBind("SENTRY_MODE", "key.sentryMode", 3);

    hero.addKeyBind("FLARES", "Deploy Flares", 3);

    hero.addKeyBind("DISABLE_PUNCH", "Disable Punch", -1);

    hero.setModifierEnabled(isModifierEnabled);
    hero.setHasProperty(hasProperty);
    hero.supplyFunction("canAim", canAim);
    hero.setKeyBindEnabled(isKeyBindEnabled);

    hero.addAttributeProfile("SLOW", slowProfile);
    hero.addAttributeProfile("WEAK", weakProfile);
    hero.addAttributeProfile("SLOW_N_WEAK", slowWeakProfile);
    hero.addAttributeProfile("DONTMOVE", dontMoveProfile);
    hero.setAttributeProfile(getAttributeProfile);

    hero.addPrimaryEquipment("fiskheroes:mini_suit", false, item => item.nbt().getString("Suit") == "sind:tony");
    hero.addKeyBind("DETRANSFORM_TONY", "Recall Armor", 1);
    hero.addKeyBind("DAMAGED", "\u00A74Suit is too damaged to be removed", 1);

    var rocketArm = iron_man.createRocketArm(hero, 4, 8);
    hero.addPrimaryEquipment("fiskheroes:superhero_boots{HeroType:sind:42_4}", true, item => item.nbt().getString("HeroType") == "sind:42_4");
    hero.addPrimaryEquipment("fiskheroes:superhero_leggings{HeroType:sind:42_3}", true, item => item.nbt().getString("HeroType") == "sind:42_3");
    hero.addPrimaryEquipment("fiskheroes:superhero_chestplate{HeroType:sind:42_2}", true, item => item.nbt().getString("HeroType") == "sind:42_2");
    hero.addPrimaryEquipment("fiskheroes:superhero_helmet{HeroType:sind:42_1}", true, item => item.nbt().getString("HeroType") == "sind:42_1");

    hero.addSoundEvent("MASK_OPEN", "fiskheroes:iron_man_mask_open");
    hero.addSoundEvent("MASK_CLOSE", "fiskheroes:iron_man_mask_close");

    hero.addSoundEvent("AIM_START", "sind:repcharge");
    hero.addSoundEvent("AIM_STOP", "fiskheroes:repulsor_powerdown");
    hero.addSoundEvent("STEP", "sind:mk42walk");

    hero.setTierOverride(getTierOverride);
    hero.addDamageProfile("FLARES", {
        "types": {
            "ENERGY": 0.4,
            "EXPLOSION": 0.3,
            "FIRE": 0.3
        },
        "properties": {
            "EFFECTS": [
            {
              "id": "fiskheroes:flashbang",
              "duration": 40,
              "amplifier": 1
            },
            {
              "id": "minecraft:slowness",
              "duration": 40,
              "amplifier": 1
            }
        ]
        }
    });
    hero.setDamageProfile(entity => null);

    hero.setTickHandler((entity, manager) => {
        iron_man.easeToDetransform(entity, manager);
        
        var nbt = entity.getWornChestplate().nbt();
        mk42.parseStringData(entity, manager);
        mk42.checkAllArmorEquipments(entity, manager);
        mk42.incrementTimers(entity, manager);
        mk42.playSounds(entity, manager);

        if (entity.getEntityName() == "fiskheroes.IronMan") {
            manager.setByte(nbt, "sentry", 5);
            mk42.fullyTransform(entity, manager);
        } else if (nbt.getByte("sentry") > 0 && entity.is("PLAYER")) {
            mk42.fullyTransformWithNotify(entity, manager);
            manager.setByte(nbt, "sentry", nbt.getByte("sentry") - 1);
        }

        var flying = entity.getData("fiskheroes:flying");
        var chestTransformed = mk42.getDatasInList(entity, chest_list, 1);
        var bootsTransformed = mk42.getDatasInList(entity, boots_list, 1);

        manager.incrementData(entity, "fiskheroes:dyn/booster_timer", 2, (flying && entity.getData("sind:dyn/mark42_boots_right_timer") == 1 && entity.getData("sind:dyn/mark42_boots_left_timer") == 1) || (entity.getData("sind:dyn/mark42_faceplate_flip_timer") > 0.2 && entity.getData("sind:dyn/mark42_faceplate_flip_timer") < 0.5));
        manager.incrementData(entity, "sind:dyn/booster_timer2", 2, (flying && chestTransformed) || (entity.getData("sind:dyn/mark42_faceplate_flip_timer") > 0.2 && entity.getData("sind:dyn/mark42_faceplate_flip_timer") < 0.5));
        var item = entity.getHeldItem();
        flying &= !entity.as("PLAYER").isUsingItem();
        
        // from tony, idk man 
        manager.incrementData(entity, "sind:dyn/tony_to_suit", 10, false);

        manager.incrementData(entity, "fiskheroes:dyn/booster_r_timer", 2, entity.getData("sind:dyn/mark42_right_gauntlet_timer") == 1 && item.isEmpty() && (entity.getData("sind:dyn/mark42_initial_timer") < 0.05 || entity.getData("sind:dyn/mark42_initial_timer") > 0.95) && (entity.getData("sind:dyn/mark42_faceplate_catch_timer") < 0.16 || entity.getData("sind:dyn/mark42_faceplate_catch_timer") > 0.85) && ((flying && !entity.isPunching() && entity.getData("fiskheroes:aiming_timer") == 0) || (entity.getData("sind:dyn/mark42_faceplate_flip_timer") > 0.2 && entity.getData("sind:dyn/mark42_faceplate_flip_timer") < 0.5)));
        manager.incrementData(entity, "fiskheroes:dyn/booster_l_timer", 2, entity.getData("sind:dyn/mark42_left_gauntlet_timer") == 1 && !item.doesNeedTwoHands() && (entity.getData("sind:dyn/mark42_initial_timer") < 0.05 || entity.getData("sind:dyn/mark42_initial_timer") > 0.95) && (flying || (entity.getData("sind:dyn/mark42_faceplate_flip_timer") > 0.2 && entity.getData("sind:dyn/mark42_faceplate_flip_timer") < 0.5)) );
        manager.incrementData(entity, "sind:dyn/sentry_timer", 10, entity.getData("fiskheroes:suit_open"));

        manager.incrementData(entity, "sind:dyn/edith_timer", 5, chestTransformed);
        
        if (!entity.is("DISPLAY") && entity.is("PLAYER")) {
            if ((chestTransformed || bootsTransformed)) {
                landing.tick(entity, manager);
            } else {
                manager.incrementData(entity, "sind:dyn/superhero_landing_timer", 2, 8, false, true);
                var t = entity.getData("sind:dyn/superhero_landing_ticks");
                if (t > 0) {
                    manager.setData(entity, "sind:dyn/superhero_landing_ticks", --t);
                }
            }
            jarvis.health(entity, manager, "jarvis");
            jarvis.lowhealth(entity, manager, "jarvis");
            jarvis.heatwarning(entity, manager, "jarvis");
            jarvis.timers(entity, manager);
            
            //armrocket
            rocketArm.tick(entity, manager);
            //flares
            if (entity.getData("sind:dyn/flares")) {
                entity.world().getEntitiesInRangeOf(entity.pos(), 10).forEach(other => {
                    var isBehind = entity.getLookVector().subtract(180, 180, 180).dot(entity.pos().subtract(other.pos())) < 0.5;
                    if (isBehind && !entity.equals(other) && entity.isLivingEntity() && entity.world().isUnobstructed(entity.pos(), other.pos())) {
                        other.hurtByAttacker(hero, "FLARES", "%2$s grounded %1$s with flares", 2.0, entity);
                        if (PackLoader.getSide() == "SERVER" && other.isWearingFullSuit() && !other.as("PLAYER").isCreativeMode() && (other.getData("fiskheroes:flying"))) {
                            manager.setDataWithNotify(other, "fiskheroes:flying", false);
                        }
                    }
                });
            }
        }
        iron_man.fix42EquipmentIndex(entity, manager);

        //back flaps timers
        if (entity.getData("sind:dyn/flight_boost_timer") > 0.5) {
            manager.incrementData(entity, "sind:dyn/flight_boost_timer", 30, entity.getData("fiskheroes:flying") && entity.isSprinting());
        }
        else {
            manager.incrementData(entity, "sind:dyn/flight_boost_timer", 10, entity.getData("fiskheroes:flying") && entity.isSprinting());
        }
        iron_man.autoJarvisAfterSentry(entity, manager);
  });
}

function jarvisKey(player, manager) {
    iron_man.jarvisKey(player, manager);
    return true;
}

function mobScan(entity, manager) {
    iron_man.mobScan(entity, manager);
    return true;
}

function isModifierEnabled(entity, modifier) {
    var nbt = entity.getWornChestplate().nbt();
    var headTransformed = entity.getData("sind:dyn/mark42_helmet_timer") == 1 
        && (entity.getData("sind:dyn/mark42_faceplate_catch_timer") == 1 || entity.getData("sind:dyn/mark42_faceplate_flip_timer") == 1);
    var chestTransformed = mk42.getDatasInList(entity, chest_list, 1);
    var pantsTransformed = mk42.getDatasInList(entity, pants_list, 1);
    var bootsTransformed = mk42.getDatasInList(entity, boots_list, 1);
    var fullTransformed = headTransformed && chestTransformed && pantsTransformed && bootsTransformed;
    var transforming = entity.getData("sind:dyn/tentacles_timer") > 0;

    var beamshooting = entity.getData("fiskheroes:beam_shooting_timer") > 0;
    switch (modifier.id()) {
        case "flight_normal":
            return (!beamshooting && !transforming && (chestTransformed || bootsTransformed)) || entity.getEntityName() == "fiskheroes.IronMan";
        case "flight_unibeam": 
            return (beamshooting || transforming) && (chestTransformed || bootsTransformed);
        //armrocket
        case "tnt":
            return entity.getData("sind:dyn/armrockets_timer") == 1 && nbt.getByte("tnt_ammo") > 0;
        case "fc":
            return entity.getData("sind:dyn/armrockets_timer") == 1 && nbt.getByte("fc_ammo") > 0;
        case "gp":  
            return entity.getData("sind:dyn/armrockets_timer") == 1 && nbt.getByte("gp_ammo") > 0;
    }
    switch (modifier.name()) {
        case "fiskheroes:water_breathing":
            return !entity.getData("fiskheroes:mask_open") && headTransformed;
        case "fiskheroes:damage_immunity":
            return fullTransformed;
        case "fiskheroes:fire_immunity":
            return fullTransformed;
        case "fiskheroes:projectile_immunity":
            return fullTransformed;
        default:
            return true;
    }
}

function slowProfile(profile) {
    profile.inheritDefaults();
    profile.addAttribute("BASE_SPEED", -0.05, 1);
}

function weakProfile(profile) {
    profile.inheritDefaults();
    profile.addAttribute("PUNCH_DAMAGE", 0.0, 1);
    profile.addAttribute("WEAPON_DAMAGE", 0.0, 1);
}

function slowWeakProfile(profile) {
    profile.inheritDefaults();
    profile.addAttribute("BASE_SPEED", -0.05, 1);
    profile.addAttribute("PUNCH_DAMAGE", 0.0, 1);
    profile.addAttribute("WEAPON_DAMAGE", 0.0, 1);
}

function dontMoveProfile(profile) {
    profile.inheritDefaults();
    profile.addAttribute("BASE_SPEED", -10.0, 1);
    profile.addAttribute("SPRINT_SPEED", -1.0, 1);
    profile.addAttribute("JUMP_HEIGHT", -5.0, 0);
}

function getAttributeProfile(entity) {
    var chestTransformed = mk42.getDatasInList(entity, chest_list, 1);
    var pantsTransformed = mk42.getDatasInList(entity, pants_list, 1);
    var transforming = entity.getData("sind:dyn/tentacles_timer") > 0;
    
    if (entity.getData("fiskheroes:beam_shooting_timer") > 0 || entity.getData("sind:dyn/suit_to_tony") > 0 || transforming) {
        return "DONTMOVE";
    }
    if (!pantsTransformed && !chestTransformed) {
        return "SLOW_N_WEAK";
    }
    if (!pantsTransformed) {
        return "SLOW";
    }
    if (!chestTransformed) {
        return "WEAK";
    }
    return null;
}


function isKeyBindEnabled(entity, keyBind) {
    var jarvison = entity.getData("sind:dyn/jarvis")
    var headTransformed = entity.getData("sind:dyn/mark42_helmet_timer") == 1 
        && (entity.getData("sind:dyn/mark42_faceplate_catch_timer") == 1 || entity.getData("sind:dyn/mark42_faceplate_flip_timer") == 1);
    var chestTransformed = mk42.getDatasInList(entity, chest_list, 1);
    var pantsTransformed = mk42.getDatasInList(entity, pants_list, 1);
    var bootsTransformed = mk42.getDatasInList(entity, boots_list, 1);
    var fullTransformed = headTransformed && chestTransformed && pantsTransformed && bootsTransformed;
    var transforming = entity.getData("sind:dyn/tentacles_timer") > 0;

    var gpcount = getCount(entity, "minecraft:gunpowder");
    var tntcount = getCount(entity, "minecraft:tnt");
    var fccount = getCount(entity, "minecraft:fire_charge");
    var nbt = entity.getWornChestplate().nbt();

    var sneaking = entity.isSneaking();
    var hasMiniSuit = nbt.hasKey("Equipment") && iron_man.getIndex(nbt.getTagList("Equipment"), 0) ? iron_man.getIndex(nbt.getTagList("Equipment"), 0).getCompoundTag("Item").getShort("id") == PackLoader.getNumericalItemId("fiskheroes:mini_suit") : false;
    if (entity.getData("sind:dyn/ease") && keyBind != "DISABLE_PUNCH") {
        return false;
    }

    var gpammo = nbt.getByte("gp_ammo");
    var tntammo = nbt.getByte("tnt_ammo");
    var fcammo = nbt.getByte("fc_ammo");
    var aiming = entity.getData("fiskheroes:aiming");

    var flying = entity.getData("fiskheroes:flying");
    var beamcharging = entity.getData("fiskheroes:beam_charging");

    switch (keyBind) {
        case "CHARGED_BEAM":
            return !entity.isSneaking() && !entity.isInWater() && fullTransformed;
        case "AIM":
            return (hasMiniSuit ? !sneaking : true) && (!entity.getData("sind:dyn/armgun_bool") && !entity.isInWater()) && chestTransformed && !transforming && !entity.getData("fiskheroes:beam_charging") && canAim(entity);
        case "AIM_BRUH_C":
            return (hasMiniSuit ? !sneaking : true) && entity.getData("fiskheroes:aiming") && (!entity.getData("sind:dyn/armgun_bool") && !entity.isInWater()) && chestTransformed && !transforming && !entity.getData("fiskheroes:beam_charging") && canAim(entity);
        case "func_MOBSCAN":
            return entity.isSneaking() && entity.getData("sind:dyn/mob_cooldown") == 0 && jarvison && headTransformed && !transforming;
        case "SENTRY_MODE":
            return !entity.isInWater() && !(entity.isSprinting() && flying) && fullTransformed;
        case "AROCKET":
            return !aiming && !flying && (gpammo > 0 || tntammo > 0 || fcammo > 0) && fullTransformed && !beamcharging && canAim(entity);
        case "VISUAL_AROCKET":
            return entity.getData("sind:dyn/armgun_bool") && !aiming && !flying && (gpammo > 0 || tntammo > 0 || fcammo > 0) && fullTransformed && !beamcharging && canAim(entity);
        case "RELOADARMGP":
            return !aiming && gpcount > 0 && tntcount == 0 && fccount == 0 && gpammo == 0 && fcammo == 0 && tntammo == 0 && !flying && !beamcharging && fullTransformed && canAim(entity);
        case "RELOADARMFC":
            return !aiming && fccount > 0 && tntcount == 0 && gpammo == 0 && fcammo == 0 && tntammo == 0 && !flying && !beamcharging && fullTransformed && canAim(entity);
        case "RELOADARMTNT":
            return !aiming && tntcount > 0 && gpammo == 0 && fcammo == 0 && tntammo == 0 && !flying && !beamcharging && fullTransformed && canAim(entity);
        case "NORELOADARM":
            return !aiming && (gpcount == 0 && tntcount == 0 && fccount == 0) && (gpammo == 0 && tntammo == 0 && fcammo == 0) && !flying && !beamcharging && fullTransformed && canAim(entity);
        case "func_JARVIS":
            return headTransformed && entity.isSneaking();
        case "FLARES":
            return pantsTransformed && !transforming && flying && entity.isSprinting() && entity.getData("sind:dyn/flares_cooldown") == 0 && !entity.getData("sind:dyn/flares");
        case "BOOTS":
            return entity.getData("sind:dyn/modularint4") && !transforming && !bootsTransformed;
        case "PANTS":
            return entity.getData("sind:dyn/modularint3") && !transforming && !pantsTransformed;
        case "CHEST":
            return entity.getData("sind:dyn/modularint2") && !transforming && !chestTransformed;
        case "HELMET":
            return entity.getData("sind:dyn/modularint1") && !transforming && !headTransformed;
        case "FULL":
            return entity.getData("sind:dyn/modularint1") && entity.getData("sind:dyn/modularint2") && entity.getData("sind:dyn/modularint3") && entity.getData("sind:dyn/modularint4") && !transforming && !fullTransformed && !chestTransformed && !headTransformed && !pantsTransformed && !bootsTransformed;
        case "DISABLE_PUNCH":
            return (entity.getData("sind:dyn/ease") || entity.getData("sind:dyn/suit_to_tony") > 0 || aiming || beamcharging || entity.getData("sind:dyn/armgun_bool") || transforming);
        case "DETRANSFORM_TONY":
            return sneaking && hasMiniSuit && !iron_man.isTooDamaged(entity.getWornHelmet()) && !iron_man.isTooDamaged(entity.getWornChestplate()) && !iron_man.isTooDamaged(entity.getWornLeggings()) && !iron_man.isTooDamaged(entity.getWornBoots());
        case "DAMAGED":
            return sneaking && hasMiniSuit && (iron_man.isTooDamaged(entity.getWornHelmet()) || iron_man.isTooDamaged(entity.getWornChestplate()) || iron_man.isTooDamaged(entity.getWornLeggings()) || iron_man.isTooDamaged(entity.getWornBoots()));
        default:
            return true;
    }
}

function hasProperty(entity, property) {
    var headTransformed = entity.getData("sind:dyn/mark42_helmet_timer") == 1 
        && (entity.getData("sind:dyn/mark42_faceplate_catch_timer") == 1 || entity.getData("sind:dyn/mark42_faceplate_flip_timer") == 1);
    return (property == "MASK_TOGGLE" && headTransformed);
}

function canAim(entity) {
    return entity.getHeldItem().isEmpty();
}
function getTierOverride(entity) {
    var tier = 0;
    var headTransformed = entity.getData("sind:dyn/mark42_helmet_timer") == 1 
        && (entity.getData("sind:dyn/mark42_faceplate_catch_timer") == 1 || entity.getData("sind:dyn/mark42_faceplate_flip_timer") == 1);
    var chestTransformed = mk42.getDatasInList(entity, chest_list, 1);
    var pantsTransformed = mk42.getDatasInList(entity, pants_list, 1);
    var bootsTransformed = mk42.getDatasInList(entity, boots_list, 1);
    //add quarter of armor defense for each piece
    if (headTransformed) {
        tier += 7 / 4;
    }
    if (chestTransformed) {
        tier += 7 / 4;
    }
    if (pantsTransformed) {
        tier += 7 / 4;
    }
    if (bootsTransformed) {
        tier += 7 / 4;
    }
    //convert to integer
    return Math.floor(tier) | 0;
}
function getCount(entity, item) {
    return iron_man.getCount(entity, item);
}

function componentTransform(entity, manager, component) {
    if (PackLoader.getSide() != "SERVER") {
        return true;
    }
    var list;
    switch(component) {
        case "helmet":
            list = ["helmet"];
            break;
        case "chest":
            list = JSON.parse(JSON.stringify(chest_list));
            break;
        case "pants":
            list = JSON.parse(JSON.stringify(pants_list));
            break;
        case "boots":
            list = JSON.parse(JSON.stringify(boots_list));
            break;
        case "full":
            list = JSON.parse(JSON.stringify([].concat(chest_list, pants_list, boots_list, "helmet"))); //dont include faceplate anims
            break;
    }
    mk42.shuffle(list);
    
    if (component == "helmet") {
        if (entity.isOnGround() && entity.getData("sind:dyn/mark42_left_gauntlet_timer") == 1 && entity.getData("sind:dyn/mark42_right_gauntlet_timer") == 1 && entity.getData("sind:dyn/mark42_boots_right_timer") == 1 && entity.getData("sind:dyn/mark42_boots_left_timer") == 1) {
            list.push("faceplate_flip");
        } else {
            list.push("faceplate_catch");
        }
    } else if (component == "full") {
        manager.setDataWithNotify(entity, "sind:dyn/mark42_transforming_full", true);
        if (entity.isOnGround()) {
            list.push("faceplate_flip");
        } else {
            list.push("faceplate_catch");
        }
    }

    list.unshift("initial");
    manager.setDataWithNotify(entity, "sind:dyn/mark42_string_data", String(list));
    return true;
}