var gantry_suits = ["sind:mark2", "sind:mark3", "sind:mark4", "sind:mark6", "sind:warmachine_mk1",
    //alts
    "sind:mark3/gm", "sind:mark3/gold", "sind:mark3/rc", "sind:mark3/stealth",
    "sind:mark4/sp", "sind:mark4/v2", "sind:mark6/v2", "sind:mark6/sc",
    "sind:warmachine_mk1/r", "sind:warmachine_mk1/mm"
];

var tony_suits = ["sind:mark7", "sind:mark8", "sind:mark9", "sind:mark10", "sind:mark11", "sind:mark12", "sind:mark13",
    "sind:mark14", "sind:mark15", "sind:mark16", "sind:mark17", "sind:mark18", "sind:mark19", "sind:mark20", "sind:mark21",
    "sind:mark22", "sind:mark23", "sind:mark24", "sind:mark25", "sind:mark26", "sind:mark27", "sind:mark28", "sind:mark29",
    "sind:mark30", "sind:mark31", "sind:mark32", "sind:mark33", "sind:mark34", "sind:mark35", "sind:mark36", "sind:mark37",
    "sind:mark38", "sind:mark39", "sind:mark40", "sind:mark41", "sind:mark42", "sind:mark43", "sind:mark45", "sind:mark46",
    "sind:mark47", "sind:mark49", "sind:warmachine_mk2", "sind:warmachine_mk3", "sind:warmachine_mk4", "sind:warmachine_mk5", "sind:warmachine_mk6",
    "sind:ironlegiondrone",
    //alts
    "sind:mark7/sz", "sind:mark7/d100", "sind:mark7/bg", "sind:mark13/zd", "sind:mark22/c", 
    "sind:mark25/g", "sind:mark26/g", "sind:mark28/zd", "sind:mark32/zd", "sind:mark34/zd",
    "sind:mark37/concept", "sind:mark38/rg",
    "sind:mark40/h", "sind:mark41/retro", "sind:mark42/sdca", "sind:mark46/concept", "sind:mark46/ip", "sind:warmachine_mk2/r", "sind:warmachine_mk2/ip_r",
    "sind:warmachine_mk2/ip_r_blue", "sind:warmachine_mk2/ip", "sind:warmachine_mk2/aou",
    "sind:warmachine_mk3/r", "sind:warmachine_mk3/p", "sind:warmachine_mk3/h", "sind:warmachine_mk3/s",
    "sind:warmachine_mk4/r",
    "sind:warmachine_mk5/r", "sind:warmachine_mk5/wm",
    "sind:ironlegiondrone/r1", "sind:ironlegiondrone/r2", "sind:ironlegiondrone/r4", "sind:ironlegiondrone/r5",
    //mk1
    "sind:mark1", "sind:mark1/gold"
];

var tony_map = {
    "mark1": ["Mark 1", "O"],
    "mark7": ["Mark 7", "J"],
    "mark8": ["Mark 8", "J"],
    "mark9": ["Mark 9", "J"],
    "mark10": ["Mark 10", "J"],
    "mark11": ["Mark 11", "J"],
    "mark12": ["Mark 12", "J"],
    "mark13": ["Mark 13", "J"],
    "mark14": ["Mark 14", "J"],
    "mark15": ["Mark 15", "J"],
    "mark16": ["Mark 16", "J"],
    "mark17": ["Mark 17", "J"],
    "mark18": ["Mark 18", "J"],
    "mark19": ["Mark 19", "J"],
    "mark20": ["Mark 20", "J"],
    "mark21": ["Mark 21", "J"],
    "mark22": ["Mark 22", "J"],
    "mark23": ["Mark 23", "J"],
    "mark24": ["Mark 24", "J"],
    "mark25": ["Mark 25", "J"],
    "mark26": ["Mark 26", "J"],
    "mark27": ["Mark 27", "J"],
    "mark28": ["Mark 28", "J"],
    "mark29": ["Mark 29", "J"],
    "mark30": ["Mark 30", "J"],
    "mark31": ["Mark 31", "J"],
    "mark32": ["Mark 32", "J"],
    "mark33": ["Mark 33", "J"],
    "mark34": ["Mark 34", "J"],
    "mark35": ["Mark 35", "J"],
    "mark36": ["Mark 36", "J"],
    "mark37": ["Mark 37", "J"],
    "mark38": ["Mark 38", "J"],
    "mark39": ["Mark 39", "J"],
    "mark40": ["Mark 40", "J"],
    "mark41": ["Mark 41", "J"],
    "mark42": ["Mark 42", "J"],
    "mark43": ["Mark 43", "J"],
    "mark45": ["Mark 45", "F"],
    "mark46": ["Mark 46", "F"],
    "mark47": ["Mark 47", "F"],
    "mark49": ["Mark 49", "S"],
    "warmachine_mk2": ["War Machine Mark 2", "SG"],
    "warmachine_mk3": ["War Machine Mark 3", "SG"],
    "warmachine_mk4": ["War Machine Mark 4", "SG"],
    "warmachine_mk5": ["War Machine Mark 5", "SG"],
    "warmachine_mk6": ["War Machine Mark 6", "SG"],
    "ironlegiondrone": ["Iron Legion Drone", "S"],
}

var gantry_map = {
    "mark2": ["Mark 2", "J"],
    "mark3": ["Mark 3", "J"],
    "mark4": ["Mark 4", "J"],
    "mark6": ["Mark 6", "J"],
    "warmachine_mk1": ["War Machine Mark 1", "H"],
}

function init(hero, tier, sentry, advanced, rocket, laser, beams, friday, tony) {
    hero.setTier(tier);
    hero.setHelmet("item.superhero_armor.piece.helmet");
    hero.setChestplate("item.superhero_armor.piece.chestplate");
    hero.setLeggings("item.superhero_armor.piece.leggings");
    hero.setBoots("item.superhero_armor.piece.boots");

    hero.addAttributeProfile("DONTMOVE", dontMoveProfile);
    hero.setAttributeProfile(getAttributeProfile);
    hero.setModifierEnabled(isModifierEnabled);
    hero.setHasProperty(hasProperty);
    hero.supplyFunction("canAim", canAim);

    if (tony == "tony") {
        hero.addPrimaryEquipment("fiskheroes:mini_suit", false, item => item.nbt().getString("Suit") == "sind:tony");
        hero.addKeyBind("DETRANSFORM_TONY", "Recall Armor", 1);
    } else if (tony == "gantry") {
        hero.addPrimaryEquipment("fiskheroes:mini_suit", false, item => item.nbt().getString("Suit") == "sind:gantry");
        hero.addKeyBind("DETRANSFORM_GANTRY", "Disassemble Armor", 1);
        hero.addKeyBind("PISTON", "\u00A74Please stand on a 5x5 grid of pistons", 1);
    }
    hero.addKeyBind("DAMAGED", "\u00A74Suit is too damaged to be recalled", 1);
    
    hero.setKeyBindEnabled(isKeyBindEnabled);
    hero.addSoundEvent("MASK_OPEN", "fiskheroes:iron_man_mask_open");
    hero.addSoundEvent("MASK_CLOSE", "fiskheroes:iron_man_mask_close");

    hero.addSoundEvent("AIM_START", advanced ? "sind:repcharge" : "fiskheroes:repulsor_charge");
    hero.addSoundEvent("AIM_STOP", "fiskheroes:repulsor_powerdown");
    hero.addSoundEvent("STEP", "sind:iron_man_step");
    hero.addSoundOverrides("MK46", {
        "suit": {
            "MASK_OPEN": "fiskheroes:iron_man_mk46_mask_open",
            "MASK_CLOSE": "fiskheroes:iron_man_mk46_mask_close"
        }
    });
    if (beams == "beams"){
        hero.addKeyBind("AIM", "Repulsor Blast/Beams", 1);
        hero.addKeyBind("AIM_BRUH_C", "\u00A7eRight/Left-Click \u00A77-\u00A7r Repulsor Blast/Beams", 1);
    } else if (beams == "shield") {
        hero.addKeyBind("AIM", "Repulsor Blast/Shield", 1);
        hero.addKeyBind("AIM_BRUH_C", "\u00A7eRight/Left-Click \u00A77-\u00A7r Repulsor Blast/Shield", 1);
    } else if (beams == "sonic") {
        hero.addKeyBind("AIM", "Repulsor Blast/Sonic Repulsors", 1);
        hero.addKeyBind("AIM_BRUH_C", "\u00A7eRight/Left-Click \u00A77-\u00A7r Repulsor Blast/Sonic Repulsors", 1);
    } else {
        hero.addKeyBind("AIM", "Repulsor Blast", 1);
        hero.addKeyBind("AIM_BRUH_C", "\u00A7eRight-Click \u00A77-\u00A7r Repulsor Blast", 1);
    }

    hero.addKeyBind("CHARGED_BEAM", "Unibeam", 2);
    if (sentry) {
        hero.addKeyBind("SENTRY_MODE", "key.sentryMode", 3);
    }
    hero.addKeyBindFunc("func_MOBSCAN", mobScan, "Mob Scan", 2);
    if(friday) {
        hero.addKeyBindFunc("func_JARVIS", jarvisKey, "Toggle FRIDAY", 5);
    }else{
        hero.addKeyBindFunc("func_JARVIS", jarvisKey, "Toggle JARVIS", 5);
    }
    if (rocket == "CHEST") {
        hero.addKeyBind("SCROCKETS", "Fire Chest Torpedoes", 4);
    }
    else if (rocket != null || rocket != undefined) {
        var rocketName = rocket[0].toUpperCase() + rocket.slice(1).toLowerCase();
        hero.addKeyBind("SCROCKETS", "Fire " + rocketName + " Rockets", 4);
    }
    if (laser) {
        hero.addKeyBind("HEAT_VISION", "Arm Lasers", 5);
    }
    hero.addKeyBind("DISABLE_PUNCH", "Disable Punch", -1);

    hero.addDamageProfile("FLARES", {
        "types": {
            "ENERGY": 0.4,
            "EXPLOSION": 0.3,
            "FIRE": 0.3
        },
        "properties": {
            "EFFECTS": [
            {
              "id": "fiskheroes:flashbang",
              "duration": 40,
              "amplifier": 1
            },
            {
              "id": "minecraft:slowness",
              "duration": 40,
              "amplifier": 1
            }
        ]
        } 
    });
    hero.addDamageProfile("HASTE", {
        "properties": {
            "EFFECTS": [
            {
              "id": "minecraft:haste",
              "duration": 1200,
              "amplifier": 1
            }
        ]
        } 
    });
    hero.addDamageProfile("HASTE2", {
        "properties": {
            "EFFECTS": [
            {
              "id": "minecraft:haste",
              "duration": 1200,
              "amplifier": 2
            }
        ]
        } 
    });
    hero.setDamageProfile(entity => null);
}
function tick(entity, manager) {
    easeToDetransform(entity, manager);

    var suitType = entity.getWornChestplate().suitType().split("/")[0];
    var flying = entity.getData("fiskheroes:flying");
    manager.incrementData(entity, "fiskheroes:dyn/booster_timer", 2, flying);
    manager.incrementData(entity, "sind:dyn/sentry_timer", 10, entity.getData("fiskheroes:suit_open"));

    var item = entity.getHeldItem();
    flying &= !entity.as("PLAYER").isUsingItem();
    var mk45to47 = (suitType == "sind:mark45" || suitType == "sind:mark46" || suitType == "sind:mark47");
    var mk45or46or47 = mk45to47 && entity.getData("fiskheroes:aiming");
    var wm3 = suitType == "sind:warmachine_mk3";
    var quantum = entity.getData("sind:dyn/quantum_use");
    srockets(entity, manager);

    var mk2stupid = entity.getWornChestplate().suitType() == "sind:mark2/mft" ? (Math.min(1, 6*entity.getData("sind:dyn/jarvis_timer")) == 0 || Math.min(1, 6*entity.getData("sind:dyn/jarvis_timer")) == 1) : true;
    manager.incrementData(entity, "fiskheroes:dyn/booster_r_timer", 2, !quantum && flying && item.isEmpty() && mk2stupid && (suitType == "sind:mark6" ? entity.getData("sind:dyn/srockets_timer") == 0 : true) && (suitType == "sind:warmachine_mk4" && entity.getData("fiskheroes:utility_belt_type") == 0 ? true : !entity.isPunching()) && entity.getData("fiskheroes:shield_blocking_timer") == 0 && (((suitType == "sind:mark30" || suitType == "sind:mark33") && !entity.is("OWNABLE")) ? entity.getData("sind:dyn/punch_right_timer") == 0 : entity.getData("fiskheroes:aiming_timer") == 0) && !entity.getData("fiskheroes:heat_vision") && !entity.getData("sind:dyn/armgun_bool") && ((suitType == "sind:mark25" || suitType == "sind:mark26") ? (!entity.getData("sind:dyn/ground_smash") && !entity.getData("sind:dyn/ground_smash_use")) : true) && !entity.getData("sind:dyn/beam_charging2") && (suitType == "sind:mark35" ? !entity.getData("fiskheroes:telekinesis") : true) && (suitType == "sind:mark23" ? !entity.getData("fiskheroes:energy_projection") : true));
    manager.incrementData(entity, "fiskheroes:dyn/booster_l_timer", 2, !quantum && flying && !item.doesNeedTwoHands() && (suitType == "sind:mark6" ? entity.getData("sind:dyn/srockets_timer") == 0 : true) && ((entity.getData("fiskheroes:blade") || suitType == "sind:mark25" || suitType == "sind:mark26") ? !entity.isPunching() : true) && ((suitType == "sind:mark30" || suitType == "sind:mark33") ? entity.getData("sind:dyn/punch_left_timer") == 0 : true) && !entity.getData("sind:dyn/armgun_bool") && !entity.getData("sind:dyn/ground_smash") && !entity.getData("sind:dyn/ground_smash_use") && (mk45to47 ? true : !entity.getData("sind:dyn/beam_charging2")) && (suitType == "sind:mark34" ? !entity.getData("fiskheroes:telekinesis") : true) && (mk45or46or47 ? entity.getData("fiskheroes:energy_projection_timer") == 0 : true) && (suitType == "sind:mark23" ? !entity.getData("fiskheroes:energy_projection") : true));

    // from tony, idk man 
    manager.incrementData(entity, "sind:dyn/tony_to_suit", 10, false);
    
    //flight boost timer for backflap animation
    if (entity.getData("sind:dyn/flight_boost_timer") > 0.5) {
        manager.incrementData(entity, "sind:dyn/flight_boost_timer", 30, entity.getData("fiskheroes:flying") && entity.isSprinting());
    } else {
        manager.incrementData(entity, "sind:dyn/flight_boost_timer", 10, entity.getData("fiskheroes:flying") && entity.isSprinting());
    }
    //only for mk45+ dual beams
    manager.incrementData(entity, "sind:dyn/cluster_timer", 5, entity.getData("fiskheroes:energy_projection") && entity.getData("fiskheroes:aiming"));
    //punching with beams fix
    manager.incrementData(entity, "sind:dyn/fake_punch_timer", 0, 10, entity.getPunchTimer() > 0);

    autoJarvisAfterSentry(entity, manager);
}
function dualRepulsors(entity, manager) {
    // right click detection (based on shields) (original system credit to max and shadow)
    manager.setData(entity, "fiskheroes:shield", entity.getData("fiskheroes:aiming"));
    if (!entity.getData("fiskheroes:aiming") && entity.getData("fiskheroes:aiming_timer") > 0){
        manager.setData(entity, "sind:dyn/punch_decider", 0);
    }
    if (entity.getData("fiskheroes:shield_blocking") && PackLoader.getSide() == "SERVER" && entity.getData("sind:dyn/tentacles_timer") == 0) {
        manager.setDataWithNotify(entity, "sind:dyn/punch_left", true);
    }
    if (entity.getData("sind:dyn/tentacles_timer") >= 1) {
        if (entity.getData("fiskheroes:aiming")) {
            manager.setData(entity, "sind:dyn/punch_decider", (entity.getData("sind:dyn/punch_decider") + 1) % 3);
        }
        manager.setData(entity, "sind:dyn/punch_left", false);
    }
    manager.incrementData(entity, "sind:dyn/tentacles_timer", 15, entity.getData("sind:dyn/punch_left")); //half of repulsor cooldown
    manager.incrementData(entity, "sind:dyn/punch_right_timer", 5, entity.getData("fiskheroes:aiming") && (entity.getData("sind:dyn/punch_decider") == 0 || entity.getData("sind:dyn/punch_decider") == 2));
    manager.incrementData(entity, "sind:dyn/punch_left_timer", 5, entity.getData("fiskheroes:aiming") && (entity.getData("sind:dyn/punch_decider") == 1 || entity.getData("sind:dyn/punch_decider") == 2));
}
function icing(entity, manager) {
    if (entity.posY() > 200 && entity.getData("fiskheroes:flying")) {
        if (!entity.getData("sind:dyn/icing")) {
            entity.playSound("fiskheroes:modifier.cryocharge", 2, 1);
            if (entity.getData("sind:dyn/jarvis")) {
                var nbt = entity.getWornChestplate().nbt();
                manager.setByte(nbt, "jarvis_prev_on", 1);
            }
        }
        manager.setData(entity, "sind:dyn/icing", true);
        manager.setData(entity, "sind:dyn/jarvis", false);
        manager.setData(entity, "sind:dyn/speaking", false);
        manager.setInterpolatedData(entity, "sind:dyn/jarvis_timer", 0);
        manager.setInterpolatedData(entity, "sind:dyn/speaking_timer", 0);
    } else if (entity.posY() < 100) {
        manager.setData(entity, "sind:dyn/icing", false);
        var nbt = entity.getWornChestplate().nbt();
        var suitType = entity.getWornChestplate().suitType().split("/")[0];
        if (nbt.getByte("jarvis_prev_on") == 1) {
            manager.setData(entity, "sind:dyn/jarvis", true);
            manager.removeTag(nbt, "jarvis_prev_on");
            var message = suitType == "sind:warmachine_mk1" ? 
                "\u00A72HAMMER O.S>\u00A7c Systems Online." : 
                "\u00A73J.A.R.V.I.S>\u00A7b J.A.R.V.I.S O.S Online."
            if (PackLoader.getSide() == "SERVER") {
                entity.as("PLAYER").addChatMessage(message);
            } else {
                entity.playSound("sind:jarvison", 1.0, 1.0);
            }
        }
    }

    if (entity.getData("sind:dyn/icing") == true && entity.motionY() < 0.25) {
        manager.setData(entity, "sind:dyn/falling", entity.motionY())
    } else if (entity.isOnGround() || entity.getData("fiskheroes:flying")) {
        manager.setData(entity, "sind:dyn/falling", 0)
    }

    if (entity.motionY() < -2 && entity.getData("sind:dyn/icing") == false && (entity.posY() > 80 && entity.posY() < 90) && entity.isSprinting()) {
        manager.setData(entity, "fiskheroes:flying", true);
    }
}
function isModifierEnabled(entity, modifier) {
    var suitType = entity.getWornChestplate().suitType().split("/")[0];
    var speed = entity.getData("fiskheroes:speed");
    var speeding = entity.getData("fiskheroes:speeding");
    var beamcharging = entity.getData("fiskheroes:beam_charging");
    var nbt = entity.getWornChestplate().nbt();
    var beamshooting = entity.getData("fiskheroes:beam_shooting_timer") > 0;
    var mk45to47 = (suitType == "sind:mark45" || suitType == "sind:mark46" || suitType == "sind:mark47");
    var wm3 = suitType == "sind:warmachine_mk3";
    var aiming_timer = entity.getData("fiskheroes:aiming_timer");

    var enlarged = suitType == "sind:mark17" || suitType == "sind:mark18" || suitType == "sind:mark24" || suitType == "sind:mark29" || suitType == "sind:mark32";
    var smash = suitType == "sind:mark25" || suitType == "sind:mark26" || suitType == "sind:mark29";
    if (entity.getWornChestplate().suitType() == "sind:mark2/mft") {
        if (modifier.name() == "fiskheroes:projectile_immunity" || modifier.name() == "fiskheroes:fire_immunity" || modifier.name() == "fiskheroes:damage_immunity") {
            return false;
        }
    }
    switch (modifier.id()) {
        //mk30/33 dual repulsors
        case "single":
            return entity.getData("sind:dyn/punch_decider") != 2;
        case "dual": 
            return entity.getData("sind:dyn/punch_decider") == 2;
        //weird mk45/46 behaviorscanAim
        case "srockets": 
            return aiming_timer == 0;
        case "srockets2":
            return aiming_timer != 0;
        case "energy_proj":
            return aiming_timer != 0;
        case "heat_vis":
            return aiming_timer == 0;
        //armrocket
        case "tnt":
            return entity.getData("sind:dyn/armrockets_timer") == 1 && nbt.getByte("tnt_ammo") > 0;
        case "fc":
            return entity.getData("sind:dyn/armrockets_timer") == 1 && nbt.getByte("fc_ammo") > 0;
        case "gp":
            return entity.getData("sind:dyn/armrockets_timer") == 1 && nbt.getByte("gp_ammo") > 0;
        case "flight_normal": 
            return !entity.getData("sind:dyn/icing") && entity.getData("sind:dyn/icing_cooldown") == 0 && !beamshooting && entity.getData("fiskheroes:dyn/flight_super_boost") == 0;
        case "flight_unibeam":
            return !entity.getData("sind:dyn/icing") && entity.getData("sind:dyn/icing_cooldown") == 0 && beamshooting && entity.getData("fiskheroes:dyn/flight_super_boost") == 0;
        case "mach0":
            return !speeding && !beamshooting;
        case "mach1":
            return speed == 1 && speeding && !beamshooting;
        case "mach2":
            return speed == 2 && speeding && !beamshooting;
        case "mach3":
            return speed == 3 && speeding && !beamshooting;
        case "mach4":
            return speed == 4 && speeding && !beamshooting;
        case "mach5":
            return speed == 5 && speeding && !beamshooting;
        case "mach6":
            return speed == 6 && speeding && !beamshooting;
        case "mach7":
            return speed == 7 && speeding && !beamshooting && entity.getData("fiskheroes:dyn/flight_super_boost") == 0;
            //mk40
        case "normal":
            return entity.is("OWNABLE");
        case "rapid":
            return !entity.is("OWNABLE");
            //mk41
        case "standard":
            return entity.getData("sind:dyn/rep_timer") < 1;
        case "il":
            return entity.getData("sind:dyn/rep_timer") == 1;
        case "cb_standard":
            return entity.getData("sind:dyn/rep_timer") < 1;
        case "cb_il":
            return entity.getData("sind:dyn/rep_timer") == 1;
        case "explosion":
            return ((entity.getData("sind:dyn/ground_smash") && entity.getData("sind:dyn/ground_smash_timer") == 1) || entity.getData("sind:dyn/ground_smash_use"));
    }
    switch (modifier.name()) {
        case "fiskheroes:super_speed":
            return entity.getData("fiskheroes:flying");
        case "fiskheroes:invisibility":
            return (entity.getData("sind:dyn/camo") && !entity.getData("fiskheroes:aiming") && !beamcharging && entity.getPunchTimer() == 0 && (suitType == "sind:mark27" ? true : entity.getData("sind:dyn/night")) && entity.getData("sind:dyn/night_timer") == 1);
        case "fiskheroes:blade":
            return suitType != "sind:mark16" || entity.getData("sind:dyn/camo");
        case "fiskheroes:energy_projection":
            return suitType != "sind:mark23" || (entity.getData("sind:dyn/lava"));
        case "fiskheroes:web_swinging":
            return canAim(entity) && !beamcharging && !entity.getData("fiskheroes:aiming");
        case "fiskheroes:telekinesis":
            return !entity.getData("sind:dyn/pull");
        case "fiskheroes:repulsor_blast":
            return mk45to47 ? entity.getData("fiskheroes:energy_projection_timer") == 0 : enlarged ? entity.getData("fiskheroes:shield_blocking_timer") == 0 : wm3 ? entity.getData("sind:dyn/beam_charging_timer2") == 0: true;
        case "fiskheroes:shield":
            return (suitType == "sind:mark30" || suitType == "sind:mark33") ? entity.getData("fiskheroes:shield_blocking_timer") == 0 : true;
        default:
            return modifier.name() != "fiskheroes:water_breathing" || !entity.getData("fiskheroes:mask_open");
    }
}
function hasProperty(entity, property) {
    var suitType = entity.getWornChestplate().suitType().split("/")[0];
    if (suitType == "sind:mark27") {
        return property == "MASK_TOGGLE" && !entity.getData("sind:dyn/camo") || property == "BREATHE_SPACE" && !entity.getData("fiskheroes:mask_open");
    }
    return entity.getWornChestplate().suitType() != "sind:mark2/mft" && (property == "MASK_TOGGLE" && !entity.getData("sind:dyn/icing")) || (property == "BREATHE_SPACE" && !entity.getData("fiskheroes:mask_open") && (entity.getData("sind:dyn/space7") || suitType == "sind:mark39" || (suitType >= "sind:mark45" && suitType <= "sind:mark47") || (suitType >= "sind:warmachine_mk3" && suitType <= "sind:warmachine_mk6")));
}

function canAim(entity) {
    return entity.getHeldItem().isEmpty();
}
function dontMoveProfile(profile) {
    profile.inheritDefaults();
    profile.addAttribute("BASE_SPEED", -10.0, 1);
    profile.addAttribute("SPRINT_SPEED", -1.0, 1);
    profile.addAttribute("JUMP_HEIGHT", -5.0, 0);
}
function getAttributeProfile(entity) {
    return (entity.getData("fiskheroes:beam_shooting_timer") > 0 || entity.getData("sind:dyn/clamp_timer") >= 1) ? "DONTMOVE" : null;
}
function isKeyBindEnabled(entity, keyBind) {
    var armrocket = entity.getData("sind:dyn/armgun_bool");
    var energyprojection = entity.getData("fiskheroes:energy_projection");
    var heatvision = entity.getData("fiskheroes:heat_vision");
    var aiming = entity.getData("fiskheroes:aiming");
    var suitType = entity.getWornChestplate().suitType().split("/")[0];
    var fuel = entity.getData("sind:dyn/fuel");
    var icing = entity.getData("sind:dyn/icing");
    var flying = entity.getData("fiskheroes:flying");
    var sneaking = entity.isSneaking();
    var inWater = entity.isInWater();
    var beamcharging = entity.getData("fiskheroes:beam_charging");
    var notshielding = entity.getData("fiskheroes:shield_blocking_timer") == 0;

    var newArmRocket = suitType == "sind:mark7" || suitType == "sind:mark8" || suitType == "sind:mark9" || suitType == "sind:mark20" || suitType == "sind:mark21" || suitType == "sind:mark31";
    var wm1 = suitType == "sind:warmachine_mk1";
    var mk3or4 = suitType == "sind:mark3" || suitType == "sind:mark4";
    var early = suitType == "sind:mark2" || mk3or4 || suitType == "sind:mark5" || suitType == "sind:mark6" || wm1;

    var centurion = suitType == "sind:mark30" || suitType == "sind:mark33";
    var mk45to47 = suitType == "sind:mark45" || suitType == "sind:mark46" || suitType == "sind:mark47";
    var enlarged = suitType == "sind:mark17" || suitType == "sind:mark18" || suitType == "sind:mark24" || suitType == "sind:mark29" || suitType == "sind:mark32";

    var mk45or46or47 = mk45to47 && entity.getData("fiskheroes:aiming");
    var mk43 = suitType == "sind:mark43";

    var getHIV = (mk3or4 || mk43 || mk45or46or47) ? false : entity.getData("fiskheroes:heat_vision");

    var wm2 = suitType == "sind:warmachine_mk2";
    var wm3 = suitType == "sind:warmachine_mk3";
    var wm4 = suitType == "sind:warmachine_mk4";
    var wm5 = suitType == "sind:warmachine_mk5";
    var wm6 = suitType == "sind:warmachine_mk6";

    var gpcount = getCount(entity, "minecraft:gunpowder");
    var tntcount = getCount(entity, "minecraft:tnt");
    var fccount = getCount(entity, "minecraft:fire_charge");
    var nbt = entity.getWornChestplate().nbt();
    var gpammo = nbt.getByte("gp_ammo");
    var tntammo = nbt.getByte("tnt_ammo");
    var fcammo = nbt.getByte("fc_ammo");

    var hasWatch = suitType == "sind:mark46" && entity.getData("sind:dyn/watch");
    var hasMiniSuit = nbt.hasKey("Equipment") && getIndex(nbt.getTagList("Equipment"), 0) ? getIndex(nbt.getTagList("Equipment"), 0).getCompoundTag("Item").getShort("id") == PackLoader.getNumericalItemId("fiskheroes:mini_suit") : false;
    
    if (entity.getWornChestplate().suitType() == "sind:mark2/mft" && keyBind == "SHIELD") {
        return false;
    }

    if (entity.getData("sind:dyn/ease") && keyBind != "DISABLE_PUNCH") {
        return false;
    }

    switch (keyBind) {
        case "AIM":
            return (hasMiniSuit ? !sneaking : true) && (mk45to47 ? (!entity.getData("sind:dyn/beam_charging2") && !armrocket && canAim(entity) && !inWater && !beamcharging) : 
            ((enlarged || centurion) ? true : notshielding) && !entity.getData("fiskheroes:telekinesis") && (wm3 ? true : !entity.getData("sind:dyn/beam_charging2")) && !entity.getData("sind:dyn/ground_smash") && (mk3or4 ? true : !heatvision) && ((mk3or4 || suitType == "sind:mark23") ? !energyprojection : true) && !armrocket && canAim(entity) && !inWater && !beamcharging && !icing && entity.getData("fiskheroes:dyn/flight_super_boost") == 0 && (early ? !(entity.getData("fiskheroes:flying") && entity.isSprinting()) : true));
        case "AIM_BRUH_C":
            return (hasMiniSuit ? !sneaking : true) && aiming && (mk45to47 ? (!entity.getData("sind:dyn/beam_charging2") && !armrocket && canAim(entity) && !inWater && !beamcharging) : 
            ((enlarged || centurion) ? true : notshielding) && !entity.getData("fiskheroes:telekinesis") && (wm3 ? true : !entity.getData("sind:dyn/beam_charging2")) && !entity.getData("sind:dyn/ground_smash") && (mk3or4 ? true : !heatvision) && ((mk3or4 || suitType == "sind:mark23") ? !energyprojection : true) && !armrocket && canAim(entity) && !inWater && !beamcharging && !icing && entity.getData("fiskheroes:dyn/flight_super_boost") == 0 && (early ? !(entity.getData("fiskheroes:flying") && entity.isSprinting()) : true));
        case "AIM_BRUH":
            return (hasMiniSuit ? !sneaking : true) && (mk45to47 ? (!entity.getData("sind:dyn/beam_charging2") && !armrocket && canAim(entity) && !inWater && !beamcharging) : 
            ((enlarged || centurion) ? true : notshielding) && !entity.getData("fiskheroes:telekinesis") && (wm3 ? true : !entity.getData("sind:dyn/beam_charging2")) && !entity.getData("sind:dyn/ground_smash") && (mk3or4 ? true : !heatvision) && ((mk3or4 || suitType == "sind:mark23") ? !energyprojection : true) && !armrocket && canAim(entity) && !inWater && !beamcharging && !icing && entity.getData("fiskheroes:dyn/flight_super_boost") == 0 && (early ? !(entity.getData("fiskheroes:flying") && entity.isSprinting()) : true)) && hasWatch;
        case "AIM_BRUH_C_4":
            return (hasMiniSuit ? !sneaking : true) && aiming && ((mk45to47 ? (!entity.getData("sind:dyn/beam_charging2") && !armrocket && canAim(entity) && !inWater && !beamcharging) : 
            ((enlarged || centurion) ? true : notshielding) && !entity.getData("fiskheroes:telekinesis") && (wm3 ? true : !entity.getData("sind:dyn/beam_charging2")) && !entity.getData("sind:dyn/ground_smash") && (mk3or4 ? true : !heatvision) && ((mk3or4 || suitType == "sind:mark23") ? !energyprojection : true) && !armrocket && canAim(entity) && !inWater && !beamcharging && !icing && entity.getData("fiskheroes:dyn/flight_super_boost") == 0 && (early ? !(entity.getData("fiskheroes:flying") && entity.isSprinting()) : true)) && hasWatch);
        case "SONIC_SFX":
            return hasWatch && aiming;
        case "CHARGED_BEAM":
            return !inWater && !sneaking && !icing && entity.getData("fiskheroes:dyn/flight_super_boost") == 0;
        case "SENTRY_MODE":
            return (!entity.getData("sind:dyn/camo") && !inWater && !(entity.isSprinting() && flying)) && (wm6 ? (!sneaking && !entity.getData("sind:dyn/quantum")): true) && ((wm4 || wm5) ? (!entity.getData("sind:dyn/wmgun_bool") && !sneaking) : true);
        case "QUANTUM": 
            return sneaking || inWater || (entity.isSprinting() && flying);
        case "QUANTUM_TP":
            return entity.getData("fiskheroes:mask_open_timer2") == 0 && entity.getData("sind:dyn/quantum_timer") == 1 && !(sneaking || inWater || (entity.isSprinting() && flying));
        case "QUANTUMQUANTUM_TP":
            return entity.getData("fiskheroes:mask_open_timer2") == 0 && entity.getData("sind:dyn/quantum_timer") == 1 && !(sneaking || inWater || (entity.isSprinting() && flying)) && entity.world().getDimension() == 2594;
        case "func_JARVIS":
            return sneaking;
        //arm rocket
        case "AROCKET":
            return notshielding && (mk3or4 ? true : !heatvision) && ((mk3or4 || suitType == "sind:mark23") ? !energyprojection : true) && canAim(entity) && !sneaking && !aiming && !flying && !beamcharging && (gpammo > 0 || tntammo > 0 || fcammo > 0);
        case "VISUAL_AROCKET":
            return (wm1 ? entity.getData("sind:dyn/srockets") : entity.getData("sind:dyn/armgun_bool")) && notshielding && (mk3or4 ? true : !heatvision) && ((mk3or4 || suitType == "sind:mark23") ? !energyprojection : true) && canAim(entity) && !sneaking && !aiming && !flying && !beamcharging && (gpammo > 0 || tntammo > 0 || fcammo > 0);
        case "RELOADARMGP":
            return notshielding && (mk3or4 ? true : !heatvision) && ((mk3or4 || suitType == "sind:mark23") ? !energyprojection : true) && canAim(entity) && !sneaking && gpcount > 0 && tntcount == 0 && fccount == 0 && gpammo == 0 && fcammo == 0 && tntammo == 0 && !flying && !beamcharging && !aiming;
        case "RELOADARMFC":
            return notshielding && (mk3or4 ? true : !heatvision) && ((mk3or4 || suitType == "sind:mark23") ? !energyprojection : true) && canAim(entity) && !sneaking && fccount > 0 && tntcount == 0 && gpammo == 0 && fcammo == 0 && tntammo == 0 && !flying && !beamcharging && !aiming;
        case "RELOADARMTNT":
            return notshielding && (mk3or4 ? true : !heatvision) && ((mk3or4 || suitType == "sind:mark23") ? !energyprojection : true) && canAim(entity) && !sneaking && tntcount > 0 && gpammo == 0 && fcammo == 0 && tntammo == 0 && !flying && !beamcharging && !aiming;
        case "NORELOADARM":
            return notshielding && (mk3or4 ? true : !heatvision) && ((mk3or4 || suitType == "sind:mark23") ? !energyprojection : true) && canAim(entity) && !sneaking && (gpcount == 0 && tntcount == 0 && fccount == 0) && (gpammo == 0 && tntammo == 0 && fcammo == 0) && !flying && !beamcharging && !aiming;
        //arm shield
        case "SHIELD":
            return enlarged ? (aiming && entity.isOnGround()) : (!aiming && !armrocket && !inWater && !beamcharging && !icing && !energyprojection && !(flying && entity.isSprinting()));
        case "FLARES":
            return flying && entity.isSprinting() && entity.getData("sind:dyn/flares_cooldown") == 0 && !entity.getData("sind:dyn/flares");
        case "SCROCKETS":
            return !entity.getData("sind:dyn/srockets") && entity.getData("sind:dyn/srockets_cooldown") == 0 && ((suitType == "sind:mark45" || suitType == "sind:mark10" || suitType == "sind:mark11" || suitType == "sind:mark12" || suitType == "sind:mark13" || suitType == "sind:mark14" || suitType == "sind:mark19" || suitType == "sind:mark27" || suitType == "sind:mark28" || suitType == "sind:mark37") ? true : (flying || sneaking || beamcharging || aiming));
        case "func_MOBSCAN":
            return sneaking && entity.getData("sind:dyn/mob_cooldown") == 0 && entity.getData("sind:dyn/jarvis");
        case "HEAT_VISION":
            return mk45to47 ? (!aiming && canAim(entity) && !beamcharging && !sneaking && !armrocket && !inWater) :
            !aiming && !armrocket && ((suitType == "sind:mark6") ? (fuel < 1 && !entity.getData("sind:dyn/reloading") && !sneaking && !inWater && !(flying && entity.isSprinting()) && !beamcharging && canAim(entity))
                : (!sneaking && !inWater && !beamcharging && canAim(entity) && !(flying && suitType == "sind:mark31")));
        case "ENERGY_PROJECTION":
            return mk45to47 ? (entity.getData("sind:dyn/fake_punch_timer") == 0 && entity.getData("fiskheroes:aiming_timer") == 1) && !entity.getData("sind:dyn/watch") : 
                notshielding && !aiming && !armrocket && (mk3or4 ? ((entity.getData("sind:dyn/rep_cooldown") == 0 || (energyprojection && entity.getData("sind:dyn/rep_cooldown") < 1)) && canAim(entity) && !sneaking && !inWater && !flying && !beamcharging)
                : suitType == "sind:mark23" ? (entity.getData("sind:dyn/lava") && canAim(entity) && !sneaking && !inWater && !beamcharging)
                : (!inWater && canAim(entity)));
        //mk6
        case "RELOAD":
            return !aiming && !armrocket && fuel >= 1 && getCount(entity, "minecraft:redstone") > 0 && !sneaking;
        case "NORELOAD":
            return !aiming && !armrocket && fuel >= 1 && getCount(entity, "minecraft:redstone") == 0 && !sneaking;
        //speed suits
        case "SUPER_SPEED":
            return flying && !sneaking;
        //arm guns
        case "ARMGUN":
            return !entity.getData("sind:dyn/camo") && !aiming && canAim(entity) && entity.getData("sind:dyn/armgun_mag") < 1 && entity.getData("sind:dyn/armreloading") == false && !sneaking && !beamcharging && (wm1 ? !flying : true) && !icing && (wm2 ? !(entity.isSprinting() && flying) : true);
        case "func_RELOAD1":
            return !entity.getData("sind:dyn/camo") && !aiming && canAim(entity) && entity.getData("sind:dyn/armgun_mag") >= 1 && !sneaking && !icing && (wm2 ? !(entity.isSprinting() && flying) : true);
        case "BLADE":
            return canAim(entity) && (suitType == "sind:mark16" ? entity.getData("sind:dyn/camo") : true) && (centurion ? !(flying || sneaking || beamcharging || aiming) : true);
        //mk16/18 stealth
        case "INVIS":
            return (entity.getData("sind:dyn/camo") && !sneaking);
        //haste applier
        case "func_HAMMERS":
            return !entity.hasPotionEffect(3) && !entity.getData("sind:dyn/tentacles") && !sneaking;
        //ground smash
        case "GROUND_SMASH_VISUAL":
            return !beamcharging && canAim(entity) && !aiming;
        case "GROUND_SMASH":
            return !aiming && canAim(entity) && (entity.getPunchTimer() == 0 || entity.getData("sind:dyn/ground_smash")) && entity.getData("sind:dyn/ground_smash_cooldown") == 0 && entity.isOnGround() && !entity.getData("sind:dyn/beam_charging2");
        case "DISABLE_PUNCH":
            return (entity.getData("sind:dyn/ease") || entity.getData("sind:dyn/suit_to_tony") > 0 || entity.getData("sind:dyn/ground_smash") || entity.getData("sind:dyn/ground_smash_use") || aiming || beamcharging || entity.getData("sind:dyn/armgun_bool") || getHIV || ((mk3or4 || suitType == "sind:mark23") ? entity.getData("fiskheroes:energy_projection") : false) || (wm1 ? entity.getData("sind:dyn/srockets") : false) || (suitType == "sind:warmachine_mk4" ? entity.getData("fiskheroes:utility_belt_type") == 0 : false) || (suitType == "sind:mark36" ? entity.getData("sind:dyn/beam_charging2") : false));
        //claw
        case "TELEKINESIS":
            return !aiming && !beamcharging && canAim(entity) && (suitType == "sind:mark37" ? entity.getData("fiskheroes:web_swinging") && entity.isPunching(): true);
        case "GRAVITY_MANIPULATION":
            return !aiming && entity.getData("fiskheroes:telekinesis");
        //sonic repulsors
        case "FAKE_AIM":
            return (wm3 ? entity.getData("fiskheroes:aiming_timer") == 1: !aiming) && entity.getHeldItem().isEmpty() && !beamcharging && (mk45to47 ? (!inWater && !sneaking && !armrocket) : true);
        case "SONIC_WAVES":
            return entity.getHeldItem().isEmpty() && (
                suitType == "sind:mark46" ? (aiming && entity.getData("sind:dyn/watch")) : 
                entity.getData("sind:dyn/beam_charging_timer2") == 1 && (wm3 ? aiming : !aiming)); //last case is mk36
        //mk27 camo
        case "CAMO":
            return suitType == "sind:mark27" ? !sneaking : suitType == "sind:mark18" ? (!sneaking && !flying): true;
        //wm1
        case "GUN":
            return entity.getData("sind:dyn/wmgun_mag") < 1 && entity.getData("sind:dyn/wmreloading") == false && !icing;
        case "func_RELOAD":
            return entity.getData("sind:dyn/wmgun_mag") >= 1 && !icing;
        //mk37
        case "func_WEB_SWINGING":
            return canAim(entity) && !aiming && !beamcharging && !sneaking;
        case "UTILITY_BELT":
            return flying && entity.isSprinting();
        case "UTILITY_BELT_C":
            return flying && entity.isSprinting() && entity.getData("fiskheroes:utility_belt_type") == 0;
        case "func_SWAP":
            return !(flying && entity.isSprinting()) && (entity.getData("sind:dyn/wmgun_bool") || sneaking);
        //detransform stuff
        case "DETRANSFORM_GANTRY":
            return isOnPistonGrid(entity) && sneaking && hasMiniSuit && !isTooDamaged(entity.getWornHelmet()) && !isTooDamaged(entity.getWornChestplate()) && !isTooDamaged(entity.getWornLeggings()) && !isTooDamaged(entity.getWornBoots());
        case "PISTON":
            return !isOnPistonGrid(entity) && sneaking && hasMiniSuit && !isTooDamaged(entity.getWornHelmet()) && !isTooDamaged(entity.getWornChestplate()) && !isTooDamaged(entity.getWornLeggings()) && !isTooDamaged(entity.getWornBoots());
        case "DETRANSFORM_TONY":
            return sneaking && hasMiniSuit && !isTooDamaged(entity.getWornHelmet()) && !isTooDamaged(entity.getWornChestplate()) && !isTooDamaged(entity.getWornLeggings()) && !isTooDamaged(entity.getWornBoots());
        case "DAMAGED":
            return sneaking && hasMiniSuit && (isTooDamaged(entity.getWornHelmet()) || isTooDamaged(entity.getWornChestplate()) || isTooDamaged(entity.getWornLeggings()) || isTooDamaged(entity.getWornBoots()));
        default:
            return true;
    }

}
function jarvisKey(player, manager) {
    var jarvison = player.getData("sind:dyn/jarvis");
    var suitType = player.getWornChestplate().suitType().split("/")[0];
    var wm1 = suitType == "sind:warmachine_mk1";
    var wm2 = suitType == "sind:warmachine_mk2" || suitType == "sind:warmachine_mk3" || suitType == "sind:warmachine_mk4" || suitType == "sind:warmachine_mk5" || suitType == "sind:warmachine_mk6";
    var stark = suitType == "sind:mark49";
    var friday = suitType == "sind:mark45" || suitType == "sind:mark46" || suitType == "sind:mark47" || suitType == "sind:mark50" || suitType == "sind:mark80" || suitType == "sind:mark85" || suitType == "sind:mark100";
    var hulkbuster = suitType == "sind:mark44" || (suitType == "sind:mark43" && player.getData("sind:dyn/hulkbuster_timer") == 1);
    var hulkbusterstark = suitType == "sind:mark48";
    var hulkbuster100 = suitType == "sind:mark100hulkbuster";
    if (PackLoader.getSide() == "SERVER") {
        if (jarvison) {
            if (wm1) {
                player.addChatMessage("\u00A72HAMMER O.S>\u00A7c Systems Offline.");
            } else if (friday) {
                player.addChatMessage("\u00A73F.R.I.D.A.Y>\u00A7b F.R.I.D.A.Y O.S Offline.");
            } else if (hulkbuster) {
                player.addChatMessage("\u00A76J.A.R.V.I.S>\u00A7e J.A.R.V.I.S O.S Offline.");
            } else if (hulkbusterstark) {
                player.addChatMessage("\u00A76STARK O.S>\u00A7e STARK O.S Offline.");
            } else if (stark) {
                player.addChatMessage("\u00A73STARK O.S>\u00A7b STARK O.S Offline.");
            } else if (wm2) {
                player.addChatMessage("\u00A72STARK O.S>\u00A7c STARK O.S Offline.");
            } else if (hulkbuster100) {
                player.addChatMessage("\u00A76F.R.I.D.A.Y>\u00A7e F.R.I.D.A.Y O.S Offline.");
            } else {
                player.addChatMessage("\u00A73J.A.R.V.I.S>\u00A7b J.A.R.V.I.S O.S Offline.");
            }
        } else {
            if (wm1) {
                player.addChatMessage("\u00A72HAMMER O.S>\u00A7c Systems Online.");
            } else if (friday) {
                player.addChatMessage("\u00A73F.R.I.D.A.Y>\u00A7b F.R.I.D.A.Y O.S Online.");
            } else if (hulkbuster) {
                player.addChatMessage("\u00A76J.A.R.V.I.S>\u00A7e J.A.R.V.I.S O.S Online.");
            } else if (hulkbusterstark) {
                player.addChatMessage("\u00A76STARK O.S>\u00A7e STARK O.S Online.");
            } else if (wm2) {
                player.addChatMessage("\u00A72STARK O.S>\u00A7c STARK O.S Online.");
            } else if (stark) {
                player.addChatMessage("\u00A73STARK O.S>\u00A7b STARK O.S Online.");
            } else if (hulkbuster100) {
                player.addChatMessage("\u00A76F.R.I.D.A.Y>\u00A7e F.R.I.D.A.Y O.S Online.");
            } else {
                player.addChatMessage("\u00A73J.A.R.V.I.S>\u00A7b J.A.R.V.I.S O.S Online.");
            }
        }
    } else {
        if (jarvison) {
            player.playSound("sind:jarvisoff", 1.0, 1.0);
        } else {
            player.playSound("sind:jarvison", 1.0, 1.0);
        }
    }
    var nbt = player.getWornChestplate().nbt();
    if (!jarvison){
        manager.setByte(nbt, "jarvis_on", 1);
    } else if (nbt.hasKey("jarvis_on")) {
        manager.removeTag(nbt, "jarvis_on");
    }
    manager.setData(player, "sind:dyn/jarvis", !jarvison);
    return true;
}
function mobScan(entity, manager) {
    var suitType = entity.getWornChestplate().suitType().split("/")[0];
    var markNum = suitType.split("sind:mark")[1] == undefined ? -1 : parseInt(suitType.split("sind:mark")[1]);
    var range = markNum >= 45 ? 30 : markNum >= 33 ? 25 : markNum >= 18 ? 20 : 15;
    if (suitType == "sind:ironlegiondrone") {
        range = 25;
    } else if (suitType == "sind:warmachine_mk2") {
        range = 20;
    } else if (suitType == "sind:warmachine_mk3") {
        range = 25;
    } else if (suitType == "sind:warmachine_mk4" || suitType == "sind:warmachine_mk5" || suitType == "sind:warmachine_mk6") {
        range = 30;
    }
    var wm1 = suitType == "sind:warmachine_mk1";
    var wm2 = suitType == "sind:warmachine_mk2" || suitType == "sind:warmachine_mk3" || suitType == "sind:warmachine_mk4" || suitType == "sind:warmachine_mk5" || suitType == "sind:warmachine_mk6";
    var stark = suitType == "sind:mark49";
    var friday = suitType == "sind:mark45" || suitType == "sind:mark46" || suitType == "sind:mark47" || suitType == "sind:mark50" || suitType == "sind:mark80" || suitType == "sind:mark85" || suitType == "sind:mark100";
    var hulkbuster = suitType == "sind:mark44" || (suitType == "sind:mark43" && entity.getData("sind:dyn/hulkbuster_timer") == 1);
    var hulkbusterstark = suitType == "sind:mark48";
    var hulkbuster100 = suitType == "sind:mark100hulkbuster";
    if (suitType == "sind:tony") {
        mobscanner(entity, manager, "edith", range);
    } else if (wm1) {
        mobscanner(entity, manager, "wm", range);
    } else if (friday) {
        mobscanner(entity, manager, "friday", range);
    } else if (hulkbuster) {
        mobscanner(entity, manager, "hulkbuster", range);
    } else if (hulkbusterstark) {
        mobscanner(entity, manager, "stark_hulkbuster", range);
    } else if (stark) {
        mobscanner(entity, manager, "stark", range);
    } else if (wm2) {
        mobscanner(entity, manager, "stark_wm", range);
    } else if (hulkbuster100) {
        mobscanner(entity, manager, "hulkbuster100", range);
    } else {
        mobscanner(entity, manager, "jarvis", range);
    }
    return true;
}
function listEntities(entity, manager, range) {
    var list = [];
    var contained = entity.world().getEntitiesInRangeOf(entity.pos(), range);
    for (var i = 0; i < contained.size(); ++i) {
        var target = contained.get(i);
        var isNull = target.getName() == "unknown" || target.getEntityName() == null && !entity.is("PLAYER");
        if (entity.getUUID() !== target.getUUID() && !isNull && entity.isLivingEntity()) {
            list.push((target == 0 ? "" : " ") + target.getName());
        }
        if (target.getHealth() > 20) {
            manager.setData(entity, "sind:dyn/danger", true);
        }
    }
    return list;
}

function mobscanner(entity, manager, type, range) {
    var type = type == undefined ? "jarvis" : type;
    var range = range == undefined ? 15 : range;

    var targetsNames = listEntities(entity, manager, range);

    if (type == "jarvis" || type == null) {
        var message1 = encode("J.A.R.V.I.S> ", "\u00A73") + encode("In a " + range + " block radius, the entities nearby are:", "\u00A7b");
        var message2 = encode("J.A.R.V.I.S>", "\u00A73") + encode(String(targetsNames), "\u00A7b");
    }
    else if (type == "friday") {
        var message1 = encode("F.R.I.D.A.Y> ", "\u00A73") + encode("Entities detected within " + range + " blocks include:", "\u00A7b");
        var message2 = encode("F.R.I.D.A.Y>", "\u00A73") + encode(String(targetsNames), "\u00A7b");
    }
    else if (type == "hulkbuster") {
        var message1 = encode("J.A.R.V.I.S> ", "\u00A76") + encode("In a " + range + " block radius, the entities nearby are:", "\u00A7e");
        var message2 = encode("J.A.R.V.I.S>", "\u00A76") + encode(String(targetsNames), "\u00A7e");
    }
    else if (type == "stark_hulkbuster") {
        var message1 = encode("STARK O.S> ", "\u00A76") + encode("In a " + range + " block radius, the entities nearby are:", "\u00A7e");
        var message2 = encode("STARK O.S>", "\u00A76") + encode(String(targetsNames), "\u00A7e");
    }
    else if (type == "stark") {
        var message1 = encode("STARK O.S> ", "\u00A73") + encode("In a " + range + " block radius, the entities nearby are:", "\u00A7b");
        var message2 = encode("STARK O.S>", "\u00A73") + encode(String(targetsNames), "\u00A7b");
    }
    else if (type == "stark_wm") {
        var message1 = encode("STARK O.S> ", "\u00A72") + encode("In a " + range + " block radius, the entities nearby are:", "\u00A7c");
        var message2 = encode("STARK O.S>", "\u00A72") + encode(String(targetsNames), "\u00A7c");
    }
    else if (type == "wm") {
        var message1 = encode("HAMMER O.S> ", "\u00A72") + encode("Perimeter secured. Nearby threats include:", "\u00A7c");
        var message2 = encode("HAMMER O.S>", "\u00A72") + encode(String(targetsNames), "\u00A74");
    }
    else if (type == "edith") {
        var message1 = encode("E.D.I.T.H> ", "\u00A73") + encode("In a " + range + " block radius, the entities nearby are:", "\u00A7b");
        var message2 = encode("E.D.I.T.H>", "\u00A73") + encode(String(targetsNames), "\u00A7b");
    }
    else if (type == "hulkbuster100") {
        var message1 = encode("F.R.I.D.A.Y> ", "\u00A76") + encode("In a " + range + " block radius, the entities nearby are:", "\u00A7e");
        var message2 = encode("F.R.I.D.A.Y>", "\u00A76") + encode(String(targetsNames), "\u00A7e");
    }

    if (PackLoader.getSide() == "CLIENT") {
        entity.playSound("sind:radar", 4, 1);
    }
    manager.setInterpolatedData(entity, "sind:dyn/mob_cooldown", 1);
    manager.setData(entity, "sind:dyn/mobscan", false);
    
    if (targetsNames.length > 0) {
        if (PackLoader.getSide() == "SERVER") {
            entity.as("PLAYER").addChatMessage(message1);
            entity.as("PLAYER").addChatMessage(message2);
        } else if (PackLoader.getSide() == "CLIENT") {
            entity.playSound("minecraft:random.orb", 4, 1);
        }
        if(!entity.getData("sind:dyn/speaking")){
            manager.setData(entity, "sind:dyn/speaking", true);
        }
    }
}
function getCount(entity, item) {
    var nbt = entity.getWornChestplate().nbt();
    var getItem = (tag, item3) => {
        return nbt.getTagList("Equipment").getCompoundTag(tag).getCompoundTag("Item").getShort("id") == PackLoader.getNumericalItemId(item3);
    }
    var count = 0;
    var slots = 5; // 0: tony, 1: gp, 2: fc, 3: tnt, 4: redstone
    for (var i = 0; i < slots; i++) {
        var item2 = nbt.getTagList("Equipment").getCompoundTag(i).getCompoundTag("Item");
        if (getItem(i, item)) {
            count += item2.getByte("Count");
        }
    }
    return count;
}

function createRocketArm(hero, keybind, slots) {
    hero.addKeyBind("AROCKET", "Arm Rocket", keybind);
    hero.addKeyBind("VISUAL_AROCKET", "\u00A7eRight-Click \u00A77-\u00A7r Arm Rocket", keybind);
    hero.addKeyBindFunc("RELOADARMGP", (player, manager) => reloadArm(player, manager, slots), "Reload Arm Rocket (Gunpowder)", keybind);
    hero.addKeyBindFunc("RELOADARMFC", (player, manager) => reloadArm(player, manager, slots), "Reload Arm Rocket (Firecharge)", keybind);
    hero.addKeyBindFunc("RELOADARMTNT", (player, manager) => reloadArm(player, manager, slots), "Reload Arm Rocket (TNT)", keybind);
    hero.addKeyBind("NORELOADARM", "\u00A7mReload Arm Rocket", keybind);

    hero.addPrimaryEquipment("minecraft:gunpowder", false);
    hero.addPrimaryEquipment("minecraft:fire_charge", false);
    hero.addPrimaryEquipment("minecraft:tnt", false);
    return {
        tick: (entity, manager) => {
            var nbt = entity.getWornChestplate().nbt();
            manager.incrementData(entity, "sind:dyn/armrockets_timer", 25, entity.getData("sind:dyn/armgun_bool"));
            if (entity.getData("sind:dyn/armrockets_timer") >= 1 && entity.isPunching() && entity.getPunchTimer() == 0) {
                entity.playSound("sind:armrocket_shoot", 5, 1);
                if (PackLoader.getSide() == "SERVER") {
                    manager.setDataWithNotify(entity, "sind:dyn/armrockets_timer", 0);
                    if (nbt.getByte("tnt_ammo") > 0) {
                        manager.setByte(nbt, "tnt_ammo", nbt.getByte("tnt_ammo") - 1);
                    } else if (nbt.getByte("fc_ammo") > 0) {
                        manager.setByte(nbt, "fc_ammo", nbt.getByte("fc_ammo") - 1);
                    } else if (nbt.getByte("gp_ammo") > 0) {
                        manager.setByte(nbt, "gp_ammo", nbt.getByte("gp_ammo") - 1);
                    }
                }
            }

        }
    };
}

function reloadArm(player, manager, slots) {
    var nbt = player.getWornChestplate().nbt();
    var reloaded = false;
    var getItem = (tag, item) => {
        return nbt.getTagList("Equipment").getCompoundTag(tag).getCompoundTag("Item").getShort("id") == PackLoader.getNumericalItemId(item);
    }
    //tnt
    for (var i = 0; i < slots; i++) {
        if (!reloaded) {
            var item = nbt.getTagList("Equipment").getCompoundTag(i).getCompoundTag("Item");
            if (getItem(i, "minecraft:tnt")) {
                if (item.getByte("Count") == 1) {
                    manager.removeTag(nbt.getTagList("Equipment"), i);
                    manager.setByte(nbt, "tnt_ammo", 2);
                    var reloaded = true;
                    player.playSound("minecraft:random.fizz", 4, 1);
                } else if (item.getByte("Count") > 0) {
                    manager.setByte(item, "Count", item.getByte("Count") - 1);
                    manager.setByte(nbt, "tnt_ammo", 2);
                    var reloaded = true;
                    player.playSound("minecraft:random.fizz", 4, 1);
                }
            }
        }
    }
    //fire charge
    if (!reloaded) {
        for (var i = 0; i < slots; i++) {
            if (!reloaded) {
                var item = nbt.getTagList("Equipment").getCompoundTag(i).getCompoundTag("Item");
                if (getItem(i, "minecraft:fire_charge")) {
                    if (item.getByte("Count") == 1) {
                        manager.removeTag(nbt.getTagList("Equipment"), i);
                        manager.setByte(nbt, "fc_ammo", 2);
                        var reloaded = true;
                        player.playSound("minecraft:random.fizz", 4, 1);
                    } else if (item.getByte("Count") > 0) {
                        manager.setByte(item, "Count", item.getByte("Count") - 1);
                        manager.setByte(nbt, "fc_ammo", 2);
                        var reloaded = true;
                        player.playSound("minecraft:random.fizz", 4, 1);
                    }
                }
            }
        }
    }
    //gunpowder
    if (!reloaded) {
        for (var i = 0; i < slots; i++) {
            if (!reloaded) {
                var item = nbt.getTagList("Equipment").getCompoundTag(i).getCompoundTag("Item");
                if (getItem(i, "minecraft:gunpowder")) {
                    if (item.getByte("Count") == 1) {
                        manager.removeTag(nbt.getTagList("Equipment"), i);
                        manager.setByte(nbt, "gp_ammo", 2);
                        var reloaded = true;
                        player.playSound("minecraft:random.fizz", 4, 1);
                    } else if (item.getByte("Count") > 0) {
                        manager.setByte(item, "Count", item.getByte("Count") - 1);
                        manager.setByte(nbt, "gp_ammo", 2);
                        var reloaded = true;
                        player.playSound("minecraft:random.fizz", 4, 1);
                    }
                }
            }
        }
    }
    return true;
};
function flares(entity, manager, hero){
    if (entity.getData("sind:dyn/flares")) {
    entity.world().getEntitiesInRangeOf(entity.pos(), 10).forEach(other => {
            var isBehind = entity.getLookVector().subtract(180, 180, 180).dot(entity.pos().subtract(other.pos())) < 0.5;  
            if (isBehind && !entity.equals(other) && entity.isLivingEntity() && entity.world().isUnobstructed(entity.pos(), other.pos())) {
                other.hurtByAttacker(hero, "FLARES", "%2$s grounded %1$s with flares", 2.0, entity);
                if (PackLoader.getSide() == "SERVER" && other.isWearingFullSuit() && !other.as("PLAYER").isCreativeMode() && (other.getData("fiskheroes:flying"))) {
                    manager.setDataWithNotify(other, "fiskheroes:flying", false);
                }
            }
        });
    }
}

function srockets(entity, manager) {
    var suitType = entity.getWornChestplate().suitType().split("/")[0];
    var mk45to47 = (suitType == "sind:mark45" || suitType == "sind:mark46" || suitType == "sind:mark47");
    var mk45or46or47 = mk45to47 && entity.getData("fiskheroes:aiming");
    var mk3or4 = suitType == "sind:mark3" || suitType == "sind:mark4";
    var mk43 = suitType == "sind:mark43";
    var getBeam = (mk3or4 || mk43 || mk45or46or47) ? "fiskheroes:heat_vision" : "fiskheroes:energy_projection";
    if (entity.getData("sind:dyn/srockets_cooldown") == 1) {
        manager.setData(entity, "sind:dyn/srockets_tog", true);
    }
    if (entity.getData("sind:dyn/srockets_cooldown") == 0) {
        manager.setData(entity, "sind:dyn/srockets_tog", false);
    }
    if ((entity.getData("sind:dyn/srockets_cooldown") > 0.45 && entity.getData("sind:dyn/srockets_cooldown") < 0.5) && entity.getData("sind:dyn/srockets_tog") == false) {
        manager.setData(entity, getBeam, true);
        entity.playSound("sind:rocket", 10, 1);
        manager.setInterpolatedData(entity, getBeam+"_timer", 1);
    } else if ((entity.getData("sind:dyn/srockets_cooldown") > 0.54 && entity.getData("sind:dyn/srockets_cooldown") < 0.59) && entity.getData("sind:dyn/srockets_tog") == false) {
        manager.setData(entity, getBeam, true);
        entity.playSound("sind:rocket", 10, 1);
        manager.setInterpolatedData(entity, getBeam+"_timer", 1);
    } else if ((entity.getData("sind:dyn/srockets_cooldown") > 0.62 && entity.getData("sind:dyn/srockets_cooldown") < 0.67) && entity.getData("sind:dyn/srockets_tog") == false) {
        manager.setData(entity, getBeam, true);
        manager.setInterpolatedData(entity, getBeam+"_timer", 1);
        entity.playSound("sind:rocket", 10, 1);
    } else if (suitType != "sind:mark23") {
        manager.setData(entity, getBeam, false);
        manager.setInterpolatedData(entity, getBeam+"_timer", 0);
    }
}

function groundsmash(entity, manager) {
    // ground smash (original code credit to shadow)
    manager.incrementData(entity, "sind:dyn/ground_smash_use_timer", 10, entity.getData("sind:dyn/ground_smash_use"));

    if (entity.getData("sind:dyn/ground_smash_use_timer") == 1) {
        manager.setData(entity, "sind:dyn/ground_smash_cooldown", 40);
    }

    if (entity.getData("sind:dyn/ground_smash_cooldown") > 0) {
        manager.setData(entity, "sind:dyn/ground_smash_cooldown", entity.getData("sind:dyn/ground_smash_cooldown") - 1);
    }

    if (!entity.getData("sind:dyn/ground_smash_use") && entity.getData("sind:dyn/ground_smash") && entity.getPunchTimer() > 0) {
        manager.setData(entity, "sind:dyn/ground_smash_use", true);
    }
    if (entity.getData("sind:dyn/ground_smash_use") && entity.getData("sind:dyn/ground_smash_use_timer") == 1) {
        manager.setData(entity, "sind:dyn/ground_smash_use", false);
    }
}
function earthquake(entity, manager) {
    //earthquake
    manager.incrementData(entity, "sind:dyn/earthquake_use_timer", 10, entity.getData("sind:dyn/earthquake_use"));

    if (entity.getData("sind:dyn/earthquake_use_timer") == 1) {
        manager.setData(entity, "sind:dyn/earthquake_cooldown", 40);
    }

    if (entity.getData("sind:dyn/earthquake_cooldown") > 0) {
        manager.setData(entity, "sind:dyn/earthquake_cooldown", entity.getData("sind:dyn/earthquake_cooldown") - 1);
    }

    if (!entity.getData("sind:dyn/earthquake_use") && entity.getData("sind:dyn/earthquake") && entity.getPunchTimer() > 0) {
        manager.setData(entity, "sind:dyn/earthquake_use", true);
    }
    if (entity.getData("sind:dyn/earthquake_use") && entity.getData("sind:dyn/earthquake_use_timer") == 1) {
        manager.setData(entity, "sind:dyn/earthquake_use", false);
    }
}

function stealth(entity, manager) {
    if (entity.isPunching() || entity.getData("fiskheroes:aiming") || entity.getData("fiskheroes:beam_charging") || entity.getData("sind:dyn/srockets") || entity.getData("fiskheroes:mask_open") || entity.getData("sind:dyn/flares")) {
        manager.setData(entity, "sind:dyn/night", false);
        manager.setData(entity, "sind:dyn/night_timer", 0);
    }
    if (entity.getData("sind:dyn/night_timer") >= 1 && !entity.getData("fiskheroes:invisible")) {
        manager.setData(entity, "fiskheroes:invisible", true);
        manager.setInterpolatedData(entity, "fiskheroes:invisibility_timer", 1);
    }
    if (entity.getData("fiskheroes:invisible") && entity.getData("sind:dyn/night_timer") < 1) {
        manager.setData(entity, "fiskheroes:invisible", false);
        manager.setInterpolatedData(entity, "fiskheroes:invisibility_timer", 0);
    }
}

function feetClamp(entity, manager) {
    var nbt = entity.getWornChestplate().nbt();
    manager.incrementData(entity, "sind:dyn/sneaking_timer", 40, 5, entity.world().blockAt(entity.pos().subtract(0,1,0)).isSolid() && entity.isSneaking() );
    manager.incrementData(entity, "sind:dyn/clamp_timer", 5, entity.getData("sind:dyn/sneaking_timer") >= 1);

    if (entity.getData("sind:dyn/clamp_timer") == 1) {
        manager.setTagList(nbt, "AttributeModifiers", manager.newTagList("[{AttributeName:\"generic.knockbackResistance\",Name:\"Knockback Resist\",Amount:1.0,Operation:0,Slot:\"chest\",UUIDMost:12345,UUIDLeast:67890}]"));
    } else {
        manager.removeTag(nbt, "AttributeModifiers");
    }
}
function fixEquipmentIndex(manager, nbtList, index, itemName, suitType) {
    for (var i = 0; i < nbtList.tagCount(); ++i) {
        var itemIdTag = nbtList.getCompoundTag(i).getCompoundTag("Item").getShort("id");
        var indexTag = nbtList.getCompoundTag(i).getByte("Index");
        var suitTypeTag = suitType == null ? null : nbtList.getCompoundTag(i).getCompoundTag("Item").getCompoundTag("tag").getString("HeroType");
        if (itemIdTag == PackLoader.getNumericalItemId(itemName) && indexTag != index && suitTypeTag == suitType) {
            manager.setByte(nbtList.getCompoundTag(i), "Index", index);
        }
    }
}
function fixArmRocketEquipmentIndex(entity, manager) {
    var nbt = entity.getWornChestplate().nbt();
    //run fix for 5 ticks
    if (nbt.hasKey("Equipment") && nbt.getByte("fix") < 5) {
        var equipments = nbt.getTagList("Equipment");
        fixEquipmentIndex(manager, equipments, 1, "minecraft:gunpowder", null);
        fixEquipmentIndex(manager, equipments, 2, "minecraft:fire_charge", null);
        fixEquipmentIndex(manager, equipments, 3, "minecraft:tnt", null);
        manager.setByte(nbt, "fix", nbt.getByte("fix") + 1);
    }
}

function fixWm1EquipmentIndex(entity, manager) {
    var nbt = entity.getWornChestplate().nbt();
    //run fix for 5 ticks
    if (nbt.hasKey("Equipment") && nbt.getByte("fix") < 5) {
        var equipments = nbt.getTagList("Equipment");
        fixEquipmentIndex(manager, equipments, 1, "minecraft:tnt", null);
        manager.setByte(nbt, "fix", nbt.getByte("fix") + 1);
    }
}

function fix6EquipmentIndex(entity, manager) {
    var nbt = entity.getWornChestplate().nbt();
    //run fix for 5 ticks
    if (nbt.hasKey("Equipment") && nbt.getByte("fix") < 5) {
        var equipments = nbt.getTagList("Equipment");
        fixEquipmentIndex(manager, equipments, 1, "minecraft:gunpowder", null);
        fixEquipmentIndex(manager, equipments, 2, "minecraft:fire_charge", null);
        fixEquipmentIndex(manager, equipments, 3, "minecraft:tnt", null);
        fixEquipmentIndex(manager, equipments, 4, "minecraft:redstone", null);
        manager.setByte(nbt, "fix", nbt.getByte("fix") + 1);
    }
}
function fix39EquipmentIndex(entity, manager) {
    var nbt = entity.getWornChestplate().nbt();
    //run fix for 5 ticks
    if (nbt.hasKey("Equipment") && nbt.getByte("fix") < 5) {
        var equipments = nbt.getTagList("Equipment");
        fixEquipmentIndex(manager, equipments, 1, "fiskheroes:superhero_chestplate", "sind:39_jetpack");
        manager.setByte(nbt, "fix", nbt.getByte("fix") + 1);
    }
}
function fix42EquipmentIndex(entity, manager) {
    var nbt = entity.getWornChestplate().nbt();
    //run fix for 5 ticks
    if (nbt.hasKey("Equipment") && nbt.getByte("fix") < 5) {
        var equipments = nbt.getTagList("Equipment");
        fixEquipmentIndex(manager, equipments, 1, "minecraft:gunpowder", null);
        fixEquipmentIndex(manager, equipments, 2, "minecraft:fire_charge", null);
        fixEquipmentIndex(manager, equipments, 3, "minecraft:tnt", null);

        fixEquipmentIndex(manager, equipments, 7, "fiskheroes:superhero_helmet", "sind:42_1");
        fixEquipmentIndex(manager, equipments, 6, "fiskheroes:superhero_chestplate", "sind:42_2");
        fixEquipmentIndex(manager, equipments, 5, "fiskheroes:superhero_leggings", "sind:42_3");
        fixEquipmentIndex(manager, equipments, 4, "fiskheroes:superhero_boots", "sind:42_4");
        manager.setByte(nbt, "fix", nbt.getByte("fix") + 1);
    }
}

function autoJarvisAfterSentry(entity, manager) {
    var nbt = entity.getWornChestplate().nbt();
    if (nbt.getByte("jarvis_on") == 1 && entity.getEntityName() == "fiskheroes.IronMan") {
        manager.setByte(nbt, "jarvis_sentry_on", 1);
        manager.removeTag(nbt, "jarvis_on");
    }
    
    if (entity.getData("sind:dyn/jarvis") && (nbt.getByte("jarvis_on") != 1) && entity.is("PLAYER")) {
        manager.setByte(nbt, "jarvis_on", 1);
    } else if (!entity.getData("sind:dyn/jarvis") && nbt.getByte("jarvis_on") == 1 && entity.is("PLAYER")) {
        manager.removeTag(nbt, "jarvis_on");
    }
    
    if (entity.is("DISPLAY") && nbt.hasKey("jarvis_on")) {
        manager.removeTag(nbt, "jarvis_on");
    }
    if (entity.is("DISPLAY") && nbt.hasKey("jarvis_sentry_on")) {
        manager.removeTag(nbt, "jarvis_sentry_on");
    }
}

function hammers(entity, manager, hero) {
    var suitType = entity.getWornChestplate().suitType().split("/")[0];
    var nbtSet = (item, value) => {
        manager.setBoolean(item.nbt(), "Unbreakable", value);
    }
    var nbt = entity.getWornChestplate().nbt();

    if (entity.as("PLAYER").isCreativeMode() && (suitType == "sind:mark25" || suitType == "sind:mark26" || suitType == "sind:mark29")) {
        manager.setData(entity, "sind:dyn/tentacles", true);
        return true;
    }
    
    if ((suitType == "sind:mark25" || suitType == "sind:mark26") && !entity.hasPotionEffect(3)){
        manager.setTagList(nbt, "AttributeModifiers", manager.newTagList("[{AttributeName:\"generic.knockbackResistance\",Name:\"Knockback Resist\",Amount:1.0,Operation:0,Slot:\"chest\",UUIDMost:12345,UUIDLeast:67890}]"));
        nbtSet(entity.getWornHelmet(), true);
        nbtSet(entity.getWornChestplate(), true);
        nbtSet(entity.getWornLeggings(), true);
        nbtSet(entity.getWornBoots(), true);
        entity.hurtByAttacker(hero, "HASTE2", "%s somehow died while activating their hammers", 0.05, entity);
        manager.removeTag(nbt, "AttributeModifiers");
        nbtSet(entity.getWornHelmet(), false);
        nbtSet(entity.getWornChestplate(), false);
        nbtSet(entity.getWornLeggings(), false);
        nbtSet(entity.getWornBoots(), false);
    } else if (suitType == "sind:mark29" && !entity.hasPotionEffect(3)){
        manager.setTagList(nbt, "AttributeModifiers", manager.newTagList("[{AttributeName:\"generic.knockbackResistance\",Name:\"Knockback Resist\",Amount:1.0,Operation:0,Slot:\"chest\",UUIDMost:12345,UUIDLeast:67890}]"));
        nbtSet(entity.getWornHelmet(), true);
        nbtSet(entity.getWornChestplate(), true);
        nbtSet(entity.getWornLeggings(), true);
        nbtSet(entity.getWornBoots(), true);
        entity.hurtByAttacker(hero, "HASTE", "%s somehow died while activating their hammer", 0.05, entity);
        manager.removeTag(nbt, "AttributeModifiers");
        nbtSet(entity.getWornHelmet(), false);
        nbtSet(entity.getWornChestplate(), false);
        nbtSet(entity.getWornLeggings(), false);
        nbtSet(entity.getWornBoots(), false);
    }

    return true;
}

function hammersTimer(entity, manager) {
    manager.incrementData(entity, "sind:dyn/tentacles_timer", 5, entity.hasPotionEffect(3) || entity.getData("sind:dyn/tentacles"));

    manager.incrementData(entity, "sind:dyn/another_timer", 1200, entity.getData("sind:dyn/tentacles")); //creative cooldown
    
    if (entity.getData("sind:dyn/another_timer") == 1) {
        manager.setData(entity, "sind:dyn/tentacles", false);
        manager.setInterpolatedData(entity, "sind:dyn/another_timer", 0);
    }
}

function encode(string, code) {
    var output = "";
    for (var i = 0; i < string.length; i++) {
        output += code + string[i];
    }
    return output;
}

function easeToDetransform(entity, manager){
    manager.incrementData(entity, "sind:dyn/suit_to_tony", 5, entity.getData("sind:dyn/ease"));
    if (entity.getInterpolatedData("sind:dyn/suit_to_tony") == 1) {
        manager.setByte(entity.getWornChestplate().nbt(), "STUPID", 1);
        detransform(entity, manager);
    }
    return true;
}

function detransform(entity, manager) {
    var nbt = entity.getWornChestplate().nbt();
    var pick = entity.getWornChestplate().suitType();

    if (gantry_suits.indexOf(pick) == -1 && tony_suits.indexOf(pick) == -1) {
        return true;
    }

    manager.setString(nbt, "Pick", pick);
    manager.setByte(nbt, "Detransform", 1);

    var gp_ammo = nbt.hasKey("gp_ammo") ? nbt.getByte("gp_ammo") : -1;
    var fc_ammo = nbt.hasKey("fc_ammo") ? nbt.getByte("fc_ammo") : -1;
    var tnt_ammo = nbt.hasKey("tnt_ammo") ? nbt.getByte("tnt_ammo") : -1;
    var currEquipments = nbt.hasKey("Equipment") ? nbt.getTagList("Equipment") : -1;

    //remove old tony/gantry mini suit
    if (currEquipments != -1) {
        var tony_off = getIndex(currEquipments, 0).getCompoundTag("Item").getCompoundTag("tag").hasKey("tony_off");
        if (tony_off && pick != "sind:mark38" && pick != "sind:mark38/rg") {
            manager.setByte(nbt, "tony_off", 1);
        }
        removeIndex(manager, currEquipments, 0);
    }

    var equipments = manager.newTagList();
    var createTag = (piece, index) => {
        return manager.newCompoundTag('{Item:{id:' + PackLoader.getNumericalItemId("fiskheroes:superhero_" + piece) + 's,Count:1b,tag:{HeroType:"' + pick + '"},Damage:0s},Index:' + index + 'b}');
    };
    var helmetTag = createTag("helmet", 0);
    var chestplateTag = createTag("chestplate", 1);
    var leggingsTag = createTag("leggings", 2);
    var bootsTag = createTag("boots", 3);
    
    var chestplateItem = manager.newCompoundTag();
    manager.setString(chestplateItem, "HeroType", pick);
    if (currEquipments != -1) {
        manager.setTagList(chestplateItem, "Equipment", currEquipments);
    }
    if (gp_ammo != -1) {
        manager.setByte(chestplateItem, "gp_ammo", gp_ammo);
    }
    if (fc_ammo != -1) {
        manager.setByte(chestplateItem, "fc_ammo", fc_ammo);
    }
    if (tnt_ammo != -1) {
        manager.setByte(chestplateItem, "tnt_ammo", tnt_ammo);
    }
    manager.setCompoundTag(chestplateTag.getCompoundTag("Item"), "tag", chestplateItem);
    manager.appendTag(equipments, helmetTag);
    manager.appendTag(equipments, chestplateTag);
    manager.appendTag(equipments, leggingsTag);
    manager.appendTag(equipments, bootsTag);
    
    manager.setTagList(nbt, "Equipment", equipments);

    var isGantry = gantry_suits.indexOf(pick) !== -1;
    var isTony = tony_suits.indexOf(pick) !== -1;

    if (isGantry) { 
        manager.setString(entity.getWornHelmet().nbt(), "HeroType", "sind:gantry");
        manager.setString(nbt, "HeroType", "sind:gantry");
        manager.setString(entity.getWornLeggings().nbt(), "HeroType", "sind:gantry");
        manager.setString(entity.getWornBoots().nbt(), "HeroType", "sind:gantry");
    } else if (isTony){
        manager.setString(entity.getWornHelmet().nbt(), "HeroType", "sind:tony");
        manager.setString(nbt, "HeroType", "sind:tony");
        manager.setString(entity.getWornLeggings().nbt(), "HeroType", "sind:tony");
        manager.setString(entity.getWornBoots().nbt(), "HeroType", "sind:tony");  
    }
    
    return true;
}

function isTooDamaged(armor) {
    return armor.damage() > 204
}

function getIndex(nbtList, index) {
    for (var i = 0; i < nbtList.tagCount(); ++i) {
        if (nbtList.getCompoundTag(i).getByte("Index") == index) {
            return nbtList.getCompoundTag(i);
        }
    }
    return null;
}

function removeIndex(manager, nbtList, index) {
    for (var i = 0; i < nbtList.tagCount(); ++i) {
        if (nbtList.getCompoundTag(i).getByte("Index") == index) {
            manager.removeTag(nbtList, i);
        }
    }
}

function isOnPistonGrid(entity) {
    for (var i = -2; i <= 2; i++) {
        for (var j = -2; j <= 2; j++) {
            var block = entity.world().getBlock(entity.pos().add(i, -1, j));
            if (block != "minecraft:piston") {
                return false;
            }
        }
    }
    return true;
}