var helmet_list = ["helmet", "faceplate_flip", "faceplate_catch"];
var chest_list = ["chest_front", "chest_back", "chest_lower_back", "right_shoulder", "left_shoulder", "right_elbow", "left_elbow", "right_gauntlet", "left_gauntlet"];
var pants_list = ["pants_left", "pants_right"];
var boots_list = ["boots_left", "boots_right"];

function shuffle(array) {
    var i = array.length;
    var j, temp;
    while (i > 0) {
        // Pick a random index from 0 to i-1
        j = Math.floor(Math.random() * i);
        i--;
        // Swap the current element with the random one
        temp = array[i];
        array[i] = array[j];
        array[j] = temp;
    }
    return array;
}

function getDatasInList(entity, list, time) {
    // if "time" not specified, assumes vars in list are booleans
    if (time == null || time == undefined) {
        for (var i = 0; i < list.length; i++) {
            if (!entity.getData("sind:dyn/mark42_" + list[i])) {
                return false;
            }
        }
    } else {
        for (var i = 0; i < list.length; i++) {
            if (entity.getData("sind:dyn/mark42_" + list[i] + "_timer") != time) {
                return false;
            }
        }
    }
    return true;
}

function timersThisOrThatForList(entity, list, time1, time2) {
    for (var i = 0; i < list.length; i++) {
        if (entity.getData("sind:dyn/mark42_" + list[i] + "_timer") != time1 && entity.getData("sind:dyn/mark42_" + list[i] + "_timer") != time2) {
            return false;
        }
    }
    return true;
}

var overlap = 0.3; // how many seconds to overlap next piece's timer with prev piece's timer, so suit can be summoned faster
function parseStringData(entity, manager) {
    if (PackLoader.getSide() != "SERVER") {
        return;
    }
    var string_data = entity.getData("sind:dyn/mark42_string_data");
    if (string_data == null || string_data == undefined || string_data == "") {
        return;
    }
    var list = string_data.split(",");

    for (var i = 0; i < list.length; i++) {
        var part = list[i];
        if (i == 0) {
            manager.setDataWithNotify(entity, "sind:dyn/mark42_" + part, true);
        } else if (entity.getData("sind:dyn/mark42_" + list[i-1] + "_timer") >= 1 - (overlap)) {
            manager.setDataWithNotify(entity, "sind:dyn/mark42_" + part, true);
        }
    }

    if (entity.getData("sind:dyn/mark42_" + list[list.length - 1] + "_timer") >= 1) {
        manager.setDataWithNotify(entity, "sind:dyn/mark42_string_data", "");
        // reset initials so their anims can be used for another suit part
        manager.setDataWithNotify(entity, "sind:dyn/mark42_initial", false);
        manager.setDataWithNotify(entity, "sind:dyn/mark42_initial_timer", 0);
    }
}

function incrementTimers(entity, manager) {
    var datas = ["mark42_initial", "mark42_helmet", "mark42_chest_front", "mark42_chest_back", "mark42_chest_lower_back", "mark42_right_shoulder", "mark42_left_shoulder", "mark42_right_elbow", "mark42_left_elbow", "mark42_right_gauntlet", "mark42_left_gauntlet", "mark42_pants_left", "mark42_pants_right", "mark42_boots_left", "mark42_boots_right"];
    // i lowk dont know if i can abstract this into a loop cause it might break increment behavior
    datas.forEach(data => {
        manager.incrementData(entity, "sind:dyn/"+data+"_timer", 20, entity.getData("sind:dyn/"+data));
    });
    // note unique increment tick speeds below
    manager.incrementData(entity, "sind:dyn/mark42_faceplate_flip_timer", 60, entity.getData("sind:dyn/mark42_faceplate_flip"));
    manager.incrementData(entity, "sind:dyn/mark42_faceplate_catch_timer", 32, entity.getData("sind:dyn/mark42_faceplate_catch"));

    var headTransformed = entity.getData("sind:dyn/mark42_helmet_timer") == 1 
        && (entity.getData("sind:dyn/mark42_faceplate_catch_timer") == 1 || entity.getData("sind:dyn/mark42_faceplate_flip_timer") == 1);
    var chestTransformed = getDatasInList(entity, chest_list, 1);
    var pantsTransformed = getDatasInList(entity, pants_list, 1);
    var bootsTransformed = getDatasInList(entity, boots_list, 1);
    var fullTransformed = headTransformed && chestTransformed && pantsTransformed && bootsTransformed;
    if (fullTransformed != entity.getData("sind:dyn/mark42_fullsuit")) {
        manager.setData(entity, "sind:dyn/mark42_fullsuit", fullTransformed);
    }

    if (fullTransformed && entity.getData("sind:dyn/mark42_transforming_full")) {
        manager.setData(entity, "sind:dyn/mark42_transforming_full", false);
    }

    var transforming = !timersThisOrThatForList(entity, chest_list.concat(pants_list, boots_list, helmet_list), 0, 1);
    manager.incrementData(entity, "sind:dyn/tentacles_timer", 5, 10, transforming || (entity.getData("sind:dyn/mark42_initial_timer")> 0 && entity.getData("sind:dyn/mark42_initial_timer") < 1));
}

function playSounds(entity, manager) {
    //function of DOOM and despair
    if (entity.getEntityName() == "fiskheroes.IronMan") {
        return;
    }
    var list = ["helmet"].concat(chest_list, pants_list, boots_list);
    list.forEach(data => {
        if (entity.getData("sind:dyn/mark42_"+data+"_timer") > 0 && !entity.getData("sind:dyn/mark42_"+data+"_fire")) {
            entity.playSound("sind:boost_chopped", 0.75, 1.0);
            manager.setData(entity, "sind:dyn/mark42_"+data+"_fire", true);
        } else if (entity.getData("sind:dyn/mark42_"+data+"_timer") > 0.4 && !entity.getData("sind:dyn/mark42_"+data+"_sound")) {
            entity.playSound("sind:piece3", 1.0, 1.1 - (Math.random() * 0.7));
            manager.setData(entity, "sind:dyn/mark42_"+data+"_sound", true);
        } else if (entity.getData("sind:dyn/mark42_"+data+"_timer") == 0) {
            if (entity.getData("sind:dyn/mark42_"+data+"_fire")) {
                manager.setData(entity, "sind:dyn/mark42_"+data+"_fire", false);
            } 
            if (entity.getData("sind:dyn/mark42_"+data+"_sound")) {
                manager.setData(entity, "sind:dyn/mark42_"+data+"_sound", false);
            }
        }
    });

    //spec cases for faceplate stuff
    if (entity.getData("sind:dyn/mark42_faceplate_flip_timer") > 0.2 && !entity.getData("sind:dyn/mark42_faceplate_flip_fire")) {
        entity.playSound("sind:boost_chopped", 0.75, 1.0);
        manager.setData(entity, "sind:dyn/mark42_faceplate_flip_fire", true);
    } else if (entity.getData("sind:dyn/mark42_faceplate_flip_timer") > 0.42 && !entity.getData("sind:dyn/mark42_faceplate_flip_sound")) {
        entity.playSound("sind:piece2", 1.0, 1.0);
        manager.setData(entity, "sind:dyn/mark42_faceplate_flip_sound", true);
    } else if (entity.getData("sind:dyn/mark42_faceplate_flip_timer") > 0.67 && !entity.getData("sind:dyn/tentacles")) { //arbitrary bool to keep num of data vars low
        entity.playSound("sind:landing", 1.0, 1.15 - Math.random() * 0.3);
        manager.setData(entity, "sind:dyn/tentacles", true);
    } else if (entity.getData("sind:dyn/mark42_faceplate_flip_timer") == 0) {
        if (entity.getData("sind:dyn/mark42_faceplate_flip_fire")) {
            manager.setData(entity, "sind:dyn/mark42_faceplate_flip_fire", false);
        }
        if (entity.getData("sind:dyn/mark42_faceplate_flip_sound")) {
            manager.setData(entity, "sind:dyn/mark42_faceplate_flip_sound", false);
        }
        if (entity.getData("sind:dyn/tentacles")) {
            manager.setData(entity, "sind:dyn/tentacles", false);
        }
    }

    if (entity.getData("sind:dyn/mark42_faceplate_catch_timer") > 0 && !entity.getData("sind:dyn/mark42_faceplate_catch_fire")) {
        entity.playSound("sind:boost_chopped", 0.75, 1.0);
        manager.setData(entity, "sind:dyn/mark42_faceplate_catch_fire", true);
    } else if (entity.getData("sind:dyn/mark42_faceplate_catch_timer") > 0.3 && !entity.getData("sind:dyn/mark42_faceplate_catch_sound")) {
        entity.playSound("sind:piece4", 0.25, 1.0);
        manager.setData(entity, "sind:dyn/mark42_faceplate_catch_sound", true);
    } else if (entity.getData("sind:dyn/mark42_faceplate_catch_timer") > 0.6875 && !entity.getData("sind:dyn/drop")) { //arbitrary bool to keep num of data vars low
        entity.playSound("sind:lock", 0.25, 1.0);
        manager.setData(entity, "sind:dyn/drop", true);
    } else if (entity.getData("sind:dyn/mark42_faceplate_catch_timer") == 0) {
        if (entity.getData("sind:dyn/mark42_faceplate_catch_fire")) {
            manager.setData(entity, "sind:dyn/mark42_faceplate_catch_fire", false);
        }
        if (entity.getData("sind:dyn/mark42_faceplate_catch_sound")) {
            manager.setData(entity, "sind:dyn/mark42_faceplate_catch_sound", false);
        }
        if (entity.getData("sind:dyn/drop")) {
            manager.setData(entity, "sind:dyn/drop", false);
        }
    }
}

function fullyTransform(entity, manager) {
    // arbitraily set faceplate to catch instead of flip ig
    var list = ["helmet", "faceplate_catch"].concat(chest_list, pants_list, boots_list);
    for (var i = 0; i < list.length; i++) {
        manager.setData(entity, "sind:dyn/mark42_" + list[i], true);
        manager.setData(entity, "sind:dyn/mark42_" + list[i] + "_sound", true);
        manager.setData(entity, "sind:dyn/mark42_" + list[i] + "_fire", true);
        manager.setInterpolatedData(entity, "sind:dyn/mark42_" + list[i] + "_timer", 1);
    }
    // spec faceplate cases
    manager.setData(entity, "sind:dyn/drop", true);
    manager.setData(entity, "sind:dyn/tentacles", true);
    manager.setInterpolatedData(entity, "sind:dyn/edith_timer", 1); // for backflaps
}

function fullyTransformWithNotify(entity, manager) {
    var list = ["helmet", "faceplate_catch"].concat(chest_list, pants_list, boots_list);
    for (var i = 0; i < list.length; i++) {
        manager.setDataWithNotify(entity, "sind:dyn/mark42_" + list[i], true);
        manager.setDataWithNotify(entity, "sind:dyn/mark42_" + list[i] + "_sound", true);
        manager.setDataWithNotify(entity, "sind:dyn/mark42_" + list[i] + "_fire", true);
        manager.setDataWithNotify(entity, "sind:dyn/mark42_" + list[i] + "_timer", 1);
    }
    // spec faceplate cases
    manager.setDataWithNotify(entity, "sind:dyn/drop", true);
    manager.setDataWithNotify(entity, "sind:dyn/tentacles", true);
    manager.setDataWithNotify(entity, "sind:dyn/edith_timer", 1); // for backflaps
}

function checkAllArmorEquipments(entity, manager) {
    checkArmorEquipment(entity, manager, 1);
    checkArmorEquipment(entity, manager, 2);
    checkArmorEquipment(entity, manager, 3);
    checkArmorEquipment(entity, manager, 4);
}

function checkArmorEquipment(entity, manager, slot) {
    if (PackLoader.getSide() == "CLIENT") {
        return;
    }
    if (getSuitPiece(entity, slot) && !entity.getData("sind:dyn/modularint" + slot)) {
        manager.setDataWithNotify(entity, "sind:dyn/modularint" + slot, true);
        return true;
    } else if (!getSuitPiece(entity, slot) && entity.getData("sind:dyn/modularint" + slot)) {
        // cancel all respective anims if suit piece is removed
        manager.setDataWithNotify(entity, "sind:dyn/mark42_string_data", ""); 
        var animList = [];
        switch (slot) {
            case 1:
                animList = helmet_list;
                break;
            case 2:
                animList = chest_list;
                break;
            case 3:
                animList = pants_list;
                break;
            case 4:
                animList = boots_list;
                break;
        }
        if (entity.getData("sind:dyn/mark42_transforming_full")) {
            animList = [].concat(helmet_list, chest_list, pants_list, boots_list);
        }
        animList.forEach(object => {
            manager.setDataWithNotify(entity, "sind:dyn/mark42_" + object, false);
            manager.setDataWithNotify(entity, "sind:dyn/mark42_" + object + "_timer", 0);
        });
        if (slot == 1 || entity.getData("sind:dyn/mark42_transforming_full")) { //disable jarvis when helmet removed
            manager.setDataWithNotify(entity, "sind:dyn/jarvis", false);
            manager.setDataWithNotify(entity, "sind:dyn/jarvis_timer", 0);
            manager.setDataWithNotify(entity, "sind:dyn/speaking", false);
            manager.setDataWithNotify(entity, "sind:dyn/speaking_timer", 0);
        }
        manager.setDataWithNotify(entity, "sind:dyn/modularint" + slot, false);
    }
}

function getEquipmentIndex(equipment, index) {
    for (var i = 0; i < equipment.tagCount(); i++) {
        if (equipment.getCompoundTag(i).getByte("Index") == index) {
            return equipment.getCompoundTag(i).getCompoundTag("Item").getCompoundTag("tag");
        }
    }
    return null;
}

function getSuitPiece(entity, suit) {
    var suitSlot = [-1, 7, 6, 5, 4];
    var nbt = entity.getWornChestplate().nbt();
    var getItem = tag => {
        var equip = getEquipmentIndex(nbt.getTagList("Equipment"), suitSlot[tag]);
        if (!equip) {
            return false;
        } 
        return equip.getString("HeroType") == "sind:42_" + String(suit);
    }
    return !nbt.hasKey("Equipment") || getItem(suit);
}