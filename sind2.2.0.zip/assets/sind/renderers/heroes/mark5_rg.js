extend("sind:mark5");
loadTextures({
    "suit": "sind:mark5/mark5_rg",
    "briefcase": "sind:mark5/mark5_rg_briefcase",
    "mask": "sind:mark5/mark5_ev_mask.tx.json",
    "chin": "sind:mark4/mark4_chin"
});
