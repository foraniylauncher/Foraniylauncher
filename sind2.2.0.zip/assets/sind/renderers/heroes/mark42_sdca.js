extend("sind:mark42");
loadTextures({
    "layer1": "sind:mark42/mark42_sdca_layer1",
    "layer2": "sind:mark42/mark42_sdca_layer2",
    "whole": "sind:mark42/mark42_sdca_complete",
    "rocket": "sind:mark42/mark42_sdca_rocket.tx.json",

    "split": "sind:mark42/mark42_sdca",
    "suit": "sind:mark42/mark42_sdca_suit.tx.json",

    "flaps": "sind:mark42/mark42_sdca_flaps.tx.json",

    "helmet": "sind:mark42/overlays_sdca/helmet",
    "chest_front": "sind:mark42/overlays_sdca/chest_front",
    "chest_back": "sind:mark42/overlays_sdca/chest_back",
    "chest_lower_back": "sind:mark42/overlays_sdca/chest_lower_back",
    "left_elbow": "sind:mark42/overlays_sdca/left_elbow",
    "left_gauntlet": "sind:mark42/overlays_sdca/left_gauntlet",
    "left_shoulder": "sind:mark42/overlays_sdca/left_shoulder",
    "right_elbow": "sind:mark42/overlays_sdca/right_elbow",
    "right_gauntlet": "sind:mark42/overlays_sdca/right_gauntlet",
    "right_shoulder": "sind:mark42/overlays_sdca/right_shoulder",
    "pants_left": "sind:mark42/overlays_sdca/pants_left",
    "pants_right": "sind:mark42/overlays_sdca/pants_right",
    "boots_left": "sind:mark42/overlays_sdca/boots_left",
    "boots_right": "sind:mark42/overlays_sdca/boots_right",
});