extend("sind:mark5");
loadTextures({
    "suit": "sind:mark5/mark5_ev",
    "briefcase": "sind:mark5/mark5_ev_briefcase",
    "mask": "sind:mark5/mark5_ev_mask.tx.json",
    "chin": "sind:mark5/mark5_ev_chin"
});
