extend("sind:external/iron_man_base");
loadTextures({
    "hulkbuster": "sind:mark44/hulkbuster",
    "hulkbuster_lights": "sind:mark44/hulkbuster_lights",
    "jackhammer": "sind:mark44/hulkbuster_arm.tx.json",
    "jackhammer_lights": "sind:mark44/hulkbuster_arm_lights",
    "rocket": "sind:mark42/mark42_rocket.tx.json",

    "split": "sind:mark43/mark43",
    "split_lights": "sind:mark42/mark42_lights",

    "fire": "sind:repulsor_layer.tx.json",
    "repulsor_hulkbuster": "sind:mark44/hulkbuster_repulsor",

    "layer1": "sind:mark43/mark43_layer1",
    "layer2": "sind:mark43/mark43_layer2",
    "fake": "sind:mark43/mark43_complete",
    "suit": "sind:mark43/mark43_suit.tx.json",

    "helmet": "sind:mark43/overlays/helmet",
    "chest_front": "sind:mark43/overlays/chest_front",
    "chest_back": "sind:mark43/overlays/chest_back",
    "chest_lower_back": "sind:mark43/overlays/chest_lower_back",
    "left_elbow": "sind:mark43/overlays/left_elbow",
    "left_gauntlet": "sind:mark43/overlays/left_gauntlet",
    "left_shoulder": "sind:mark43/overlays/left_shoulder",
    "right_elbow": "sind:mark43/overlays/right_elbow",
    "right_gauntlet": "sind:mark43/overlays/right_gauntlet",
    "right_shoulder": "sind:mark43/overlays/right_shoulder",
    "pants_left": "sind:mark43/overlays/pants_left",
    "pants_right": "sind:mark43/overlays/pants_right",
    "boots_left": "sind:mark43/overlays/boots_left",
    "boots_right": "sind:mark43/overlays/boots_right",
    "lights_noeyes": "sind:lights/lights_noeyes",

    "mask": "sind:mark42/mark42_mask.tx.json",
    "flaps": "sind:mark43/mark43_flaps.tx.json",
    "hud2": "sind:hud/hud_orange",
    "radar2": "sind:hud/hud_radar_orange",
    "radius2": "sind:hud/hud_overlay_orange",

    //jarvis stuff
    "player": "sind:hud/mark42/full",
    "player_mh": "sind:hud/mark42/mh",
    "player0": "sind:hud/mark42/0",
    "player1": "sind:hud/mark42/1",
    "player2": "sind:hud/mark42/2",
    "player3": "sind:hud/mark42/3",

    "hud_hb": "sind:hud/mark44/full",
    "hud_hb1": "sind:hud/mark44/1",
    "hud_hb_mh": "sind:hud/mark44/mh",
    "hud_hb_jh": "sind:hud/mark44/arm",
    "hud_hb_jh1": "sind:hud/mark44/w_arm",
    "hud_hb_jh_mh": "sind:hud/mark44/mh_arm"
});

var utils = implement("fiskheroes:external/utils");
var iron_man_boosters = implement("sind:external/mk43_boosters");
var iron_man_utils = implement("sind:external/iron_man_utils");
var hulkbuster_utils = implement("sind:external/hulkbuster");
var hulkbuster;
var jarvis =  implement("sind:external/jarvis");
var hud;
var hud_hb;
var hud_hb_player;

var faker;
var helmet;
var night_vision, flaps;
var unibeam2;
var leftArm;

var metal_heat;

var hb_player_repulsor;

var overlay, overlay_layer2, overlay_lights, flaps;
var helmet42, faceplate_flip42, faceplate_catch42;
var helmet42fire, faceplate_flip42fire, faceplate_catch42fire;
var chest_front42, chest_back42, chest_lower_back42, left_elbow42, left_shoulder42, left_gauntlet42, right_elbow42, right_shoulder42, right_gauntlet42;
var chest_front42fire, chest_back42fire, chest_lower_back42fire, left_elbow42fire, left_shoulder42fire, left_gauntlet42fire, right_elbow42fire, right_shoulder42fire, right_gauntlet42fire;
var pants_left42, pants_right42, boots_left42, boots_right42;
var pants_left42fire, pants_right42fire, boots_left42fire, boots_right42fire;

var helmet42ov;
var chest_front42ov, chest_back42ov, chest_lower_back42ov, left_elbow42ov, left_shoulder42ov, left_gauntlet42ov, right_elbow42ov, right_shoulder42ov, right_gauntlet42ov;
var pants_left42ov, pants_right42ov, boots_left42ov, boots_right42ov;

var helmet_list = ["helmet", "faceplate_flip", "faceplate_catch"];
var chest_list = ["chest_front", "chest_back", "chest_lower_back", "right_shoulder", "left_shoulder", "right_elbow", "left_elbow", "right_gauntlet", "left_gauntlet"];
var pants_list = ["pants_left", "pants_right"];
var boots_list = ["boots_left", "boots_right"];

function init(renderer) {
    parent.init(renderer);
    renderer.setTexture((entity, renderLayer) => {
        if (!entity.is("DISPLAY") || entity.getData("sind:dyn/hulkbuster_timer") == 1) {
            return "null";
        } else {
            return entity.getData("fiskheroes:suit_open_timer") > 0 ? "suit" : renderLayer == "LEGGINGS" ? "layer2" : "layer1";
        }
    });
    renderer.setLights((entity, renderLayer) => {
        if (!entity.is("DISPLAY") || entity.getData("sind:dyn/hulkbuster_timer") == 1) {
            return "null";
        }
        if (renderLayer == "HELMET" && entity.getData("sind:dyn/hulkbuster_timer") < 1) {
            return entity.getData('fiskheroes:mask_open_timer') == 0 ? "lights" : null;
        }
        if (entity.getData("sind:dyn/hulkbuster_timer") < 1) {
            return "lights";
        }
        return "null";
    });
}

function initAnimations(renderer) {
    parent.initAnimations(renderer);
    renderer.removeCustomAnimation("iron_man.UNIBEAM");
    renderer.removeCustomAnimation("iron_man.FLIGHT");
    renderer.removeCustomAnimation("iron_man.HOVER");
    renderer.removeCustomAnimation("iron_man.LAND");
    renderer.removeCustomAnimation("basic.AIMING");

    addAnimation(renderer, "iron_man.UNIBEAM", "sind:unibeam").setData((entity, data) => {
        var timer = 1 - entity.getInterpolatedData("fiskheroes:flight_timer");
        data.load(0, entity.getInterpolatedData("fiskheroes:beam_charge") * timer);
        data.load(1, entity.getInterpolatedData("fiskheroes:beam_shooting_timer") * timer);
        data.load(2, entity.getData("fiskheroes:beam_charging"));
    }).setCondition(entity => entity.getData("sind:dyn/hulkbuster_timer") == 0);

    utils.addFlightAnimationWithLanding(renderer, "iron_man.FLIGHT", "fiskheroes:flight/iron_man.anim.json").setCondition(entity => entity.getData("sind:dyn/hulkbuster_timer") == 0);
    utils.addHoverAnimation(renderer, "iron_man.HOVER", "fiskheroes:flight/idle/iron_man").setCondition(entity => entity.getData("sind:dyn/hulkbuster_timer") == 0);
    addAnimationWithData(renderer, "iron_man.LAND", "fiskheroes:superhero_landing", "sind:dyn/superhero_landing_timer").setCondition(entity => entity.getData("sind:dyn/hulkbuster_timer") == 0).priority = -8;

    addAnimationWithData(renderer, "basic.AIMING", "fiskheroes:aiming", "fiskheroes:aiming_timer")
    .setCondition(entity => entity.getData("sind:dyn/hulkbuster_timer") == 0).priority = 10;

    addAnimationWithData(renderer, "sind.STUFF", "sind:dual_aiming_nofp", "sind:dyn/cluster_timer").setCondition(entity => entity.getData("sind:dyn/hulkbuster_timer") == 0)
    .priority = 12;

    addAnimation(renderer, "iron_man.ROCKET", "sind:rocket_aiming").setData((entity, data) => {
    data.load(Math.min(entity.getInterpolatedData("sind:dyn/armgun_timer"), 1));}).setCondition(entity => entity.getData("sind:dyn/hulkbuster_timer") == 0).priority = 16;
    //hulkbuster animations
    addAnimation(renderer, "hb.SUMMON", "sind:hulkbuster_player/hulkbuster_summon_fly")
    .setData((entity, data) => {
        data.load(entity.getInterpolatedData("sind:dyn/hulkbuster_timer"));
    }).priority = 1;

    addAnimation(renderer, "hb.POSE", "sind:hulkbuster_player/hulkbuster_pose")
    .setData((entity, data) => {
        data.load(0, entity.getData("sind:dyn/hulkbuster_timer") == 1);
    }).setCondition(entity => entity.getData("sind:dyn/hulkbuster_timer") == 1).priority = 2;

    addAnimation(renderer, "hb.hover", "sind:flight/idle/hulkbuster_player").setData((entity, data) => {
        data.load(0, entity.getInterpolatedData("fiskheroes:levitate_timer"));
        data.load(1, entity.loop(20 * Math.PI) + 0.4);
    }).setCondition(entity => entity.getData("sind:dyn/hulkbuster_timer") == 1).priority = 11;
    addAnimation(renderer, "hb.flight", "sind:flight/hulkbuster_player.anim.json").setData((entity, data) => {
        data.load(0, entity.getInterpolatedData("fiskheroes:flight_timer"));
        data.load(1, entity.getInterpolatedData("fiskheroes:flight_boost_timer"));
        data.load(2, 1);
    }).setCondition(entity => entity.getData("sind:dyn/hulkbuster_timer") == 1).priority = 10;
    addAnimation(renderer, "hb.dive", "sind:hulkbuster_player/hulkbuster_dive").setData((entity, data) => {
        data.load(entity.getInterpolatedData("sind:dyn/dive_timer"));
    }).setCondition(entity => entity.getData("sind:dyn/hulkbuster_timer") == 1).priority = 3;
    addAnimation(renderer, "hb.landing", "sind:hulkbuster_player/hulkbuster_landing").setData((entity, data) => {
        data.load(0, entity.getInterpolatedData("sind:dyn/superhero_landing_timer"));
        data.load(3, entity.getInterpolatedData("fiskheroes:aiming_timer"));
        data.load(4, entity.getInterpolatedData("fiskheroes:energy_projection_timer"));
    }).setCondition(entity => entity.getData("sind:dyn/hulkbuster_timer") == 1).priority = 12;
    addAnimation(renderer, "hb.sneak", "sind:hulkbuster_player/hulkbuster_sneak").setData((entity, data) => {
        data.load(1, entity.getData("sind:dyn/hulkbuster_timer")==1);
        data.load(3, entity.getInterpolatedData("fiskheroes:aiming_timer"));
        data.load(4, entity.getInterpolatedData("fiskheroes:energy_projection_timer"));
        data.load(5, entity.getInterpolatedData("fiskheroes:flight_timer"));
        data.load(8, entity.getInterpolatedData("sind:dyn/sneaking_timer"));
    }).setCondition(entity => entity.getData("sind:dyn/hulkbuster_timer") == 1).priority = 13;
    addAnimation(renderer, "hb.punches", "sind:hulkbuster_player/hulkbuster_punches").setData((entity, data) => {
        data.load(0, entity.getInterpolatedData("sind:dyn/ground_smash_use_timer"));
        data.load(1, entity.getInterpolatedData("sind:dyn/earthquake_use_timer"));
        data.load(3, entity.getInterpolatedData("sind:dyn/ground_smash_timer"));
        data.load(4, entity.getInterpolatedData("sind:dyn/earthquake_timer"));
        data.load(5, entity.getInterpolatedData("sind:dyn/punch_right_timer"));
        data.load(6, entity.getInterpolatedData("sind:dyn/punch_left_timer"));
        data.load(8, entity.getData("sind:dyn/hulkbuster_timer")==1);
        data.load(9, entity.loop(100) * entity.getInterpolatedData("sind:dyn/idle_timer"));
        data.load(10, entity.loop(100) * entity.getInterpolatedData("sind:dyn/idle_timer2"));
    }).setCondition(entity => entity.getData("sind:dyn/hulkbuster_timer") == 1).priority = 14;
    addAnimation(renderer, "hb.actions", "sind:hulkbuster_player/hulkbuster_actions").setData((entity, data) => {
        data.load(0, 1);
        data.load(1, entity.getInterpolatedData("sind:dyn/sprinting_timer"));
        data.load(2, entity.getInterpolatedData("sind:dyn/leaping_timer"));
        data.load(3, entity.getInterpolatedData("fiskheroes:energy_projection_timer"));
        data.load(4, entity.getInterpolatedData("fiskheroes:aiming_timer"));
        data.load(5, entity.getInterpolatedData("fiskheroes:flight_timer"));
        data.load(6, entity.getInterpolatedData("sind:dyn/dive_timer"));
        data.load(7, entity.getInterpolatedData("sind:dyn/superhero_landing_timer"));
        data.load(8, entity.getData("sind:dyn/hulkbuster_timer")==1);
        // unibeam
        var timer = 1 - entity.getInterpolatedData("fiskheroes:flight_timer");
        data.load(10, entity.getInterpolatedData("fiskheroes:beam_charge") * timer);
        data.load(11, entity.getInterpolatedData("fiskheroes:beam_shooting_timer") * timer);
        data.load(12, entity.getData("fiskheroes:beam_charging"));
    }).setCondition(entity => entity.getData("sind:dyn/hulkbuster_timer") == 1).priority = 15;
    addAnimation(renderer, "hb.smash_stomp", "sind:hulkbuster_player/hulkbuster_smash_stomp").setData((entity, data) => {
        data.load(0, entity.getInterpolatedData("sind:dyn/ground_smash_timer"));
        data.load(1, Math.min(1, 2 * entity.getInterpolatedData("sind:dyn/ground_smash_use_timer")));
        data.load(2, entity.getInterpolatedData("sind:dyn/earthquake_timer"));
        data.load(3, Math.min(1, 2 * entity.getInterpolatedData("sind:dyn/earthquake_use_timer")));
        data.load(5, entity.getInterpolatedData("fiskheroes:energy_projection_timer"));
        data.load(4, entity.getInterpolatedData("fiskheroes:aiming_timer"));
        data.load(5, entity.getInterpolatedData("fiskheroes:shield_blocking_timer"));
    }).setCondition(entity => entity.getData("sind:dyn/hulkbuster_timer") == 1).priority = 16;
    addAnimation(renderer, "hb.jackhammer", "sind:hulkbuster_player/hulkbuster_jackhammer").setData((entity, data) => {
        data.load(0, entity.getInterpolatedData("sind:dyn/telekinesis_timer"));
        data.load(1, entity.getInterpolatedData("fiskheroes:heat_vision_timer"));
    }).setCondition(entity => entity.getData("sind:dyn/hulkbuster_timer") == 1 && entity.getData("sind:dyn/hulkbuster_arm_timer") == 1).priority = 17;

    addAnimationWithData(renderer, "tony_suit", "sind:cancel", "sind:dyn/tony_to_suit").priority = -11;
    addAnimationWithData(renderer, "suit_tony", "sind:cancel", "sind:dyn/suit_to_tony").priority = -11;
    addAnimation(renderer, "cancel_on_detransform", "sind:cancel").setData((entity, data) => {
        data.load(iron_man_utils.getDetransform(entity));
    }).priority = -11;

    addAnimation(renderer, "sind.NOTHING", "sind:cancel").setData((entity, data) => {
        data.load(entity.getInterpolatedData("sind:dyn/tentacles_timer"));
    }).priority = -11;

    addAnimation(renderer, "armbeGONE", "fiskheroes:ocular_beam").setData((entity, data) => {
        data.load(Math.min(1, entity.getInterpolatedData("sind:dyn/tentacles_timer")));
    }).priority = -11;

    // add animation from HELL
    addAnimationWithData(renderer, "initial", "sind:mk42/initial", "sind:dyn/mark42_initial_timer").setCondition(entity => entity.getEntityName() != "fiskheroes.IronMan" && entity.getInterpolatedData("sind:dyn/mark42_initial_timer") < 1);
    addAnimationWithData(renderer, "faceplate_flip", "sind:mk42/faceplate_flip", "sind:dyn/mark42_faceplate_flip_timer").setCondition(entity => entity.getEntityName() != "fiskheroes.IronMan" && entity.getInterpolatedData("sind:dyn/mark42_faceplate_flip_timer") < 1);
    addAnimationWithData(renderer, "faceplate_catch", "sind:mk42/faceplate_catch", "sind:dyn/mark42_faceplate_catch_timer").setCondition(entity => entity.getEntityName() != "fiskheroes.IronMan" && entity.getInterpolatedData("sind:dyn/mark42_faceplate_catch_timer") < 1);
    addAnimationWithData(renderer, "helmet", "sind:mk42/helmet", "sind:dyn/mark42_helmet_timer").setCondition(entity => entity.getEntityName() != "fiskheroes.IronMan" && entity.getInterpolatedData("sind:dyn/mark42_helmet_timer") < 1);
    addAnimationWithData(renderer, "chest_front", "sind:mk42/chest_front", "sind:dyn/mark42_chest_front_timer").setCondition(entity => entity.getEntityName() != "fiskheroes.IronMan" && entity.getInterpolatedData("sind:dyn/mark42_chest_front_timer") < 1);
    addAnimationWithData(renderer, "chest_back", "sind:mk42/chest_back", "sind:dyn/mark42_chest_back_timer").setCondition(entity => entity.getEntityName() != "fiskheroes.IronMan" && entity.getInterpolatedData("sind:dyn/mark42_chest_back_timer") < 1);
    addAnimationWithData(renderer, "chest_lower_back", "sind:mk42/chest_lower_back", "sind:dyn/mark42_chest_lower_back_timer").setCondition(entity => entity.getEntityName() != "fiskheroes.IronMan" && entity.getInterpolatedData("sind:dyn/mark42_chest_lower_back_timer") < 1);
    addAnimationWithData(renderer, "left_elbow", "sind:mk42/left_elbow", "sind:dyn/mark42_left_elbow_timer").setCondition(entity => entity.getEntityName() != "fiskheroes.IronMan" && entity.getInterpolatedData("sind:dyn/mark42_left_elbow_timer") < 1);
    addAnimationWithData(renderer, "left_shoulder", "sind:mk42/left_shoulder", "sind:dyn/mark42_left_shoulder_timer").setCondition(entity => entity.getEntityName() != "fiskheroes.IronMan" && entity.getInterpolatedData("sind:dyn/mark42_left_shoulder_timer") < 1);
    addAnimationWithData(renderer, "left_gauntlet", "sind:mk42/left_gauntlet", "sind:dyn/mark42_left_gauntlet_timer").setCondition(entity => entity.getEntityName() != "fiskheroes.IronMan" && entity.getInterpolatedData("sind:dyn/mark42_left_gauntlet_timer") < 1);
    addAnimationWithData(renderer, "right_elbow", "sind:mk42/right_elbow", "sind:dyn/mark42_right_elbow_timer").setCondition(entity => entity.getEntityName() != "fiskheroes.IronMan" && entity.getInterpolatedData("sind:dyn/mark42_right_elbow_timer") < 1);
    addAnimationWithData(renderer, "right_shoulder", "sind:mk42/right_shoulder", "sind:dyn/mark42_right_shoulder_timer").setCondition(entity => entity.getEntityName() != "fiskheroes.IronMan" && entity.getInterpolatedData("sind:dyn/mark42_right_shoulder_timer") < 1);
    addAnimationWithData(renderer, "right_gauntlet", "sind:mk42/right_gauntlet", "sind:dyn/mark42_right_gauntlet_timer").setCondition(entity => entity.getEntityName() != "fiskheroes.IronMan" && entity.getInterpolatedData("sind:dyn/mark42_right_gauntlet_timer") < 1);
    addAnimationWithData(renderer, "pants_left", "sind:mk42/pants_left", "sind:dyn/mark42_pants_left_timer").setCondition(entity => entity.getEntityName() != "fiskheroes.IronMan" && entity.getInterpolatedData("sind:dyn/mark42_pants_left_timer") < 1);
    addAnimationWithData(renderer, "pants_right", "sind:mk42/pants_right", "sind:dyn/mark42_pants_right_timer").setCondition(entity => entity.getEntityName() != "fiskheroes.IronMan" && entity.getInterpolatedData("sind:dyn/mark42_pants_right_timer") < 1);
    addAnimationWithData(renderer, "boots_left", "sind:mk42/boots_left", "sind:dyn/mark42_boots_left_timer").setCondition(entity => entity.getEntityName() != "fiskheroes.IronMan" && entity.getInterpolatedData("sind:dyn/mark42_boots_left_timer") < 1);
    addAnimationWithData(renderer, "boots_right", "sind:mk42/boots_right", "sind:dyn/mark42_boots_right_timer").setCondition(entity => entity.getEntityName() != "fiskheroes.IronMan" && entity.getInterpolatedData("sind:dyn/mark42_boots_right_timer") < 1);
}

function initEffects(renderer) {
    parent.initEffects(renderer);
    hulkbuster = hulkbuster_utils.create(renderer, utils, iron_man_utils, "hulkbuster", "hulkbuster_lights", "fake", "lights", "jackhammer", "jackhammer_lights", "fire", "repulsor_hulkbuster");
    hb_player_repulsor = renderer.createEffect("fiskheroes:overlay");
    repulsor = renderer.createEffect("fiskheroes:overlay");
    unibeam2 = iron_man_utils.createUnibeam(renderer, 0x8CC4E2, 0, 0, -0.35);
    boosters = iron_man_boosters.create(renderer, "fiskheroes:repulsor_layer_%s", true);
    utils.bindParticles(renderer, "fiskheroes:iron_man").setCondition(entity => entity.getData("fiskheroes:flying") && entity.getData("sind:dyn/hulkbuster_timer") < 1);

    night_vision = renderer.bindProperty("fiskheroes:night_vision");
    night_vision.factor = 1;
    night_vision.setCondition(entity => (entity.getData("fiskheroes:mask_open_timer2") == 0 || entity.getData("sind:dyn/hulkbuster_timer") >= 1) && (entity.getData("sind:dyn/mark42_faceplate_catch_timer") == 1 || entity.getData("sind:dyn/mark42_faceplate_flip_timer") == 1));
    night_vision.firstPersonOnly = false;

    overlay = renderer.createEffect("fiskheroes:overlay");
    overlay.texture.set("layer1");

    overlay_layer2 = renderer.createEffect("fiskheroes:overlay");
    overlay_layer2.texture.set("layer2");

    overlay_lights = renderer.createEffect("fiskheroes:overlay");
    overlay_lights.texture.set(null, "lights");

    helmet42ov = renderer.createEffect("fiskheroes:overlay");
    helmet42ov.texture.set("helmet");
    chest_front42ov = renderer.createEffect("fiskheroes:overlay");
    chest_front42ov.texture.set("chest_front", "lights_noeyes");
    chest_back42ov = renderer.createEffect("fiskheroes:overlay");
    chest_back42ov.texture.set("chest_back");
    chest_lower_back42ov = renderer.createEffect("fiskheroes:overlay");
    chest_lower_back42ov.texture.set("chest_lower_back");
    left_elbow42ov = renderer.createEffect("fiskheroes:overlay");
    left_elbow42ov.texture.set("left_elbow");
    left_shoulder42ov = renderer.createEffect("fiskheroes:overlay");
    left_shoulder42ov.texture.set("left_shoulder");
    left_gauntlet42ov = renderer.createEffect("fiskheroes:overlay");
    left_gauntlet42ov.texture.set("left_gauntlet");
    right_elbow42ov = renderer.createEffect("fiskheroes:overlay");
    right_elbow42ov.texture.set("right_elbow");
    right_shoulder42ov = renderer.createEffect("fiskheroes:overlay");
    right_shoulder42ov.texture.set("right_shoulder");
    right_gauntlet42ov = renderer.createEffect("fiskheroes:overlay");
    right_gauntlet42ov.texture.set("right_gauntlet");
    pants_left42ov = renderer.createEffect("fiskheroes:overlay");
    pants_left42ov.texture.set("pants_left");
    pants_right42ov = renderer.createEffect("fiskheroes:overlay");
    pants_right42ov.texture.set("pants_right");
    boots_left42ov = renderer.createEffect("fiskheroes:overlay");
    boots_left42ov.texture.set("boots_left");
    boots_right42ov = renderer.createEffect("fiskheroes:overlay");
    boots_right42ov.texture.set("boots_right");

    helmet42 = createModel(renderer, "helmet");
    helmet42fire = createFire(renderer, "helmet");
    faceplate_flip42 = createModel(renderer, "faceplate_flip");
    faceplate_flip42fire = createFire(renderer, "faceplate_flip");
    faceplate_catch42 = createModel(renderer, "faceplate_catch");
    faceplate_catch42fire = createFire(renderer, "faceplate_catch");
    chest_front42 = createModel(renderer, "chest_front");
    chest_front42fire = createFire(renderer, "chest_front");
    chest_back42 = createModel(renderer, "chest_back");
    chest_back42fire = createFire(renderer, "chest_back");
    chest_lower_back42 = createModel(renderer, "chest_lower_back");
    chest_lower_back42fire = createFire(renderer, "chest_lower_back");
    left_elbow42 = createModel(renderer, "left_elbow");
    left_elbow42fire = createFire(renderer, "left_elbow");
    left_shoulder42 = createModel(renderer, "left_shoulder");
    left_shoulder42fire = createFire(renderer, "left_shoulder");
    left_gauntlet42 = createModel(renderer, "left_gauntlet");
    left_gauntlet42fire = createFire(renderer, "left_gauntlet");
    right_elbow42 = createModel(renderer, "right_elbow");
    right_elbow42fire = createFire(renderer, "right_elbow");
    right_shoulder42 = createModel(renderer, "right_shoulder");
    right_shoulder42fire = createFire(renderer, "right_shoulder");
    right_gauntlet42 = createModel(renderer, "right_gauntlet");
    right_gauntlet42fire = createFire(renderer, "right_gauntlet");
    pants_left42 = createModel(renderer, "pants_left");
    pants_left42fire = createFire(renderer, "pants_left");
    pants_right42 = createModel(renderer, "pants_right");
    pants_right42fire = createFire(renderer, "pants_right");
    boots_left42 = createModel(renderer, "boots_left");
    boots_left42fire = createFire(renderer, "boots_left");
    boots_right42 = createModel(renderer, "boots_right");
    boots_right42fire = createFire(renderer, "boots_right");

    //fake left arm credit to shadow
    leftArm = renderer.createEffect("fiskheroes:model");
    leftArm.setModel(utils.createModel(renderer, "sind:leftArm", "layer1"));
    leftArm.anchor.ignoreAnchor(true);
    leftArm.anchor.set("rightArm");
    leftArm.setRotation(-90, 90, 0);

    utils.bindBeam(renderer, "fiskheroes:energy_projection", "sind:repbeams", "rightArm", 0xFFC462, [{
                "firstPerson": [-3.75, 3.0, -8.0],
                "offset": [-0.5, 8.0, 0.0],
                "size": [1.5, 1.5]
            }, {
                "firstPerson": [3.75, 3.0, -8.0],
                "offset": [0.5, 8.0, 0.0],
                "size": [1.5, 1.5],
                "anchor": "leftArm"
            }
        ])
    .setParticles(renderer.createResource("PARTICLE_EMITTER", "fiskheroes:impact_charged_beam")).setCondition(entity => !entity.getData("sind:dyn/hulkbuster"));

    flares = iron_man_utils.createFlares(renderer, utils, "layer2", null);
    flaps = iron_man_utils.create42Flaps(renderer, utils, "flaps", null, 3);
    rockets2 = iron_man_utils.createArmRocket(renderer, utils, "rocket", null, 4);

    var lgun = utils.createModel(renderer, "sind:mk3/gunleft", "layer1", null);
    lgun.bindAnimation("sind:shoulderguns").setData((entity, data) => {
        var guncharge = entity.getInterpolatedData("sind:dyn/srockets_cooldown");
        data.load(0, entity.getData("sind:dyn/srockets") ? Math.min(guncharge * 2, 1) : Math.min(guncharge * 5, 1));
    });

    var rgun = utils.createModel(renderer, "sind:mk3/gunright", "layer1", null);
    rgun.bindAnimation("sind:shoulderguns").setData((entity, data) => {
        var guncharge = entity.getInterpolatedData("sind:dyn/srockets_cooldown");
        data.load(0, entity.getData("sind:dyn/srockets") ? Math.min(guncharge * 2, 1) : Math.min(guncharge * 5, 1));
    });

    rightgun = renderer.createEffect("fiskheroes:model").setModel(rgun);
    rightgun.anchor.set("rightArm");

    leftgun = renderer.createEffect("fiskheroes:model").setModel(lgun);
    leftgun.anchor.set("leftArm");

    leftgun.setOffset(4.95, -2.15, 0);
    rightgun.setOffset(-4.95, -2.15, 0);

    helmet = iron_man_utils.createFaceplate(renderer, "mask", null);

    utils.bindBeam(renderer, "fiskheroes:repulsor_blast", "fiskheroes:repulsor_blast", "rightArm", 0xFFC462, [{
        "firstPerson": [-4.5, 3.75, -7.0],
        "offset": [-0.5, 9.0, 0.0],
        "size": [1.5, 1.5]
    }
    ]).setCondition(entity => !entity.getData("sind:dyn/hulkbuster"));

    utils.bindBeam(renderer, "fiskheroes:charged_beam", "sind:unibeam", "body", 0xFFC462, [{
        "firstPerson": [0, 6, -3],
        "offset": [0, 2.75, -3], "size": [1.5, 1.5]
            }
    ]).setParticles(renderer.createResource("PARTICLE_EMITTER", "fiskheroes:impact_energy_projection")).setCondition(entity => !entity.getData("sind:dyn/hulkbuster"));

    utils.bindBeam(renderer, "fiskheroes:heat_vision", "sind:rockets1", "head", 0xFFFFFF, [{
                "offset": [5.5, -1.0, 3.0],
                "size": [0.25, 0.25]
            }, {
                "offset": [-5.5, -1.0, 3.0],
                "size": [0.25, 0.25]
            }, {
                "offset": [4.5, -1.0, 3.0],
                "size": [0.25, 0.25]
            }, {
                "offset": [-4.5, -1.0, 3.0],
                "size": [0.25, 0.25]
            }, {
                "offset": [5.5, -0.5, 3.0],
                "size": [0.25, 0.25]
            }, {
                "offset": [-5.5, -0.5, 3.0],
                "size": [0.25, 0.25]
            }, {
                "offset": [4.5, -0.5, 3.0],
                "size": [0.25, 0.25]
            }, {
                "offset": [-4.5, -0.5, 3.0],
                "size": [0.25, 0.25]
            }
        ]).setParticles(renderer.createResource("PARTICLE_EMITTER", "fiskheroes:impact_charged_beam")).setCondition(entity => !entity.getData("sind:dyn/hulkbuster") && entity.getData("sind:dyn/hulkbuster_arm_timer") == 0);
    //hulkbuster stuff
    utils.bindBeam(renderer, "fiskheroes:charged_beam", "sind:unibeam", "body", 0xFFC462, [{
        "firstPerson": [0, 6, -3],
        "offset": [0, 4.25, -3], "size": [1.5, 1.5]
            }
    ]).setParticles(renderer.createResource("PARTICLE_EMITTER", "fiskheroes:impact_energy_projection")).setCondition(entity => entity.getData("sind:dyn/hulkbuster"));

    metal_heat = renderer.createEffect("fiskheroes:metal_heat");
    metal_heat.includeEffects(helmet.effect, flaps.flaps, rockets2.rockets2, leftgun, rightgun, flares.flares, leftArm, hulkbuster.effect, hulkbuster.fake, hulkbuster.fparm, hulkbuster.jackhammereffect, hulkbuster.leftarmeffect,
        overlay, overlay_layer2,
        helmet42, faceplate_flip42, faceplate_catch42, 
        chest_front42, chest_back42, chest_lower_back42, 
        left_elbow42, left_shoulder42, left_gauntlet42, 
        right_elbow42, right_shoulder42, right_gauntlet42,
        pants_left42, pants_right42, boots_left42, boots_right42,

        helmet42ov, chest_front42ov, chest_back42ov, chest_lower_back42ov,
        left_elbow42ov, left_shoulder42ov, left_gauntlet42ov,
        right_elbow42ov, right_shoulder42ov, right_gauntlet42ov,
        pants_left42ov, pants_right42ov, boots_left42ov, boots_right42ov
    );

    hud = jarvis.create(renderer, utils, "jarvis", 0xA9DADE, 25);
    hud_hb = jarvis.create_hb(renderer, utils, "jarvis", 0xFFA559, 25);
    hud_hb_player = jarvis.create_hb_player(renderer, utils, "jarvis", 0xA9DADE, 25);
}

function render(entity, renderLayer, isFirstPersonArm) {
    var headTransformed = entity.getData("sind:dyn/mark42_helmet_timer") == 1 
        && (entity.getData("sind:dyn/mark42_faceplate_catch_timer") == 1 || entity.getData("sind:dyn/mark42_faceplate_flip_timer") == 1);
    var chestTransformed = getDatasInList(entity, chest_list, 1);
    var pantsTransformed = getDatasInList(entity, pants_list, 1);
    var bootsTransformed = getDatasInList(entity, boots_list, 1);
    hulkbuster.render(entity, isFirstPersonArm);
    if (entity.getInterpolatedData("sind:dyn/hulkbuster_timer") < 0.984) {
        var eq = entity.getInterpolatedData("sind:dyn/hulkbuster_timer") > 1/3 ? 0 : Math.min(1, (Math.sin(3*Math.PI*entity.getInterpolatedData("sind:dyn/hulkbuster_timer"))/Math.sin(Math.PI*0.05)) );
        if (!isFirstPersonArm) {
            if (renderLayer == "CHESTPLATE") {
                hb_player_repulsor.opacity = eq;
                hb_player_repulsor.texture.set(null, "repulsor");
                hb_player_repulsor.render();
                hb_player_repulsor.texture.set(null, "repulsor_left");
                hb_player_repulsor.render();
            } else if (renderLayer == "BOOTS") {
                hb_player_repulsor.opacity = eq;
                hb_player_repulsor.texture.set(null, "repulsor_boots");
                hb_player_repulsor.render();
            }
        }
        boosters.render(entity, renderLayer, isFirstPersonArm, false);
        if (!entity.is("DISPLAY")) {
            overlay.texture.set("layer1");
            if (entity.getData("fiskheroes:suit_open_timer") > 0) {
                overlay.texture.set("suit", "lights");
            }
            if (renderLayer == "HELMET" && headTransformed || renderLayer == "CHESTPLATE" && chestTransformed || renderLayer == "BOOTS" && bootsTransformed || entity.getWornChestplate().nbt().getByte("sentry") > 0) {
                overlay.render();
                if (renderLayer == "HELMET" && (headTransformed || entity.getWornChestplate().nbt().getByte("sentry") > 0) && entity.getData('fiskheroes:mask_open_timer') == 0) {
                    overlay_lights.render();
                } else if (renderLayer == "CHESTPLATE" && (chestTransformed || entity.getWornChestplate().nbt().getByte("sentry") > 0)) {
                    overlay_lights.render();
                    rockets2.render(entity, renderLayer, isFirstPersonArm);
                    unibeam2.render(entity, isFirstPersonArm);
                    if(isFirstPersonArm && entity.getData("sind:dyn/cluster_timer") > 0){
                        leftArm.setOffset(-9, 13.9, 15 - Math.min(1, entity.getInterpolatedData("fiskheroes:energy_projection_timer")) * 15);
                        leftArm.render();
                    }
                    flaps.render(entity, renderLayer, isFirstPersonArm);
                    if (entity.getInterpolatedData("sind:dyn/srockets_cooldown") >= 0.01) {
                        leftgun.render()
                        rightgun.render()
                    }
                }
            }
            if (renderLayer == "LEGGINGS" && (pantsTransformed || entity.getWornChestplate().nbt().getByte("sentry") > 0) && entity.getData("fiskheroes:suit_open_timer") == 0) {
                overlay_layer2.render();
            }
        }
        if (!isFirstPersonArm) {
            if (renderLayer == "HELMET" && (entity.getData("sind:dyn/tony_to_suit") > 0 || (entity.getInterpolatedData("sind:dyn/mark42_faceplate_flip_timer") >= 0.7 || entity.getInterpolatedData("sind:dyn/mark42_faceplate_catch_timer") >= 0.7)|| entity.is("DISPLAY"))) {
                helmet.render(entity.getInterpolatedData("fiskheroes:mask_open_timer2"));
                if (!entity.is("DISPLAY") && entity.getInterpolatedData("sind:dyn/mark42_faceplate_flip_timer") < 1 && entity.getInterpolatedData("sind:dyn/mark42_faceplate_catch_timer") < 1) {
                    overlay_lights.render();
                }
            } else if (renderLayer == "CHESTPLATE" && chestTransformed) {
                repulsor.opacity = Math.max(Math.min(entity.getInterpolatedData("fiskheroes:aimed_timer") * 2, 1), entity.getInterpolatedData("fiskheroes:dyn/booster_r_timer"));
                repulsor.texture.set(null, "repulsor");
                repulsor.render();
                repulsor.opacity = Math.max(Math.min(entity.getInterpolatedData("fiskheroes:energy_projection_timer") * 2, 1), entity.getInterpolatedData("fiskheroes:dyn/booster_l_timer"));
                repulsor.texture.set(null, "repulsor_left");
                repulsor.render();
            } else if (renderLayer == "LEGGINGS" && entity.getData("fiskheroes:suit_open_timer") == 0 && entity.getData("sind:dyn/flares_timer") > 0 && pantsTransformed) {
                flares.render(entity, renderLayer, isFirstPersonArm);
            } else if (renderLayer == "BOOTS" && bootsTransformed) {
                repulsor.opacity = entity.getInterpolatedData("fiskheroes:dyn/booster_timer");
                repulsor.texture.set(null, "repulsor_boots");
                repulsor.render();
            }
        }
    }
    renderModel(entity, helmet42, "sind:dyn/mark42_helmet_timer", isFirstPersonArm, "Special Case");
    renderModel(entity, faceplate_catch42, "sind:dyn/mark42_faceplate_catch_timer", isFirstPersonArm, "Special Case");
    renderModel(entity, faceplate_flip42, "sind:dyn/mark42_faceplate_flip_timer", isFirstPersonArm, "Special Case");
    renderModel(entity, chest_front42, "sind:dyn/mark42_chest_front_timer", isFirstPersonArm, chest_list);
    renderModel(entity, chest_back42, "sind:dyn/mark42_chest_back_timer", isFirstPersonArm, chest_list);
    renderModel(entity, chest_lower_back42, "sind:dyn/mark42_chest_lower_back_timer", isFirstPersonArm, chest_list);
    renderModel(entity, left_elbow42, "sind:dyn/mark42_left_elbow_timer", isFirstPersonArm, chest_list);
    renderModel(entity, left_shoulder42, "sind:dyn/mark42_left_shoulder_timer", isFirstPersonArm, chest_list);
    renderModel(entity, left_gauntlet42, "sind:dyn/mark42_left_gauntlet_timer", isFirstPersonArm, chest_list);
    renderModel(entity, right_elbow42, "sind:dyn/mark42_right_elbow_timer", isFirstPersonArm, chest_list);
    renderModel(entity, right_shoulder42, "sind:dyn/mark42_right_shoulder_timer", isFirstPersonArm, chest_list);
    renderModel(entity, right_gauntlet42, "sind:dyn/mark42_right_gauntlet_timer", isFirstPersonArm, chest_list);
    renderModel(entity, pants_left42, "sind:dyn/mark42_pants_left_timer", isFirstPersonArm, pants_list);
    renderModel(entity, pants_right42, "sind:dyn/mark42_pants_right_timer", isFirstPersonArm, pants_list);
    renderModel(entity, boots_left42, "sind:dyn/mark42_boots_left_timer", isFirstPersonArm, boots_list);
    renderModel(entity, boots_right42, "sind:dyn/mark42_boots_right_timer", isFirstPersonArm, boots_list);

    renderModel(entity, helmet42fire, "sind:dyn/mark42_helmet_timer", isFirstPersonArm, "Special Case");
    renderModel(entity, faceplate_catch42fire, "sind:dyn/mark42_faceplate_catch_timer", isFirstPersonArm, "Special Case");
    renderModel(entity, faceplate_flip42fire, "sind:dyn/mark42_faceplate_flip_timer", isFirstPersonArm, "Special Case");
    renderModel(entity, chest_front42fire, "sind:dyn/mark42_chest_front_timer", isFirstPersonArm, chest_list);
    renderModel(entity, chest_back42fire, "sind:dyn/mark42_chest_back_timer", isFirstPersonArm, chest_list);
    renderModel(entity, chest_lower_back42fire, "sind:dyn/mark42_chest_lower_back_timer", isFirstPersonArm, chest_list);
    renderModel(entity, left_elbow42fire, "sind:dyn/mark42_left_elbow_timer", isFirstPersonArm, chest_list);
    renderModel(entity, left_shoulder42fire, "sind:dyn/mark42_left_shoulder_timer", isFirstPersonArm, chest_list);
    renderModel(entity, left_gauntlet42fire, "sind:dyn/mark42_left_gauntlet_timer", isFirstPersonArm, chest_list);
    renderModel(entity, right_elbow42fire, "sind:dyn/mark42_right_elbow_timer", isFirstPersonArm, chest_list);
    renderModel(entity, right_shoulder42fire, "sind:dyn/mark42_right_shoulder_timer", isFirstPersonArm, chest_list);
    renderModel(entity, right_gauntlet42fire, "sind:dyn/mark42_right_gauntlet_timer", isFirstPersonArm, chest_list);
    renderModel(entity, pants_left42fire, "sind:dyn/mark42_pants_left_timer", isFirstPersonArm, pants_list);
    renderModel(entity, pants_right42fire, "sind:dyn/mark42_pants_right_timer", isFirstPersonArm, pants_list);
    renderModel(entity, boots_left42fire, "sind:dyn/mark42_boots_left_timer", isFirstPersonArm, boots_list);
    renderModel(entity, boots_right42fire, "sind:dyn/mark42_boots_right_timer", isFirstPersonArm, boots_list);

    renderOverlay(entity, helmet42ov, "sind:dyn/mark42_helmet_timer", "Special Case");
    renderOverlay(entity, chest_front42ov, "sind:dyn/mark42_chest_front_timer", chest_list);
    renderOverlay(entity, chest_back42ov, "sind:dyn/mark42_chest_back_timer", chest_list);
    renderOverlay(entity, chest_lower_back42ov, "sind:dyn/mark42_chest_lower_back_timer", chest_list);
    renderOverlay(entity, left_elbow42ov, "sind:dyn/mark42_left_elbow_timer", chest_list);
    renderOverlay(entity, left_shoulder42ov, "sind:dyn/mark42_left_shoulder_timer", chest_list);
    renderOverlay(entity, left_gauntlet42ov, "sind:dyn/mark42_left_gauntlet_timer", chest_list);
    renderOverlay(entity, right_elbow42ov, "sind:dyn/mark42_right_elbow_timer", chest_list);
    renderOverlay(entity, right_shoulder42ov, "sind:dyn/mark42_right_shoulder_timer", chest_list);
    renderOverlay(entity, right_gauntlet42ov, "sind:dyn/mark42_right_gauntlet_timer", chest_list);
    renderOverlay(entity, pants_left42ov, "sind:dyn/mark42_pants_left_timer", pants_list);
    renderOverlay(entity, pants_right42ov, "sind:dyn/mark42_pants_right_timer", pants_list);
    renderOverlay(entity, boots_left42ov, "sind:dyn/mark42_boots_left_timer", boots_list);
    renderOverlay(entity, boots_right42ov, "sind:dyn/mark42_boots_right_timer", boots_list);

    if (entity.is("DISPLAY")) {
        if (renderLayer == "HELMET") {
        helmet.render(entity.getInterpolatedData("fiskheroes:mask_open_timer2"));
        } else if (renderLayer == "CHESTPLATE") {
            rockets2.render(entity, renderLayer, isFirstPersonArm);
            flaps.render(entity, renderLayer, isFirstPersonArm);
        }
    }

    metal_heat.opacity = entity.getInterpolatedData("fiskheroes:metal_heat");
    metal_heat.render();

    if (renderLayer == "HELMET"){
        hud.render(entity, renderLayer, isFirstPersonArm);
        hud_hb.render(entity, renderLayer, isFirstPersonArm);
        hud_hb_player.render(entity, renderLayer, isFirstPersonArm);
    }
}

function createFire(renderer, model) {
    var fireModel;
    if (model == "faceplate_flip" || model == "faceplate_catch") {
        modelTrue = "faceplate";
        fireModel = renderer.createResource("MODEL", "sind:mk42/" + modelTrue + "_fire");
    } else {
        fireModel = renderer.createResource("MODEL", "sind:mk42/" + model + "_fire");
    }
    fireModel.bindAnimation("sind:mk42/" + model).setData((entity, data) => {
        data.load(entity.getInterpolatedData("sind:dyn/mark42_" + model + "_timer"));
    });
    fireModel.bindAnimation("fiskheroes:flight/iron_man.anim.json").setData((entity, data) => {
        data.load(0, entity.getInterpolatedData("fiskheroes:flight_timer") * (1 - entity.getInterpolatedData("fiskheroes:dyn/superhero_landing_timer")));
        data.load(1, entity.getInterpolatedData("fiskheroes:flight_boost_timer"));
    });
    fireModel.bindAnimation("fiskheroes:flight/idle/iron_man").setData((entity, data) => {
        data.load(0, entity.getInterpolatedData("fiskheroes:levitate_timer"));
        data.load(1, entity.loop(20 * Math.PI) + 0.4);
    });
    fireModel.texture.set(null, "fire");
    fire = renderer.createEffect("fiskheroes:model").setModel(fireModel);
    fire.anchor.set("body");
    fire.anchor.ignoreAnchor(true);
    return fire;
}

function createModel(renderer, model) {
    var Model;
    if (model == "faceplate_flip" || model == "faceplate_catch") {
        modelTrue = "faceplate";
        Model = renderer.createResource("MODEL", "sind:mk42/" + modelTrue);
    } else {
        Model = renderer.createResource("MODEL", "sind:mk42/" + model);
    }
    Model.bindAnimation("sind:mk42/" + model).setData((entity, data) => {
        data.load(entity.getInterpolatedData("sind:dyn/mark42_" + model + "_timer"));
    });
    Model.bindAnimation("fiskheroes:flight/iron_man.anim.json").setData((entity, data) => {
        data.load(0, entity.getInterpolatedData("fiskheroes:flight_timer") * (1 - entity.getInterpolatedData("fiskheroes:dyn/superhero_landing_timer")));
        data.load(1, entity.getInterpolatedData("fiskheroes:flight_boost_timer"));
    });
    Model.bindAnimation("fiskheroes:flight/idle/iron_man").setData((entity, data) => {
        data.load(0, entity.getInterpolatedData("fiskheroes:levitate_timer"));
        data.load(1, entity.loop(20 * Math.PI) + 0.4);
    });
    Model.texture.set("split", "split_lights");
    m = renderer.createEffect("fiskheroes:model").setModel(Model);
    m.anchor.set("body");
    m.anchor.ignoreAnchor(true);
    return m;
}
function renderModel(entity, thing, timer, isFirstPersonArm, list) {
    if (list == "Special Case") {
        if (entity.getInterpolatedData(timer) > 0 && entity.getWornChestplate().nbt().getByte("sentry") == 0) {
            if (isFirstPersonArm && (entity.getInterpolatedData("sind:dyn/mark42_faceplate_flip_timer") < 0.7 && entity.getInterpolatedData("sind:dyn/mark42_faceplate_catch_timer") < 0.7)) {
                thing.setOffset(0, 4, 4);
                thing.render();
            } else if (!isFirstPersonArm && entity.getInterpolatedData(timer) < 0.7) {
                thing.setOffset(0, 0, 0);
                thing.render();
            }
        }
    }
    else if (entity.getInterpolatedData(timer) > 0 && entity.getWornChestplate().nbt().getByte("sentry") == 0) {
        if (isFirstPersonArm && !getDatasInList(entity, list, 1)) {
            thing.setOffset(0, 4, 4);
            thing.render();
        } else if (!isFirstPersonArm && entity.getInterpolatedData(timer) < 0.7) {
            thing.setOffset(0, 0, 0);
            thing.render();
        }
    }
}

function renderOverlay(entity, thing, timer, list) {
    if (entity.getInterpolatedData("sind:dyn/hulkbuster_timer") >= 0.984) {
        return;
    }
    if (list == "Special Case") {
        if (entity.getInterpolatedData(timer) >= 0.7 && (entity.getInterpolatedData("sind:dyn/mark42_faceplate_flip_timer") < 1 && entity.getInterpolatedData("sind:dyn/mark42_faceplate_flip_timer") < 1) && entity.getWornChestplate().nbt().getByte("sentry") == 0) {
            thing.render();
        }
    } 
    else if (entity.getInterpolatedData(timer) >= 0.7 && !getDatasInList(entity, list, 1) && entity.getWornChestplate().nbt().getByte("sentry") == 0) {
        thing.render();
    }
}

function getDatasInList(entity, list, time) {
    // if "time" not specified, assumes vars in list are booleans
    if (time == null || time == undefined) {
        for (var i = 0; i < list.length; i++) {
            if (!entity.getData("sind:dyn/mark42_" + list[i])) {
                return false;
            }
        }
    } else {
        for (var i = 0; i < list.length; i++) {
            if (entity.getInterpolatedData("sind:dyn/mark42_" + list[i] + "_timer") != time) {
                return false;
            }
        }
    }
    return true;
}