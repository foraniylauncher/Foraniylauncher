extend("sind:external/iron_man_base");
loadTextures({
    "lights1": "sind:lights/lights_noeyes",
    "suit": "sind:mark5/mark5",
    "briefcase": "sind:mark5/mark5_briefcase",
    "briefcase_eyes": "sind:mark5/mark5_briefcase_eyes",
    "briefcase_reactor": "sind:mark5/mark5_briefcase_reactor",
    "mask": "sind:mark5/mark5_mask.tx.json",
    "chin": "sind:mark5/mark5_chin",

    //jarvis stuff
    "player": "sind:hud/mark5/full",
    "player_mh": "sind:hud/mark5/mh",
    "player0": "sind:null",
    "player1": "sind:hud/mark5/1",
    "player2": "sind:null",
    "player3": "sind:null"
});
var utils = implement("fiskheroes:external/utils");
var iron_man_boosters = implement("sind:external/early_boosters");
var iron_man_utils = implement("sind:external/iron_man_utils");
var repulsor;
var lightsoff;
var boosters;
var helmet, chin;
var metal_heat;
var unibeam;

var briefcaseEyesModel, briefcaseReactorModelLightsOff;
var briefcase, briefcase_eyes, briefcase_reactor, briefcase_reactor_lightsoff, briefcase_hand;

var jarvis = implement("sind:external/jarvis");
var hud;

function init(renderer) {
    parent.init(renderer);
    renderer.setTexture((entity, renderLayer) => {
        if (!entity.is("DISPLAY")) {
            var timer = entity.getInterpolatedData("sind:dyn/another_timer");
            return timer >= 12.6/13 ? "suit" : "null";
        }
        return entity.getData("fiskheroes:mask_open") ? "null" : "suit";
    });

    renderer.setLights((entity, renderLayer) => {
        if (!entity.is("DISPLAY")) {
            var timer = entity.getInterpolatedData("sind:dyn/another_timer");
            return timer >= 12.6/13 && !entity.isInWater() ? (entity.getData('fiskheroes:mask_open_timer') == 0 ? "lights" : "lights1") : "null";
        }
        return entity.getData("fiskheroes:mask_open") ? "null" : "lights";
    });

    renderer.showModel("CHESTPLATE", "rightArm", "leftArm", "body", "head", "leftLeg", "rightLeg");
    renderer.fixHatLayer("CHESTPLATE");
}

function initEffects(renderer) {
    parent.initEffects(renderer);
    repulsor = renderer.createEffect("fiskheroes:overlay");
    unibeam = iron_man_utils.createUnibeam(renderer, 0x8CC4E2, 0, 0, -0.35);
    
    lightsoff = renderer.createEffect("fiskheroes:overlay");

    boosters = iron_man_boosters.create(renderer, "fiskheroes:repulsor_layer_%s", true);

    helmet = iron_man_utils.createFaceplate(renderer, "mask", null);
    chin = iron_man_utils.createChinplate(renderer, "chin", null);

    var briefcaseModel = utils.createModel(renderer, "sind:mk5/briefcase", "briefcase", null);
    briefcaseModel.bindAnimation("sind:mk5_transformation").setData((entity, data) => {
        data.load(entity.getInterpolatedData("sind:dyn/another_timer"));
    });

    briefcase = renderer.createEffect("fiskheroes:model");
    briefcase.setModel(briefcaseModel);
    briefcase.anchor.set("body");
    briefcase.anchor.ignoreAnchor(true);

    briefcaseEyesModel = utils.createModel(renderer, "sind:mk5/briefcase", null, "briefcase_eyes");
    briefcaseEyesModel.bindAnimation("sind:mk5_transformation").setData((entity, data) => {
        data.load(entity.getInterpolatedData("sind:dyn/another_timer"));
    });

    briefcase_eyes = renderer.createEffect("fiskheroes:model");
    briefcase_eyes.setModel(briefcaseEyesModel);
    briefcase_eyes.anchor.set("body");
    briefcase_eyes.anchor.ignoreAnchor(true);

    briefcaseReactorModelLightsOff = utils.createModel(renderer, "sind:mk5/briefcase", "briefcase_reactor", null);
    briefcaseReactorModelLightsOff.bindAnimation("sind:mk5_transformation").setData((entity, data) => {
        data.load(entity.getInterpolatedData("sind:dyn/another_timer"));
    });

    briefcase_reactor_lightsoff = renderer.createEffect("fiskheroes:model");
    briefcase_reactor_lightsoff.setModel(briefcaseReactorModelLightsOff);
    briefcase_reactor_lightsoff.anchor.set("body");
    briefcase_reactor_lightsoff.anchor.ignoreAnchor(true);

    var briefcaseReactorModel = utils.createModel(renderer, "sind:mk5/briefcase", null, "briefcase_reactor");
    briefcaseReactorModel.bindAnimation("sind:mk5_transformation").setData((entity, data) => {
        data.load(entity.getInterpolatedData("sind:dyn/another_timer"));
    });

    briefcase_reactor = renderer.createEffect("fiskheroes:model");
    briefcase_reactor.setModel(briefcaseReactorModel);
    briefcase_reactor.anchor.set("body");
    briefcase_reactor.anchor.ignoreAnchor(true);

    var briefcaseHandModel = utils.createModel(renderer, "sind:mk5/briefcase_hand", "briefcase", null);
    briefcaseHandModel.bindAnimation("sind:mk5_transformation").setData((entity, data) => {
        data.load(entity.getInterpolatedData("sind:dyn/another_timer"));
    });

    briefcase_hand = renderer.createEffect("fiskheroes:model");
    briefcase_hand.setModel(briefcaseHandModel);
    briefcase_hand.anchor.set("rightArm");
    briefcase_hand.setOffset(-5, -2, 0);

    utils.bindParticles(renderer, "sind:early_suits").setCondition(entity => entity.getData("fiskheroes:flying"));

    utils.bindBeam(renderer, "fiskheroes:charged_beam", "sind:unibeam", "body", 0xFFC462, [{
                "firstPerson": [0, 6, -3],
                "offset": [0, 2.75, -3],
                "size": [1.5, 1.5]
            }
        ]).setParticles(renderer.createResource("PARTICLE_EMITTER", "fiskheroes:impact_energy_projection"));

    metal_heat = renderer.createEffect("fiskheroes:metal_heat");
    metal_heat.includeEffects(helmet.effect, chin.effect);

    hud = jarvis.create(renderer, utils, "jarvis", 0x59D7FF);
}

function initAnimations(renderer) {
    parent.initAnimations(renderer);
    addAnimation(renderer, "mk5", "sind:mk5_transformation").setCondition(entity => entity.getInterpolatedData("sind:dyn/another_timer") < 1)
        .setData((entity, data) => data.load(entity.getInterpolatedData("sind:dyn/another_timer")));

    addAnimation(renderer, "sind.NOTHING", "sind:cancel").setData((entity, data) => {
        data.load(entity.getInterpolatedData("sind:dyn/tentacles_timer"));
    }).priority = -11;
    
    addAnimation(renderer, "armbeGONE", "fiskheroes:ocular_beam").setData((entity, data) => {
        data.load(entity.getInterpolatedData("sind:dyn/tentacles_timer"));
    }).priority = -11;
}

function render(entity, renderLayer, isFirstPersonArm) {
    boosters.render(entity, renderLayer, isFirstPersonArm, true);
    if (!isFirstPersonArm) {
        if (entity.getInterpolatedData("sind:dyn/another_timer") >= 12.6/13) {
            chin.render(entity.getInterpolatedData("fiskheroes:mask_open_timer2"));
            helmet.render(entity.getInterpolatedData("fiskheroes:mask_open_timer2"));
        }

        repulsor.opacity = Math.max(Math.min(entity.getInterpolatedData("fiskheroes:aimed_timer") * 2, 1), entity.getInterpolatedData("fiskheroes:dyn/booster_r_timer"));
        repulsor.texture.set(null, "repulsor");
        repulsor.render();
        repulsor.opacity = entity.getInterpolatedData("fiskheroes:dyn/booster_l_timer");
        repulsor.texture.set(null, "repulsor_left");
        repulsor.render();

        repulsor.opacity = entity.getInterpolatedData("fiskheroes:dyn/booster_timer");
        repulsor.texture.set(null, "repulsor_boots");
        repulsor.render();
    }
    if (entity.getInterpolatedData("sind:dyn/another_timer") < 2/13) {
        if (isFirstPersonArm) {
            if (entity.getInterpolatedData("sind:dyn/another_timer") < 1.2/13) {
                briefcase_hand.render();
            }
        } else if (entity.is("DISPLAY") ? entity.getData("fiskheroes:mask_open") : true) {
            briefcase_hand.render();
        }
    } else if (entity.getInterpolatedData("sind:dyn/another_timer") < 12.6/13) {
        briefcase.setOffset(0, 4*isFirstPersonArm, 4*isFirstPersonArm);
        briefcase.render();

        if (entity.getInterpolatedData("sind:dyn/another_timer") < 9/13) {
            var eq = clamp((52/3 * entity.getInterpolatedData("sind:dyn/another_timer")) - 11, 0, 1);
            briefcase_reactor.opacity = eq;
            briefcase_reactor.setOffset(0, 4*isFirstPersonArm, 4*isFirstPersonArm);
            briefcase_reactor.render();

            briefcaseReactorModelLightsOff.texture.set("briefcase_reactor");
        } else {
            briefcaseReactorModelLightsOff.texture.set(null, "briefcase_reactor");
        }
        briefcase_reactor_lightsoff.setOffset(0, 4*isFirstPersonArm, 4*isFirstPersonArm);
        briefcase_reactor_lightsoff.render();

        if (entity.getInterpolatedData("sind:dyn/another_timer") < 12/13) {
            briefcaseEyesModel.texture.set("briefcase_eyes");
        } else {
            briefcaseEyesModel.texture.set(null, "briefcase_eyes");
        }
        briefcase_eyes.setOffset(0, 4*isFirstPersonArm, 4*isFirstPersonArm);
        briefcase_eyes.render();
    }
    if (entity.isInWater() && entity.getInterpolatedData("sind:dyn/another_timer") >= 12.6/13) {
        if (entity.getData("fiskheroes:mask_open_timer") > 0) {
            lightsoff.texture.set("lights_noeyes");
        } else {
            lightsoff.texture.set("lights");
        }
        lightsoff.render();
    }
    unibeam.render(entity, isFirstPersonArm);
    hud.render(entity, renderLayer, isFirstPersonArm);

    if (!entity.getData("fiskheroes:mask_open") && entity.is("DISPLAY")) {
        helmet.render(0);
        chin.render(0);
    }

    metal_heat.opacity = entity.getInterpolatedData("fiskheroes:metal_heat");
    metal_heat.render();
}

function clamp(value, min, max) {
    return Math.min(Math.max(value, min), max);
}