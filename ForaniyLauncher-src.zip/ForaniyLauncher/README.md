# ForaniyLauncher

Лаунчер Minecraft Java Edition для Android в фиолетовом стиле. Экраны: Играть / Сборки / Каталог / Аккаунты / Настройки.

## Что работает
- Выбор режима входа: официальный Microsoft или офлайн по нику (Microsoft не обязателен).
- Сборки (версия + Vanilla/Fabric), скачивание версий Mojang с проверкой SHA-1.
- Каталог Modrinth: моды (с обязательными зависимостями), шейдеры, текстуры.
- Установка Java по вашей ссылке на архив, настройки ОЗУ, Java, папки игры.
- Автозаход на сервер (`host[:port]`) для сборки.

## Важные ограничения (честно)
1. **Офлайн-режим по нику не означает, что любой сервер вас пустит.** Серверы с `online-mode=true` требуют лицензионный аккаунт. Авторизация не обходится.
2. **Картинка игры на экране** требует графического бэкенда (OpenGL-мост). Сейчас `ProcessLaunchBackend` запускает Java как процесс без дисплея. Точка расширения: `minecraft/LaunchBackend.kt`. См. `docs/ARCHITECTURE.md`.
3. **Java** должна быть собрана под Android. Готовых ссылок в приложении нет, вы вставляете свою.
4. **Вход через Microsoft** нужен собственный Azure client ID (`msClientId`); для Minecraft-сервисов приложение Azure должно быть одобрено Mojang (иначе 403 на login_with_xbox).

## Сборка APK
Нужны JDK 17+, Android SDK (platform 35) и доступ к Google Maven / Maven Central / Gradle.

```
./gradlew assembleDebug -PmsClientId=<AZURE_CLIENT_ID>   # clientId необязателен
# результат: app/build/outputs/apk/debug/app-debug.apk
```
Либо откройте папку в Android Studio (Ladybug+), либо загрузите проект на GitHub: `.github/workflows/build-apk.yml` соберёт APK и приложит его как artifact (секрет `MS_CLIENT_ID` необязателен).

Проект ещё ни разу не компилировался: возможны мелкие ошибки компиляции, исправляйте по сообщениям Gradle.
