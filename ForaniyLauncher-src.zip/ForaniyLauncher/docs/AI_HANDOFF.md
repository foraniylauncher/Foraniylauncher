# Для следующего ИИ/разработчика
1. Сначала соберите проект (`./gradlew assembleDebug`) и исправьте возможные ошибки компиляции: код писался без компилятора.
2. Структура и потоки: `docs/ARCHITECTURE.md`. Иконки генерируются `tools/generate_icons.py` (источник истины), дизайн-ассеты `tools/generate_design.py`.
3. Новые экраны: `ui/<name>/` (Screen + ViewModel), регистрация в `ui/Screen.kt` и `ui/AppRoot.kt`.
4. Следующие шаги: (a) графический `LaunchBackend`; (b) выбор папки через SAF; (c) релизная подпись; (d) тесты для `VersionJson`, `LaunchCommandBuilder`, `ServerAddress`.
5. Не хардкодить ссылки на Java; не обходить авторизацию серверов.
