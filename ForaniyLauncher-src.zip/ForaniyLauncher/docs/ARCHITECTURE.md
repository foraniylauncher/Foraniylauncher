# Архитектура

Пакет `ru.foraniy.launcher`. Слои зависят только вниз: `ui -> auth/catalog/minecraft -> data -> core/domain`.

| Слой | Путь | Роль |
|---|---|---|
| core | `core/` | Http (повторы, загрузка), Json, Files/Hashing, SecretBox (Android Keystore AES-GCM), LauncherPaths, ошибки |
| domain | `domain/Models.kt` | Account, Build, LauncherSettings, enum'ы. Без Android |
| data | `data/` | Settings/Accounts/Builds репозитории (JSON, StateFlow), PathsProvider |
| minecraft | `minecraft/` | манифест Mojang, VersionJson (rules, inheritsFrom), GameInstaller, FabricMeta, LaunchCommandBuilder, JavaRuntimeManager, LaunchBackend, LaunchService |
| auth | `auth/` | OfflineAuth, MicrosoftAuth (device code -> Xbox -> XSTS -> Minecraft), AccountManager |
| catalog | `catalog/` | Modrinth API v2, ContentInstaller |
| ui | `ui/` | Compose: theme, components, экраны + ViewModel'и |

DI вручную: `AppContainer`. ViewModel'и создаются через `appViewModel { }` (Activity-scope).

## Поток запуска
Play -> `LaunchService.launch(build, account)` -> resolve версии -> GameInstaller (параллельно, SHA-1) -> Fabric (если нужен) -> Java (`JavaRuntimeManager.resolve`) -> `LaunchCommandBuilder` -> `LaunchBackend.start`. `LaunchService` живёт в `appScope`, поэтому загрузки не прерываются при смене экрана.

## Офлайн-режим
UUID = `UUID.nameUUIDFromBytes("OfflinePlayer:<name>")`, token `0`, user_type `legacy`. Автозаход: `--quickPlayMultiplayer` (новые версии) или `--server/--port` (старые).

## Что не реализовано и что менять
**Отображение игры на Android.** Нужен `LaunchBackend` с in-process JVM и мостом GLFW->EGL/OpenGL ES (подход PojavLauncher/MobileGlues), нативные библиотеки LWJGL под arm64 и обработка ввода. Интерфейс `LaunchBackend` уже изолирует эту часть: достаточно реализовать его и подставить в `AppContainer.backend`. Natives сейчас пропускаются (ожидается, что их даёт бэкенд).
