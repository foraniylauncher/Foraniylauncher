# Дизайн
Минимализм, тёмный фон `#0B0714`, акцент фиолетовый `#A855F7` (свечение `#C084FC`, глубокий `#7C3AED`). Токены: `design/tokens.json` и `ui/theme/Color.kt`.
Шрифты (концепт): Manrope (заголовки), Inter (текст), JetBrains Mono (логи).
Ассеты: `design/logo`, `design/icons` (29 иконок + `_sheet.svg`), `design/backgrounds`, `design/ui-kit`.
