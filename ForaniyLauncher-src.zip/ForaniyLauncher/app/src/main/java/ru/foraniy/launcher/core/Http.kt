package ru.foraniy.launcher.core

import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.delay
import kotlinx.coroutines.ensureActive
import kotlinx.coroutines.withContext
import org.json.JSONException
import org.json.JSONObject
import java.io.File
import java.io.IOException
import java.net.HttpURLConnection
import java.net.URL
import java.net.URLEncoder

class HttpException(val code: Int, val url: String, val body: String) :
    IOException("HTTP $code: ${url.substringBefore('?')}")

/** Result of a request. Never thrown for HTTP errors: callers decide (auth flows need the error body). */
class HttpResult(val url: String, val code: Int, val body: String) {
    val ok: Boolean get() = code in 200..299

    fun requireOk(): HttpResult {
        if (!ok) throw HttpException(code, url, body)
        return this
    }

    fun json(): JSONObject = try {
        JSONObject(body)
    } catch (e: JSONException) {
        JSONObject()
    }
}

/** Minimal HTTP client on HttpURLConnection. All functions are main-safe and cancellable. */
object Http {
    const val USER_AGENT = "ForaniyLauncher/0.1.0 (Android)"
    private const val CONNECT_TIMEOUT_MS = 15_000
    private const val READ_TIMEOUT_MS = 30_000

    fun enc(s: String): String = URLEncoder.encode(s, "UTF-8")

    suspend fun get(url: String, headers: Map<String, String> = emptyMap()): HttpResult =
        withContext(Dispatchers.IO) { execute("GET", url, headers, null, null) }

    suspend fun postJson(url: String, body: JSONObject, headers: Map<String, String> = emptyMap()): HttpResult =
        withContext(Dispatchers.IO) {
            execute(
                "POST", url, headers + ("Accept" to "application/json"),
                body.toString().toByteArray(Charsets.UTF_8), "application/json",
            )
        }

    suspend fun postForm(url: String, form: Map<String, String>, headers: Map<String, String> = emptyMap()): HttpResult {
        val encoded = form.entries.joinToString("&") { enc(it.key) + "=" + enc(it.value) }
        return withContext(Dispatchers.IO) {
            execute("POST", url, headers, encoded.toByteArray(Charsets.UTF_8), "application/x-www-form-urlencoded")
        }
    }

    private fun execute(
        method: String,
        url: String,
        headers: Map<String, String>,
        body: ByteArray?,
        contentType: String?,
    ): HttpResult {
        val conn = URL(url).openConnection() as HttpURLConnection
        try {
            conn.requestMethod = method
            conn.connectTimeout = CONNECT_TIMEOUT_MS
            conn.readTimeout = READ_TIMEOUT_MS
            conn.instanceFollowRedirects = true
            conn.setRequestProperty("User-Agent", USER_AGENT)
            for ((k, v) in headers) conn.setRequestProperty(k, v)
            if (body != null) {
                conn.doOutput = true
                if (contentType != null) conn.setRequestProperty("Content-Type", contentType)
                conn.outputStream.use { it.write(body) }
            }
            val code = conn.responseCode
            val stream = if (code in 200..299) conn.inputStream else conn.errorStream
            val text = stream?.bufferedReader(Charsets.UTF_8)?.use { it.readText() } ?: ""
            return HttpResult(url, code, text)
        } finally {
            conn.disconnect()
        }
    }

    /**
     * Downloads [url] to [target] via a ".part" file (atomic), optionally verifying SHA-1, with 3 attempts.
     * [onLength] gets Content-Length when known, [onBytes] gets every chunk size (called on the IO thread).
     */
    suspend fun download(
        url: String,
        target: File,
        sha1: String? = null,
        onLength: (Long) -> Unit = {},
        onBytes: (Long) -> Unit = {},
    ) = withContext(Dispatchers.IO) {
        target.parentFile?.mkdirs()
        val tmp = File(target.path + ".part")
        var attempt = 0
        while (true) {
            try {
                val conn = URL(url).openConnection() as HttpURLConnection
                try {
                    conn.connectTimeout = CONNECT_TIMEOUT_MS
                    conn.readTimeout = READ_TIMEOUT_MS
                    conn.instanceFollowRedirects = true
                    conn.setRequestProperty("User-Agent", USER_AGENT)
                    val code = conn.responseCode
                    if (code !in 200..299) throw HttpException(code, url, "")
                    val len = conn.contentLengthLong
                    if (len > 0) onLength(len)
                    conn.inputStream.use { input ->
                        tmp.outputStream().use { out ->
                            val buf = ByteArray(64 * 1024)
                            while (true) {
                                ensureActive()
                                val n = input.read(buf)
                                if (n < 0) break
                                out.write(buf, 0, n)
                                onBytes(n.toLong())
                            }
                        }
                    }
                } finally {
                    conn.disconnect()
                }
                if (sha1 != null && !Hashing.sha1(tmp).equals(sha1, ignoreCase = true)) {
                    throw IOException("Контрольная сумма не совпала: ${url.substringAfterLast('/')}")
                }
                if (!tmp.renameTo(target)) {
                    tmp.copyTo(target, overwrite = true)
                    tmp.delete()
                }
                return@withContext
            } catch (e: CancellationException) {
                tmp.delete()
                throw e
            } catch (e: IOException) {
                tmp.delete()
                if (e is HttpException && e.code in 400..499) throw e
                attempt++
                if (attempt >= 3) throw e
                delay(400L * attempt)
            }
        }
    }
}
