package ru.foraniy.launcher.ui.theme

import androidx.compose.runtime.Immutable
import androidx.compose.runtime.staticCompositionLocalOf
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.lerp

// Design tokens: keep in sync with design/tokens.json.
val FxBg = Color(0xFF0B0714)
val FxSurface = Color(0xFF130D21)
val FxSurface2 = Color(0xFF1B1230)
val FxSurface3 = Color(0xFF241A3D)
val FxOutline = Color(0xFF2A1F45)
val FxOutlineStrong = Color(0xFF3B2D63)
val FxPrimary = Color(0xFFA855F7)
val FxGlow = Color(0xFFC084FC)
val FxDeep = Color(0xFF7C3AED)
val FxSoft = Color(0xFFE9D5FF)
val FxText = Color(0xFFF3EEFF)
val FxMuted = Color(0xFF9A8FB8)
val FxFaint = Color(0xFF6B6188)
val FxSuccess = Color(0xFF4ADE80)
val FxWarning = Color(0xFFFBBF24)
val FxDanger = Color(0xFFFB7185)
val FxInfo = Color(0xFF60A5FA)

/** The user-selectable accent (Settings -> Appearance). Everything "neon" derives from it. */
@Immutable
class AccentColors(val main: Color, val glow: Color, val deep: Color) {
    companion object {
        fun from(main: Color) = AccentColors(
            main = main,
            glow = lerp(main, Color.White, 0.25f),
            deep = lerp(main, Color.Black, 0.30f),
        )
    }
}

class AccentPreset(val name: String, val color: Color)

val AccentPresets = listOf(
    AccentPreset("Фиолетовый", Color(0xFFA855F7)),
    AccentPreset("Индиго", Color(0xFF818CF8)),
    AccentPreset("Маджента", Color(0xFFE879F9)),
    AccentPreset("Орхидея", Color(0xFFC084FC)),
    AccentPreset("Циан", Color(0xFF22D3EE)),
)

val LocalAccent = staticCompositionLocalOf { AccentColors.from(FxPrimary) }

/** Cover gradients for builds and avatars: (light, dark). */
val CoverPalette = listOf(
    Color(0xFFA855F7) to Color(0xFF4C1D95),
    Color(0xFF818CF8) to Color(0xFF3730A3),
    Color(0xFFE879F9) to Color(0xFF86198F),
    Color(0xFFC084FC) to Color(0xFF6D28D9),
    Color(0xFF22D3EE) to Color(0xFF0E7490),
    Color(0xFFF472B6) to Color(0xFF9D174D),
)
