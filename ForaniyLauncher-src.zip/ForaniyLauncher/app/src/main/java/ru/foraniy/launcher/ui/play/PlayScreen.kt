package ru.foraniy.launcher.ui.play

import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.selection.SelectionContainer
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.platform.LocalClipboardManager
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.AnnotatedString
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import ru.foraniy.launcher.AppContainer
import ru.foraniy.launcher.R
import ru.foraniy.launcher.domain.Account
import ru.foraniy.launcher.domain.AccountType
import ru.foraniy.launcher.domain.Build
import ru.foraniy.launcher.domain.LoaderType
import ru.foraniy.launcher.minecraft.LaunchState
import ru.foraniy.launcher.minecraft.ServerAddress
import ru.foraniy.launcher.ui.Screen
import ru.foraniy.launcher.ui.accounts.AuthChoicePanel
import ru.foraniy.launcher.ui.appViewModel
import ru.foraniy.launcher.ui.components.ButtonKind
import ru.foraniy.launcher.ui.components.ForaniyButton
import ru.foraniy.launcher.ui.components.ForaniyDialog
import ru.foraniy.launcher.ui.components.ForaniyProgressBar
import ru.foraniy.launcher.ui.components.ForaniySheetDialog
import ru.foraniy.launcher.ui.components.ForaniyTextField
import ru.foraniy.launcher.ui.components.Avatar
import ru.foraniy.launcher.ui.components.HintText
import ru.foraniy.launcher.ui.components.NoticeBox
import ru.foraniy.launcher.ui.components.Panel
import ru.foraniy.launcher.ui.components.StatusPill
import ru.foraniy.launcher.ui.formatAgo
import ru.foraniy.launcher.ui.formatSpeed
import ru.foraniy.launcher.ui.theme.CoverPalette
import ru.foraniy.launcher.ui.theme.ForaniyFonts
import ru.foraniy.launcher.ui.theme.FxDanger
import ru.foraniy.launcher.ui.theme.FxGlow
import ru.foraniy.launcher.ui.theme.FxInfo
import ru.foraniy.launcher.ui.theme.FxMuted
import ru.foraniy.launcher.ui.theme.FxOutline
import ru.foraniy.launcher.ui.theme.FxSoft
import ru.foraniy.launcher.ui.theme.FxSuccess
import ru.foraniy.launcher.ui.theme.FxSurface2
import ru.foraniy.launcher.ui.theme.FxText
import ru.foraniy.launcher.ui.theme.FxWarning
import ru.foraniy.launcher.ui.theme.LocalAccent

@Composable
fun PlayScreen(container: AppContainer, onNavigate: (Screen) -> Unit) {
    val vm = appViewModel { PlayViewModel(container) }
    val builds by vm.builds.collectAsStateWithLifecycle()
    val accounts by vm.accounts.collectAsStateWithLifecycle()
    val settings by vm.settings.collectAsStateWithLifecycle()
    val launch by vm.launchState.collectAsStateWithLifecycle()
    val log by vm.log.collectAsStateWithLifecycle()

    val build = builds.firstOrNull { it.id == settings.selectedBuildId } ?: builds.firstOrNull()
    val account = accounts.firstOrNull { it.id == settings.selectedAccountId } ?: accounts.firstOrNull()

    var showLog by remember { mutableStateOf(false) }
    var showBuildPicker by remember { mutableStateOf(false) }
    var showServer by remember { mutableStateOf(false) }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .verticalScroll(rememberScrollState())
            .padding(horizontal = 20.dp, vertical = 12.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp),
    ) {
        Header(account) { onNavigate(Screen.ACCOUNTS) }

        when {
            account == null -> {
                Text(
                    "Выберите, как войти в игру. Это нужно один раз.",
                    style = MaterialTheme.typography.bodyMedium,
                    color = FxMuted,
                )
                AuthChoicePanel(container)
            }

            build == null -> Panel(Modifier.fillMaxWidth()) {
                Text("Создайте первую сборку", style = MaterialTheme.typography.titleMedium, color = FxText)
                Spacer(Modifier.height(4.dp))
                Text(
                    "Сборка это версия Minecraft со своей папкой игры, модами и настройками.",
                    style = MaterialTheme.typography.bodyMedium,
                    color = FxMuted,
                )
                Spacer(Modifier.height(16.dp))
                ForaniyButton("Создать сборку", { onNavigate(Screen.BUILDS) }, Modifier.fillMaxWidth(), icon = R.drawable.ic_plus)
            }

            else -> HeroCard(
                build = build,
                account = account,
                launch = launch,
                onPlay = { vm.play(build, account) },
                onCancel = vm::cancel,
                onDismiss = vm::dismissResult,
                onShowLog = { showLog = true },
                onPickBuild = { showBuildPicker = true },
                onServer = { showServer = true },
                onOpenSettings = { onNavigate(Screen.SETTINGS) },
            )
        }
        Spacer(Modifier.height(8.dp))
    }

    if (showLog) LogDialog(log) { showLog = false }

    if (showBuildPicker) {
        ForaniySheetDialog(title = "Выбор сборки", onDismiss = { showBuildPicker = false }) {
            if (builds.isEmpty()) {
                Text("Сборок пока нет.", color = FxMuted)
            }
            builds.forEach { b ->
                Panel(
                    Modifier.fillMaxWidth(),
                    onClick = {
                        vm.selectBuild(b.id)
                        showBuildPicker = false
                    },
                    selected = b.id == build?.id,
                ) {
                    Text(b.name, style = MaterialTheme.typography.titleMedium, color = FxText, maxLines = 1, overflow = TextOverflow.Ellipsis)
                    Text(buildSubtitle(b), style = MaterialTheme.typography.bodySmall, color = FxMuted)
                }
            }
        }
    }

    if (showServer && build != null) {
        ServerDialog(
            current = build.serverAddress,
            offline = account?.type == AccountType.OFFLINE,
            onSave = {
                vm.setServer(build, it)
                showServer = false
            },
            onDismiss = { showServer = false },
        )
    }
}

private fun buildSubtitle(b: Build): String {
    val loader = if (b.loader == LoaderType.FABRIC) " · Fabric" + (b.loaderVersion?.let { " $it" } ?: "") else ""
    return "Minecraft ${b.mcVersion}$loader"
}

@Composable
private fun Header(account: Account?, onAccount: () -> Unit) {
    Row(Modifier.fillMaxWidth().padding(top = 4.dp), verticalAlignment = Alignment.CenterVertically) {
        Image(painterResource(R.drawable.ic_logo_mark), contentDescription = null, modifier = Modifier.height(36.dp))
        Spacer(Modifier.width(10.dp))
        Row(Modifier.weight(1f)) {
            Text("Foraniy", style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.ExtraBold, color = FxText)
            Text("Launcher", style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.Light, color = FxGlow)
        }
        Row(
            modifier = Modifier
                .clip(RoundedCornerShape(24.dp))
                .background(FxSurface2)
                .border(1.dp, FxOutline, RoundedCornerShape(24.dp))
                .clickable(onClick = onAccount)
                .padding(start = 6.dp, end = 14.dp, top = 6.dp, bottom = 6.dp),
            verticalAlignment = Alignment.CenterVertically,
        ) {
            if (account != null) {
                Avatar(account.name, size = 28)
                Spacer(Modifier.width(8.dp))
                Text(account.name, style = MaterialTheme.typography.labelLarge, color = FxText, maxLines = 1, overflow = TextOverflow.Ellipsis, modifier = Modifier.widthIn(max = 120.dp))
            } else {
                Spacer(Modifier.width(8.dp))
                Text("Войти", style = MaterialTheme.typography.labelLarge, color = FxSoft)
            }
        }
    }
}

@Composable
private fun HeroCard(
    build: Build,
    account: Account,
    launch: LaunchState,
    onPlay: () -> Unit,
    onCancel: () -> Unit,
    onDismiss: () -> Unit,
    onShowLog: () -> Unit,
    onPickBuild: () -> Unit,
    onServer: () -> Unit,
    onOpenSettings: () -> Unit,
) {
    val server = ServerAddress.parse(build.serverAddress)

    Panel(Modifier.fillMaxWidth(), contentPadding = androidx.compose.foundation.layout.PaddingValues(18.dp)) {
        // build title
        Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(14.dp)) {
            val (light, dark) = CoverPalette[build.coverIndex.mod(CoverPalette.size)]
            Box(
                Modifier
                    .size(60.dp)
                    .clip(RoundedCornerShape(18.dp))
                    .background(Brush.linearGradient(listOf(light, dark))),
                contentAlignment = Alignment.Center,
            ) {
                Icon(painterResource(R.drawable.ic_builds), null, Modifier.size(30.dp), tint = androidx.compose.ui.graphics.Color.White)
            }
            Column(Modifier.weight(1f)) {
                Text(build.name, style = MaterialTheme.typography.titleLarge, color = FxText, maxLines = 1, overflow = TextOverflow.Ellipsis)
                Text(buildSubtitle(build), style = MaterialTheme.typography.bodyMedium, color = FxMuted)
                Text(formatAgo(build.lastPlayedAtMs), style = MaterialTheme.typography.bodySmall, color = FxMuted)
            }
        }

        Spacer(Modifier.height(14.dp))

        // account
        Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            Text("Играете как", style = MaterialTheme.typography.bodySmall, color = FxMuted)
            Text(account.name, style = MaterialTheme.typography.labelLarge, color = FxText, maxLines = 1, overflow = TextOverflow.Ellipsis, modifier = Modifier.weight(1f, fill = false))
            if (account.type == AccountType.MICROSOFT) StatusPill("Microsoft", FxSuccess) else StatusPill("Офлайн", FxWarning)
        }

        Spacer(Modifier.height(10.dp))

        // server
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .clip(RoundedCornerShape(14.dp))
                .background(FxSurface2)
                .clickable(onClick = onServer)
                .padding(horizontal = 14.dp, vertical = 12.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.spacedBy(10.dp),
        ) {
            Icon(painterResource(R.drawable.ic_external), null, Modifier.size(20.dp), tint = FxGlow)
            Column(Modifier.weight(1f)) {
                Text("Сервер для автозахода", style = MaterialTheme.typography.bodySmall, color = FxMuted)
                Text(
                    server?.display ?: "Не задан. Нажмите, чтобы указать",
                    style = MaterialTheme.typography.labelLarge,
                    color = if (server != null) FxText else FxMuted,
                    maxLines = 1,
                    overflow = TextOverflow.Ellipsis,
                )
            }
            Icon(painterResource(R.drawable.ic_chevron_right), null, Modifier.size(20.dp), tint = FxMuted)
        }
        if (server != null && account.type == AccountType.OFFLINE) {
            HintText("Офлайн-ник: сервер пустит вас, только если сам разрешает вход без лицензии.", color = FxWarning)
        }

        Spacer(Modifier.height(18.dp))

        // main action, depends on the launch state
        when (launch) {
            LaunchState.Idle -> ForaniyButton("Играть", onPlay, Modifier.fillMaxWidth(), icon = R.drawable.ic_play, height = 60.dp)

            is LaunchState.Working -> {
                Text(launch.label, style = MaterialTheme.typography.labelLarge, color = FxText)
                Spacer(Modifier.height(10.dp))
                ForaniyProgressBar(launch.fraction)
                Spacer(Modifier.height(6.dp))
                val extra = buildString {
                    launch.fraction?.let { append("${(it * 100).toInt()}%") }
                    val speed = formatSpeed(launch.bytesPerSecond)
                    if (speed.isNotEmpty()) append("  ·  $speed")
                }
                if (extra.isNotEmpty()) Text(extra, style = MaterialTheme.typography.bodySmall, color = FxMuted)
                Spacer(Modifier.height(14.dp))
                ForaniyButton("Отмена", onCancel, Modifier.fillMaxWidth(), kind = ButtonKind.Outline, height = 48.dp)
            }

            is LaunchState.Running -> {
                Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    Box(Modifier.size(10.dp).clip(CircleShape).background(FxSuccess))
                    Text("Игра запущена", style = MaterialTheme.typography.labelLarge, color = FxText)
                }
                Spacer(Modifier.height(8.dp))
                NoticeBox(
                    "Лаунчер запустил Java-процесс. Чтобы картинка игры появилась на экране телефона, нужен " +
                        "графический мост OpenGL (см. docs/ARCHITECTURE.md). Ход запуска смотрите в логе.",
                    FxInfo,
                )
                Spacer(Modifier.height(12.dp))
                ForaniyButton("Остановить", onCancel, Modifier.fillMaxWidth(), kind = ButtonKind.Danger, icon = R.drawable.ic_stop, height = 52.dp)
            }

            is LaunchState.Finished -> {
                val ok = launch.exitCode == 0
                Text(
                    if (ok) "Игра завершилась" else "Игра завершилась с ошибкой (код ${launch.exitCode})",
                    style = MaterialTheme.typography.labelLarge,
                    color = if (ok) FxSuccess else FxDanger,
                )
                Spacer(Modifier.height(12.dp))
                Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                    ForaniyButton("Лог", onShowLog, Modifier.weight(1f), kind = ButtonKind.Tonal, icon = R.drawable.ic_terminal, height = 48.dp)
                    ForaniyButton("Готово", onDismiss, Modifier.weight(1f), height = 48.dp)
                }
            }

            is LaunchState.Failed -> {
                NoticeBox(launch.message, FxDanger)
                Spacer(Modifier.height(12.dp))
                if (launch.needJava != null) {
                    ForaniyButton("Настроить Java ${launch.needJava}", onOpenSettings, Modifier.fillMaxWidth(), icon = R.drawable.ic_java, height = 52.dp)
                    Spacer(Modifier.height(10.dp))
                }
                Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                    ForaniyButton("Лог", onShowLog, Modifier.weight(1f), kind = ButtonKind.Tonal, icon = R.drawable.ic_terminal, height = 48.dp)
                    ForaniyButton("Закрыть", onDismiss, Modifier.weight(1f), kind = ButtonKind.Outline, height = 48.dp)
                }
            }
        }

        if (launch == LaunchState.Idle) {
            Spacer(Modifier.height(12.dp))
            Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                ForaniyButton("Сменить сборку", onPickBuild, Modifier.weight(1f), kind = ButtonKind.Tonal, icon = R.drawable.ic_builds, height = 48.dp)
                ForaniyButton("Лог", onShowLog, Modifier.weight(1f), kind = ButtonKind.Tonal, icon = R.drawable.ic_terminal, height = 48.dp)
            }
        }
    }
}

@Composable
private fun ServerDialog(current: String, offline: Boolean, onSave: (String) -> Unit, onDismiss: () -> Unit) {
    var text by remember { mutableStateOf(current) }
    val valid = text.isBlank() || ServerAddress.parse(text) != null

    ForaniyDialog(
        title = "Сервер для автозахода",
        onDismiss = onDismiss,
        confirmText = "Сохранить",
        onConfirm = { onSave(text) },
        confirmEnabled = valid,
        dismissText = "Отмена",
    ) {
        Text(
            "После запуска игра сама подключится к этому серверу. Оставьте поле пустым, чтобы заходить в меню игры.",
            style = MaterialTheme.typography.bodyMedium,
            color = FxMuted,
        )
        ForaniyTextField(
            value = text,
            onValueChange = { text = it },
            label = "Адрес сервера",
            isError = !valid,
            supportingText = if (valid) "Например: play.example.com или 1.2.3.4:25566" else "Формат: адрес или адрес:порт",
        )
        if (offline) {
            NoticeBox(
                "Вы играете по нику. Серверы с лицензионной проверкой такой вход отклонят. " +
                    "Зайти получится только туда, где вход без лицензии разрешён владельцем сервера.",
                FxWarning,
            )
        }
    }
}

@Composable
private fun LogDialog(lines: List<String>, onDismiss: () -> Unit) {
    val clipboard = LocalClipboardManager.current
    val text = if (lines.isEmpty()) "Пока пусто. Лог появится после запуска." else lines.joinToString("\n")
    ForaniyDialog(
        title = "Лог запуска",
        onDismiss = onDismiss,
        confirmText = "Копировать",
        onConfirm = {
            clipboard.setText(AnnotatedString(text))
            onDismiss()
        },
    ) {
        SelectionContainer {
            Text(text, fontFamily = ForaniyFonts.mono, fontSize = 11.sp, lineHeight = 15.sp, color = FxSoft)
        }
    }
}
