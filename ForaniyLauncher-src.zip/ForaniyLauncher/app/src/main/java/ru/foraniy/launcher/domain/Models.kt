package ru.foraniy.launcher.domain

/** Plain data models shared by all layers. No Android or UI imports here. */

enum class AccountType { OFFLINE, MICROSOFT }

/**
 * A player account. For OFFLINE only [name]/[uuid] matter.
 * For MICROSOFT the tokens are kept in memory decrypted and stored encrypted (see SecretBox).
 */
data class Account(
    val id: String,
    val type: AccountType,
    val name: String,
    val uuid: String,
    val msRefreshToken: String = "",
    val mcAccessToken: String = "",
    val mcExpiresAtMs: Long = 0L,
)

enum class LoaderType(val label: String, val modrinthName: String?) {
    VANILLA("Vanilla", null),
    FABRIC("Fabric", "fabric"),
}

/** A "build" (instance): one Minecraft version + loader with its own game folder, like in Millida/Prism. */
data class Build(
    val id: String,
    val name: String,
    val mcVersion: String,
    val loader: LoaderType = LoaderType.VANILLA,
    val loaderVersion: String? = null,
    /** null = use the global RAM setting. */
    val ramMb: Int? = null,
    /** null/blank = automatic Java selection. */
    val javaPath: String? = null,
    val extraJvmArgs: String = "",
    /**
     * Optional "host[:port]" the game joins right after start. An OFFLINE account only works on servers that
     * allow it (online-mode=false); servers that check licenses will refuse it, and that is by design.
     */
    val serverAddress: String = "",
    val createdAtMs: Long = 0L,
    val lastPlayedAtMs: Long = 0L,
    val coverIndex: Int = 0,
)

enum class JavaMode { AUTO, CUSTOM }

data class LauncherSettings(
    val ramMb: Int = 2048,
    val javaMode: JavaMode = JavaMode.AUTO,
    val customJavaPath: String = "",
    /** Java major version -> URL of a .zip / .tar.gz runtime archive the user provided. */
    val runtimeUrls: Map<Int, String> = emptyMap(),
    /** Blank = default folder. */
    val gameRootOverride: String = "",
    val accentIndex: Int = 0,
    val showSnapshots: Boolean = false,
    val showOldVersions: Boolean = false,
    val verifyBeforeLaunch: Boolean = true,
    val selectedBuildId: String? = null,
    val selectedAccountId: String? = null,
)
