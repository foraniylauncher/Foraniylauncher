package ru.foraniy.launcher.minecraft

import org.json.JSONArray
import org.json.JSONObject
import ru.foraniy.launcher.core.arr
import ru.foraniy.launcher.core.mapObjects
import ru.foraniy.launcher.core.obj
import ru.foraniy.launcher.core.str
import ru.foraniy.launcher.core.strings

/** Pure parsing of Mojang / Fabric version JSON. No I/O, no Android: easy to unit test. */
object VersionJson {

    /** A version JSON exactly as on disk, before `inheritsFrom` is applied. */
    class Raw(
        val id: String,
        val inheritsFrom: String?,
        val type: String?,
        val mainClass: String?,
        val assetIndex: AssetIndexRef?,
        val client: FileRef?,
        val libraries: List<Library>,
        val gameArgs: List<ArgItem>,
        val jvmArgs: List<ArgItem>,
        val javaMajor: Int?,
    )

    /** Versions before 1.13 have no "arguments" block; these are the JVM flags the old launcher added. */
    private val LEGACY_JVM_ARGS = listOf(
        "-Djava.library.path=\${natives_directory}",
        "-Dminecraft.launcher.brand=\${launcher_name}",
        "-Dminecraft.launcher.version=\${launcher_version}",
        "-cp",
        "\${classpath}",
    )

    fun parse(j: JSONObject): Raw {
        val argsObj = j.obj("arguments")
        val legacy = j.str("minecraftArguments")

        val gameArgs: List<ArgItem>
        val jvmArgs: List<ArgItem>
        if (argsObj != null) {
            gameArgs = parseArgs(argsObj.arr("game"))
            jvmArgs = parseArgs(argsObj.arr("jvm"))
        } else if (legacy != null) {
            gameArgs = legacy.split(' ').filter { it.isNotBlank() }.map { ArgItem(listOf(it), emptyList()) }
            jvmArgs = LEGACY_JVM_ARGS.map { ArgItem(listOf(it), emptyList()) }
        } else {
            gameArgs = emptyList()
            jvmArgs = emptyList()
        }

        val libraries = (j.arr("libraries")?.mapObjects { parseLibrary(it) } ?: emptyList()).filterNotNull()

        val assetIndex = j.obj("assetIndex")?.let {
            val url = it.str("url")
            if (url == null) null else AssetIndexRef(it.getString("id"), url, it.str("sha1"), it.optLong("size"))
        }
        val client = j.obj("downloads")?.obj("client")?.let {
            val url = it.str("url")
            if (url == null) null else FileRef(url, it.str("sha1"), it.optLong("size"))
        }
        val javaMajor = j.obj("javaVersion")?.optInt("majorVersion", 0)?.takeIf { it > 0 }

        return Raw(
            id = j.getString("id"),
            inheritsFrom = j.str("inheritsFrom"),
            type = j.str("type"),
            mainClass = j.str("mainClass"),
            assetIndex = assetIndex,
            client = client,
            libraries = libraries,
            gameArgs = gameArgs,
            jvmArgs = jvmArgs,
            javaMajor = javaMajor,
        )
    }

    fun toResolved(raw: Raw): ResolvedVersion = ResolvedVersion(
        id = raw.id,
        clientJarId = raw.id,
        type = raw.type ?: "release",
        mainClass = raw.mainClass ?: throw IllegalStateException("В ${raw.id} не указан mainClass"),
        assetIndex = raw.assetIndex,
        client = raw.client,
        libraries = raw.libraries,
        gameArgs = raw.gameArgs,
        jvmArgs = raw.jvmArgs,
        javaMajor = raw.javaMajor ?: 8,
    )

    /** Applies a child (e.g. Fabric profile) on top of its already resolved parent (vanilla). */
    fun merge(parent: ResolvedVersion, child: Raw): ResolvedVersion {
        val libs = LinkedHashMap<String, Library>()
        for (l in child.libraries) libs[libKey(l.name)] = l
        for (l in parent.libraries) libs.putIfAbsent(libKey(l.name), l)
        return ResolvedVersion(
            id = child.id,
            clientJarId = parent.clientJarId,
            type = child.type ?: parent.type,
            mainClass = child.mainClass ?: parent.mainClass,
            assetIndex = child.assetIndex ?: parent.assetIndex,
            client = child.client ?: parent.client,
            libraries = libs.values.toList(),
            gameArgs = parent.gameArgs + child.gameArgs,
            jvmArgs = parent.jvmArgs + child.jvmArgs,
            javaMajor = child.javaMajor ?: parent.javaMajor,
        )
    }

    /** Mojang rule semantics: the last matching rule wins, no rules = allowed. We pretend to be linux/arm64. */
    fun rulesAllow(rules: List<Rule>, features: Map<String, Boolean> = emptyMap()): Boolean {
        if (rules.isEmpty()) return true
        var allowed = false
        for (r in rules) if (matches(r, features)) allowed = r.allow
        return allowed
    }

    /** "group:artifact:version[:classifier][@ext]" -> "group/path/artifact/version/artifact-version[-classifier].ext" */
    fun mavenPath(name: String): String {
        var coords = name
        var ext = "jar"
        val at = coords.indexOf('@')
        if (at >= 0) {
            ext = coords.substring(at + 1)
            coords = coords.substring(0, at)
        }
        val p = coords.split(':')
        require(p.size >= 3) { "Некорректное имя библиотеки: $name" }
        val classifier = p.getOrNull(3)
        val file = p[1] + "-" + p[2] + (if (classifier != null) "-$classifier" else "") + "." + ext
        return p[0].replace('.', '/') + "/" + p[1] + "/" + p[2] + "/" + file
    }

    private fun matches(r: Rule, features: Map<String, Boolean>): Boolean {
        if (r.osName != null && r.osName != "linux") return false
        if (r.osArch != null && r.osArch != "arm64" && r.osArch != "aarch64") return false
        for ((k, v) in r.features) if ((features[k] ?: false) != v) return false
        return true
    }

    private fun libKey(name: String): String {
        val p = name.split(':')
        return if (p.size >= 4) "${p[0]}:${p[1]}:${p[3]}" else "${p[0]}:${p.getOrElse(1) { "" }}"
    }

    private fun parseLibrary(o: JSONObject): Library? {
        val name = o.str("name") ?: return null
        if (!rulesAllow(parseRules(o.arr("rules")))) return null

        val artifact = o.obj("downloads")?.obj("artifact")
        if (artifact != null) {
            val url = artifact.str("url")
            if (url.isNullOrBlank()) return null
            return Library(name, artifact.str("path") ?: mavenPath(name), url, artifact.str("sha1"), artifact.optLong("size"))
        }
        // Old "natives" libraries have no plain artifact: desktop natives are useless on Android and
        // are provided by the runtime bridge, so they are skipped.
        if (o.has("natives")) return null

        // Fabric style: only a maven coordinate and a repository base url.
        val base = o.str("url") ?: return null
        val path = mavenPath(name)
        return Library(name, path, base.trimEnd('/') + "/" + path, o.str("sha1"), o.optLong("size"))
    }

    private fun parseRules(a: JSONArray?): List<Rule> = a?.mapObjects { r ->
        val os = r.obj("os")
        val featureObj = r.obj("features")
        val features = HashMap<String, Boolean>()
        featureObj?.keys()?.forEach { k -> features[k] = featureObj.optBoolean(k) }
        Rule(
            allow = r.optString("action") == "allow",
            osName = os?.str("name"),
            osArch = os?.str("arch"),
            features = features,
        )
    } ?: emptyList()

    private fun parseArgs(arr: JSONArray?): List<ArgItem> {
        if (arr == null) return emptyList()
        val out = ArrayList<ArgItem>()
        for (i in 0 until arr.length()) {
            when (val e = arr.get(i)) {
                is String -> out.add(ArgItem(listOf(e), emptyList()))
                is JSONObject -> {
                    val values = when (val v = e.opt("value")) {
                        is String -> listOf(v)
                        is JSONArray -> v.strings()
                        else -> emptyList()
                    }
                    out.add(ArgItem(values, parseRules(e.arr("rules"))))
                }
            }
        }
        return out
    }
}
