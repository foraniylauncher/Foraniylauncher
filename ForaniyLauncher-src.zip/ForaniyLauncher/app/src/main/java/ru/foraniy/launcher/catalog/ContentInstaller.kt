package ru.foraniy.launcher.catalog

import ru.foraniy.launcher.core.Http
import ru.foraniy.launcher.core.LauncherException
import ru.foraniy.launcher.data.PathsProvider
import ru.foraniy.launcher.domain.Build
import java.io.File

/** Installs a Modrinth project (plus its required mod dependencies) into the game folder of a build. */
class ContentInstaller(
    private val api: ModrinthApi,
    private val paths: PathsProvider,
) {
    /** Returns the file names that were installed (or were already there). */
    suspend fun install(project: ContentProject, build: Build): List<String> {
        val loader = build.loader.modrinthName
        val gameDir = paths.current().buildDir(build.id)
        val installed = ArrayList<String>()
        val seen = HashSet<String>()

        suspend fun one(projectId: String, type: ContentType, depth: Int) {
            if (!seen.add(projectId)) return
            val file = api.bestFile(projectId, build.mcVersion, if (type == ContentType.MOD) loader else null)
                ?: if (depth == 0) throw LauncherException("Для Minecraft ${build.mcVersion} нет подходящей версии") else return
            val target = File(File(gameDir, type.folder), file.fileName)
            if (!target.exists()) Http.download(file.url, target, file.sha1)
            installed += file.fileName
            if (type == ContentType.MOD && depth < MAX_DEPTH) {
                for (dep in file.requiredDeps) one(dep, ContentType.MOD, depth + 1)
            }
        }

        one(project.id, project.type, 0)
        return installed
    }

    /** Files currently in a content folder of the build, sorted by name. */
    fun listInstalled(build: Build, type: ContentType): List<File> =
        File(paths.current().buildDir(build.id), type.folder)
            .listFiles { f -> f.isFile && !f.name.endsWith(".part") }
            ?.sortedBy { it.name.lowercase() }
            ?: emptyList()

    private companion object {
        const val MAX_DEPTH = 3
    }
}
