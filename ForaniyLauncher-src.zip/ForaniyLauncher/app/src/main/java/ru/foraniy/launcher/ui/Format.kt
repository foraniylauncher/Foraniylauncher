package ru.foraniy.launcher.ui

import java.util.Locale

fun formatAgo(ms: Long, now: Long = System.currentTimeMillis()): String {
    if (ms <= 0L) return "Ещё не запускалась"
    val minutes = ((now - ms) / 60_000L).coerceAtLeast(0L)
    return when {
        minutes < 1 -> "Играли только что"
        minutes < 60 -> "Играли $minutes мин назад"
        minutes < 60 * 24 -> "Играли ${minutes / 60} ч назад"
        else -> "Играли ${minutes / (60 * 24)} дн назад"
    }
}

fun formatSpeed(bytesPerSecond: Long): String =
    if (bytesPerSecond <= 0) "" else String.format(Locale.US, "%.1f МБ/с", bytesPerSecond / 1_048_576.0)

fun formatSize(bytes: Long): String = when {
    bytes < 1024 -> "$bytes Б"
    bytes < 1_048_576 -> "${bytes / 1024} КБ"
    else -> String.format(Locale.US, "%.1f МБ", bytes / 1_048_576.0)
}

fun formatCount(n: Long): String = when {
    n >= 1_000_000 -> String.format(Locale.US, "%.1f млн", n / 1_000_000.0)
    n >= 1_000 -> "${n / 1_000} тыс"
    else -> n.toString()
}
