package ru.foraniy.launcher.ui.components

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ColumnScope
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.window.Dialog
import androidx.compose.ui.window.DialogProperties
import ru.foraniy.launcher.R
import ru.foraniy.launcher.ui.theme.FxFaint
import ru.foraniy.launcher.ui.theme.FxMuted
import ru.foraniy.launcher.ui.theme.FxOutline
import ru.foraniy.launcher.ui.theme.FxSurface2
import ru.foraniy.launcher.ui.theme.FxText
import ru.foraniy.launcher.ui.theme.LocalAccent

/** Standard alert-style dialog; the body scrolls, so only use plain (non-lazy) content inside. */
@Composable
fun ForaniyDialog(
    title: String,
    onDismiss: () -> Unit,
    modifier: Modifier = Modifier,
    confirmText: String? = null,
    onConfirm: (() -> Unit)? = null,
    confirmEnabled: Boolean = true,
    dismissText: String = "Закрыть",
    content: @Composable ColumnScope.() -> Unit,
) {
    val accent = LocalAccent.current
    AlertDialog(
        onDismissRequest = onDismiss,
        modifier = modifier,
        containerColor = FxSurface2,
        shape = RoundedCornerShape(24.dp),
        title = { Text(title, style = MaterialTheme.typography.titleLarge, color = FxText) },
        text = {
            Column(
                modifier = Modifier.verticalScroll(rememberScrollState()),
                verticalArrangement = Arrangement.spacedBy(12.dp),
                content = content,
            )
        },
        confirmButton = {
            if (confirmText != null && onConfirm != null) {
                TextButton(onClick = onConfirm, enabled = confirmEnabled) {
                    Text(
                        confirmText,
                        color = if (confirmEnabled) accent.glow else FxFaint,
                        fontWeight = FontWeight.Bold,
                    )
                }
            }
        },
        dismissButton = {
            TextButton(onClick = onDismiss) { Text(dismissText, color = FxMuted) }
        },
    )
}

/**
 * Full-width dialog with a header and a close button, for content that contains a LazyColumn
 * (version picker, build picker). Give the lazy list a heightIn(max = ...).
 */
@Composable
fun ForaniySheetDialog(
    title: String,
    onDismiss: () -> Unit,
    content: @Composable ColumnScope.() -> Unit,
) {
    Dialog(onDismissRequest = onDismiss, properties = DialogProperties(usePlatformDefaultWidth = false)) {
        Column(
            modifier = Modifier
                .fillMaxWidth(0.94f)
                .clip(RoundedCornerShape(24.dp))
                .background(FxSurface2)
                .border(1.dp, FxOutline, RoundedCornerShape(24.dp))
                .padding(start = 20.dp, end = 8.dp, top = 12.dp, bottom = 16.dp),
            verticalArrangement = Arrangement.spacedBy(12.dp),
        ) {
            Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
                Text(
                    title,
                    style = MaterialTheme.typography.titleLarge,
                    color = FxText,
                    modifier = Modifier.weight(1f),
                )
                SmallIconButton(R.drawable.ic_close, "Закрыть", onDismiss)
            }
            Column(
                modifier = Modifier.padding(end = 12.dp),
                verticalArrangement = Arrangement.spacedBy(12.dp),
                content = content,
            )
        }
    }
}
