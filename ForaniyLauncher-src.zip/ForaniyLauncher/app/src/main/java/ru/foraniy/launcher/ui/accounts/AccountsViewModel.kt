package ru.foraniy.launcher.ui.accounts

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.Job
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.launch
import ru.foraniy.launcher.AppContainer
import ru.foraniy.launcher.auth.AuthException
import ru.foraniy.launcher.auth.DeviceCode
import ru.foraniy.launcher.auth.OfflineAuth
import ru.foraniy.launcher.core.userMessage
import ru.foraniy.launcher.domain.Account
import ru.foraniy.launcher.domain.AccountType

/** State of the Microsoft device-code sign-in dialog. */
sealed interface MsFlow {
    data object Idle : MsFlow
    data object Starting : MsFlow
    data class Waiting(val code: DeviceCode) : MsFlow
    data class Failed(val message: String) : MsFlow
}

/** The two ways to get an account. */
enum class AuthMode { MICROSOFT, OFFLINE }

class AccountsViewModel(private val c: AppContainer) : ViewModel() {
    val accounts = c.accounts.state
    val settings = c.settings.state
    val microsoftConfigured: Boolean get() = c.microsoft.isConfigured

    private val _ms = MutableStateFlow<MsFlow>(MsFlow.Idle)
    val ms: StateFlow<MsFlow> = _ms.asStateFlow()
    private var msJob: Job? = null

    /** Official sign-in. The launcher never sees the password: the user types a code on microsoft.com. */
    fun startMicrosoft() {
        if (msJob?.isActive == true) return
        msJob = viewModelScope.launch {
            _ms.value = MsFlow.Starting
            try {
                val code = c.microsoft.startDeviceCode()
                _ms.value = MsFlow.Waiting(code)
                val login = c.microsoft.awaitSignIn(code)
                val account = Account(
                    id = login.uuid,
                    type = AccountType.MICROSOFT,
                    name = login.name,
                    uuid = login.uuid,
                    msRefreshToken = login.refreshToken,
                    mcAccessToken = login.mcAccessToken,
                    mcExpiresAtMs = login.mcExpiresAtMs,
                )
                c.accounts.upsert(account)
                select(account.id)
                _ms.value = MsFlow.Idle
            } catch (e: CancellationException) {
                _ms.value = MsFlow.Idle
                throw e
            } catch (e: AuthException) {
                _ms.value = MsFlow.Failed(e.message ?: "Ошибка входа")
            } catch (e: Exception) {
                _ms.value = MsFlow.Failed(e.userMessage())
            }
        }
    }

    fun cancelMicrosoft() {
        msJob?.cancel()
        _ms.value = MsFlow.Idle
    }

    fun dismissMicrosoftError() {
        _ms.value = MsFlow.Idle
    }

    /** Offline account by nickname. Returns an error message or null on success (the account becomes selected). */
    fun addOffline(name: String): String? {
        val nick = name.trim()
        OfflineAuth.validate(nick)?.let { return it }
        val account = OfflineAuth.createAccount(nick)
        c.accounts.upsert(account)
        select(account.id)
        return null
    }

    fun select(id: String) {
        c.settings.edit { it.copy(selectedAccountId = id) }
    }

    fun remove(account: Account) {
        c.accounts.remove(account.id)
        if (c.settings.state.value.selectedAccountId == account.id) {
            c.settings.edit { it.copy(selectedAccountId = null) }
        }
    }
}
