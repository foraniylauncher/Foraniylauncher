package ru.foraniy.launcher.auth

import ru.foraniy.launcher.core.LauncherException
import ru.foraniy.launcher.data.AccountsRepository
import ru.foraniy.launcher.domain.Account
import ru.foraniy.launcher.domain.AccountType
import ru.foraniy.launcher.minecraft.LaunchAccount

/** Turns a stored [Account] into the session data a launch needs, refreshing Microsoft tokens when they expire. */
class AccountManager(
    private val accounts: AccountsRepository,
    private val microsoft: MicrosoftAuth,
) {
    suspend fun sessionFor(account: Account): LaunchAccount = when (account.type) {
        AccountType.OFFLINE -> LaunchAccount(account.name, account.uuid, accessToken = "0", userType = "legacy")

        AccountType.MICROSOFT -> {
            var acc = account
            val expiresSoon = acc.mcAccessToken.isBlank() || acc.mcExpiresAtMs - System.currentTimeMillis() < 120_000L
            if (expiresSoon) {
                if (acc.msRefreshToken.isBlank()) throw LauncherException("Войдите в аккаунт Microsoft заново")
                try {
                    val login = microsoft.refresh(acc.msRefreshToken)
                    acc = acc.copy(
                        name = login.name,
                        uuid = login.uuid,
                        msRefreshToken = login.refreshToken,
                        mcAccessToken = login.mcAccessToken,
                        mcExpiresAtMs = login.mcExpiresAtMs,
                    )
                    accounts.upsert(acc)
                } catch (e: AuthException) {
                    throw LauncherException(e.message ?: "Не удалось обновить сессию Microsoft", cause = e)
                }
            }
            LaunchAccount(acc.name, acc.uuid, acc.mcAccessToken, userType = "msa")
        }
    }
}
