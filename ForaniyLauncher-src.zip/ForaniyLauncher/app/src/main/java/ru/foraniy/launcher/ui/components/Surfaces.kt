package ru.foraniy.launcher.ui.components

import androidx.compose.animation.animateColorAsState
import androidx.compose.animation.core.LinearEasing
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ColumnScope
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.semantics.Role
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import ru.foraniy.launcher.ui.theme.CoverPalette
import ru.foraniy.launcher.ui.theme.FxFaint
import ru.foraniy.launcher.ui.theme.FxMuted
import ru.foraniy.launcher.ui.theme.FxOutline
import ru.foraniy.launcher.ui.theme.FxSoft
import ru.foraniy.launcher.ui.theme.FxSurface
import ru.foraniy.launcher.ui.theme.FxSurface2
import ru.foraniy.launcher.ui.theme.FxSurface3
import ru.foraniy.launcher.ui.theme.FxText
import ru.foraniy.launcher.ui.theme.LocalAccent

/** Rounded dark card with a thin outline. Pass [onClick] to make the whole card tappable. */
@Composable
fun Panel(
    modifier: Modifier = Modifier,
    onClick: (() -> Unit)? = null,
    selected: Boolean = false,
    contentPadding: PaddingValues = PaddingValues(16.dp),
    content: @Composable ColumnScope.() -> Unit,
) {
    val accent = LocalAccent.current
    val shape = RoundedCornerShape(20.dp)
    val borderColor by animateColorAsState(if (selected) accent.main else FxOutline, tween(200), label = "panelBorder")
    Column(
        modifier = modifier
            .clip(shape)
            .background(FxSurface.copy(alpha = 0.92f))
            .border(if (selected) 1.5.dp else 1.dp, borderColor, shape)
            .then(if (onClick != null) Modifier.clickable(role = Role.Button, onClick = onClick) else Modifier)
            .padding(contentPadding),
        content = content,
    )
}

@Composable
fun ScreenTitle(title: String, subtitle: String? = null, modifier: Modifier = Modifier) {
    Column(modifier.padding(top = 8.dp)) {
        Text(title, style = MaterialTheme.typography.headlineMedium, color = FxText)
        if (subtitle != null) {
            Text(subtitle, style = MaterialTheme.typography.bodyMedium, color = FxMuted)
        }
    }
}

@Composable
fun SectionLabel(text: String, modifier: Modifier = Modifier) {
    Text(
        text = text.uppercase(),
        style = MaterialTheme.typography.labelSmall,
        color = FxFaint,
        modifier = modifier.padding(start = 4.dp, top = 4.dp),
    )
}

/** Pill-shaped filter / choice chip (36dp high; wrap in a 48dp row when it is the only touch target). */
@Composable
fun ForaniyChip(text: String, selected: Boolean, onClick: () -> Unit, modifier: Modifier = Modifier) {
    val accent = LocalAccent.current
    val bg by animateColorAsState(if (selected) accent.deep.copy(alpha = 0.40f) else FxSurface2, tween(180), label = "chipBg")
    val border by animateColorAsState(if (selected) accent.main else FxOutline, tween(180), label = "chipBorder")
    Box(
        modifier = modifier
            .height(36.dp)
            .clip(RoundedCornerShape(18.dp))
            .background(bg)
            .border(1.dp, border, RoundedCornerShape(18.dp))
            .clickable(role = Role.RadioButton, onClick = onClick)
            .padding(horizontal = 14.dp),
        contentAlignment = Alignment.Center,
    ) {
        Text(
            text = text,
            style = MaterialTheme.typography.labelLarge,
            color = if (selected) FxSoft else FxMuted,
            maxLines = 1,
        )
    }
}

/** Small tag like "Microsoft", "Офлайн", "Установлена". */
@Composable
fun StatusPill(text: String, color: Color, modifier: Modifier = Modifier) {
    Box(
        modifier = modifier
            .clip(RoundedCornerShape(10.dp))
            .background(color.copy(alpha = 0.16f))
            .padding(horizontal = 8.dp, vertical = 3.dp),
    ) {
        Text(text, style = MaterialTheme.typography.labelMedium, color = color, maxLines = 1)
    }
}

/** [fraction] == null draws an indeterminate sweeping bar. */
@Composable
fun ForaniyProgressBar(fraction: Float?, modifier: Modifier = Modifier) {
    val accent = LocalAccent.current
    val animated by animateFloatAsState(fraction ?: 0f, tween(200), label = "progress")
    val sweep by rememberInfiniteTransition(label = "indeterminate").animateFloat(
        initialValue = 0f,
        targetValue = 1f,
        animationSpec = infiniteRepeatable(tween(1400, easing = LinearEasing)),
        label = "sweep",
    )
    Canvas(
        modifier
            .fillMaxWidth()
            .height(10.dp)
            .clip(RoundedCornerShape(5.dp)),
    ) {
        drawRect(FxSurface3)
        if (fraction != null) {
            drawRect(
                brush = Brush.horizontalGradient(listOf(accent.deep, accent.glow)),
                size = Size(size.width * animated.coerceIn(0f, 1f), size.height),
            )
        } else {
            val segment = size.width * 0.35f
            val x = (size.width + segment) * sweep - segment
            val left = x.coerceAtLeast(0f)
            val right = (x + segment).coerceAtMost(size.width)
            if (right > left) {
                drawRect(
                    brush = Brush.horizontalGradient(listOf(accent.deep, accent.glow), startX = x, endX = x + segment),
                    topLeft = Offset(left, 0f),
                    size = Size(right - left, size.height),
                )
            }
        }
    }
}

/** Round avatar with the first letter of [name] on a gradient picked from the name. */
@Composable
fun Avatar(name: String, modifier: Modifier = Modifier, size: Int = 44) {
    val (light, dark) = CoverPalette[(name.hashCode() and 0x7fffffff) % CoverPalette.size]
    Box(
        modifier = modifier
            .size(size.dp)
            .clip(CircleShape)
            .background(Brush.linearGradient(listOf(light, dark))),
        contentAlignment = Alignment.Center,
    ) {
        Text(
            text = name.firstOrNull()?.uppercaseChar()?.toString() ?: "?",
            color = Color.White,
            fontWeight = FontWeight.ExtraBold,
            fontSize = (size * 0.42f).sp,
        )
    }
}

/** Soft inline message (info / warning / error) inside screens. */
@Composable
fun NoticeBox(text: String, color: Color, modifier: Modifier = Modifier, onClick: (() -> Unit)? = null) {
    Row(
        modifier = modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(14.dp))
            .background(color.copy(alpha = 0.12f))
            .border(1.dp, color.copy(alpha = 0.35f), RoundedCornerShape(14.dp))
            .then(if (onClick != null) Modifier.clickable(onClick = onClick) else Modifier)
            .padding(12.dp),
        horizontalArrangement = Arrangement.spacedBy(10.dp),
        verticalAlignment = Alignment.Top,
    ) {
        Text(text, style = MaterialTheme.typography.bodyMedium, color = FxSoft)
    }
}

@Composable
fun VSpace(height: Int) = Spacer(Modifier.height(height.dp))
