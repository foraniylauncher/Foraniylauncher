package ru.foraniy.launcher.minecraft

enum class VersionType(val label: String) {
    RELEASE("Release"),
    SNAPSHOT("Snapshot"),
    OLD_BETA("Beta"),
    OLD_ALPHA("Alpha");

    companion object {
        fun parse(s: String?): VersionType = when (s) {
            "snapshot" -> SNAPSHOT
            "old_beta" -> OLD_BETA
            "old_alpha" -> OLD_ALPHA
            else -> RELEASE
        }
    }
}

/** One row of Mojang's version_manifest_v2.json. */
data class VersionEntry(
    val id: String,
    val type: VersionType,
    val url: String,
    val sha1: String,
    val releaseTime: String,
)

data class FileRef(val url: String, val sha1: String?, val size: Long)

/** A downloadable library jar. Libraries without a download source (desktop natives) are dropped at parse time. */
data class Library(val name: String, val path: String, val url: String, val sha1: String?, val size: Long)

data class AssetIndexRef(val id: String, val url: String, val sha1: String?, val size: Long)

data class Rule(
    val allow: Boolean,
    val osName: String?,
    val osArch: String?,
    val features: Map<String, Boolean>,
)

/** A launch argument group: plain strings have no rules, conditional ones carry [rules]. */
data class ArgItem(val values: List<String>, val rules: List<Rule>)

/**
 * A fully merged version (vanilla, or Fabric profile + its vanilla parent) ready for installing and launching.
 * [id] names the version folder; [clientJarId] names the folder holding the vanilla client jar.
 */
data class ResolvedVersion(
    val id: String,
    val clientJarId: String,
    val type: String,
    val mainClass: String,
    val assetIndex: AssetIndexRef?,
    val client: FileRef?,
    val libraries: List<Library>,
    val gameArgs: List<ArgItem>,
    val jvmArgs: List<ArgItem>,
    val javaMajor: Int,
)
