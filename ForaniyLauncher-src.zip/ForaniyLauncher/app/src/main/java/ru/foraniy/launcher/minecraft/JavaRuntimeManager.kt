package ru.foraniy.launcher.minecraft

import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import ru.foraniy.launcher.core.Http
import ru.foraniy.launcher.core.LauncherException
import ru.foraniy.launcher.data.PathsProvider
import ru.foraniy.launcher.data.SettingsRepository
import ru.foraniy.launcher.domain.JavaMode
import java.io.File

data class JavaRuntime(val major: Int, val home: File, val executable: File)

/**
 * Finds and installs Java runtimes (runtimes/java<N>/).
 *
 * IMPORTANT: desktop JDK builds (Temurin etc.) are linked against glibc and do NOT run on Android (bionic).
 * The archive must be an Android-compatible runtime (for example the OpenJDK builds used by Android
 * Minecraft launchers). The launcher does not hardcode download links: the user supplies the URL in Settings.
 */
class JavaRuntimeManager(
    private val paths: PathsProvider,
    private val settings: SettingsRepository,
) {
    fun installed(major: Int): JavaRuntime? {
        val dir = paths.current().runtimeDir(major)
        if (!dir.isDirectory) return null
        val exe = findJavaExecutable(dir) ?: return null
        return JavaRuntime(major, exe.parentFile?.parentFile ?: dir, exe)
    }

    /** Order: build override > global custom path (if mode is CUSTOM) > installed runtime for [major]. */
    fun resolve(major: Int, buildJavaPath: String?): JavaRuntime? {
        val s = settings.state.value
        val custom = buildJavaPath?.takeIf { it.isNotBlank() }
            ?: s.customJavaPath.takeIf { s.javaMode == JavaMode.CUSTOM && it.isNotBlank() }
        if (custom != null) {
            val f = File(custom.trim())
            val exe = if (f.isDirectory) findJavaExecutable(f) else f.takeIf { it.isFile }
            return exe?.let { JavaRuntime(major, it.parentFile?.parentFile ?: it, it) }
        }
        return installed(major)
    }

    /** [onProgress] gets (label, fraction) where fraction == null means "indeterminate". */
    suspend fun install(
        major: Int,
        url: String,
        onProgress: (String, Float?) -> Unit,
    ) = withContext(Dispatchers.IO) {
        val p = paths.current()
        val tmp = File(p.cache, "java$major.download")
        var total = 0L
        var got = 0L

        onProgress("Скачивание Java $major", 0f)
        Http.download(url, tmp, null, onLength = { total = it }) { n ->
            got += n
            onProgress("Скачивание Java $major", if (total > 0) (got.toFloat() / total).coerceIn(0f, 1f) else null)
        }

        onProgress("Распаковка Java $major…", null)
        val dest = p.runtimeDir(major)
        dest.deleteRecursively()
        dest.mkdirs()
        when (Archives.sniff(tmp)) {
            Archives.Kind.ZIP -> Archives.unzip(tmp, dest)
            Archives.Kind.TAR_GZ -> Archives.untarGz(tmp, dest)
            Archives.Kind.UNKNOWN -> {
                tmp.delete()
                throw LauncherException("Неизвестный формат архива: нужен .zip или .tar.gz (.tar.xz не поддерживается)")
            }
        }
        tmp.delete()

        val exe = findJavaExecutable(dest) ?: throw LauncherException("В архиве не найден файл bin/java")
        exe.setExecutable(true, false)
        onProgress("Java $major установлена", 1f)
    }

    fun uninstall(major: Int) {
        paths.current().runtimeDir(major).deleteRecursively()
    }

    private fun findJavaExecutable(dir: File, depth: Int = 0): File? {
        if (depth > 4) return null
        val direct = File(dir, "bin/java")
        if (direct.isFile) return direct
        val children = dir.listFiles() ?: return null
        for (child in children) {
            if (!child.isDirectory) continue
            val found = findJavaExecutable(child, depth + 1)
            if (found != null) return found
        }
        return null
    }
}
