package ru.foraniy.launcher.ui.components

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.Slider
import androidx.compose.material3.SliderDefaults
import androidx.compose.material3.Switch
import androidx.compose.material3.SwitchDefaults
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp
import ru.foraniy.launcher.ui.theme.FxDanger
import ru.foraniy.launcher.ui.theme.FxFaint
import ru.foraniy.launcher.ui.theme.FxMuted
import ru.foraniy.launcher.ui.theme.FxOutline
import ru.foraniy.launcher.ui.theme.FxOutlineStrong
import ru.foraniy.launcher.ui.theme.FxSurface2
import ru.foraniy.launcher.ui.theme.FxSurface3
import ru.foraniy.launcher.ui.theme.FxText
import ru.foraniy.launcher.ui.theme.LocalAccent

@Composable
fun ForaniyTextField(
    value: String,
    onValueChange: (String) -> Unit,
    label: String,
    modifier: Modifier = Modifier,
    singleLine: Boolean = true,
    isError: Boolean = false,
    supportingText: String? = null,
    keyboardType: KeyboardType = KeyboardType.Text,
) {
    val accent = LocalAccent.current
    OutlinedTextField(
        value = value,
        onValueChange = onValueChange,
        modifier = modifier.fillMaxWidth(),
        label = { Text(label) },
        singleLine = singleLine,
        isError = isError,
        supportingText = if (supportingText != null) {
            { Text(supportingText) }
        } else {
            null
        },
        keyboardOptions = KeyboardOptions(keyboardType = keyboardType),
        shape = RoundedCornerShape(14.dp),
        colors = OutlinedTextFieldDefaults.colors(
            focusedTextColor = FxText,
            unfocusedTextColor = FxText,
            focusedContainerColor = FxSurface2,
            unfocusedContainerColor = FxSurface2,
            cursorColor = accent.glow,
            focusedBorderColor = accent.main,
            unfocusedBorderColor = FxOutlineStrong,
            errorBorderColor = FxDanger,
            focusedLabelColor = accent.glow,
            unfocusedLabelColor = FxMuted,
            focusedSupportingTextColor = FxMuted,
            unfocusedSupportingTextColor = FxMuted,
            errorSupportingTextColor = FxDanger,
        ),
    )
}

/** Title (+ optional subtitle) on the left, switch on the right. */
@Composable
fun SwitchRow(
    title: String,
    checked: Boolean,
    onCheckedChange: (Boolean) -> Unit,
    modifier: Modifier = Modifier,
    subtitle: String? = null,
) {
    val accent = LocalAccent.current
    Row(
        modifier = modifier
            .fillMaxWidth()
            .heightIn(min = 48.dp),
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.spacedBy(12.dp),
    ) {
        Column(Modifier.weight(1f)) {
            Text(title, style = MaterialTheme.typography.bodyLarge, color = FxText)
            if (subtitle != null) Text(subtitle, style = MaterialTheme.typography.bodySmall, color = FxMuted)
        }
        Switch(
            checked = checked,
            onCheckedChange = onCheckedChange,
            colors = SwitchDefaults.colors(
                checkedThumbColor = Color.White,
                checkedTrackColor = accent.main,
                checkedBorderColor = Color.Transparent,
                uncheckedThumbColor = FxMuted,
                uncheckedTrackColor = FxSurface3,
                uncheckedBorderColor = FxOutlineStrong,
            ),
        )
    }
}

/** Slider for whole numbers with [step] granularity (e.g. RAM in MB, step 256). */
@Composable
fun StepSlider(
    value: Int,
    onValueChange: (Int) -> Unit,
    min: Int,
    max: Int,
    step: Int,
    modifier: Modifier = Modifier,
) {
    val accent = LocalAccent.current
    val steps = ((max - min) / step - 1).coerceAtLeast(0)
    Slider(
        value = value.coerceIn(min, max).toFloat(),
        onValueChange = { raw ->
            val snapped = (Math.round((raw - min) / step.toFloat()) * step + min).coerceIn(min, max)
            if (snapped != value) onValueChange(snapped)
        },
        valueRange = min.toFloat()..max.toFloat(),
        steps = steps,
        modifier = modifier.fillMaxWidth(),
        colors = SliderDefaults.colors(
            thumbColor = Color.White,
            activeTrackColor = accent.main,
            inactiveTrackColor = FxSurface3,
            activeTickColor = Color.Transparent,
            inactiveTickColor = Color.Transparent,
        ),
    )
}

@Composable
fun HintText(text: String, modifier: Modifier = Modifier, color: Color = FxFaint) {
    Text(text, style = MaterialTheme.typography.bodySmall, color = color, modifier = modifier.padding(top = 4.dp))
}
