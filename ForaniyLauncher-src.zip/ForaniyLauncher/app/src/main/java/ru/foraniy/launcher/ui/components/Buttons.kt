package ru.foraniy.launcher.ui.components

import androidx.annotation.DrawableRes
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.tween
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.interaction.collectIsPressedAsState
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.semantics.Role
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import ru.foraniy.launcher.ui.theme.FxDanger
import ru.foraniy.launcher.ui.theme.FxFaint
import ru.foraniy.launcher.ui.theme.FxOutline
import ru.foraniy.launcher.ui.theme.FxOutlineStrong
import ru.foraniy.launcher.ui.theme.FxSoft
import ru.foraniy.launcher.ui.theme.FxSurface2
import ru.foraniy.launcher.ui.theme.FxSurface3
import ru.foraniy.launcher.ui.theme.LocalAccent

enum class ButtonKind { Primary, Tonal, Outline, Danger }

/**
 * The launcher's button. Primary has the neon glow: use it for ONE main action per screen/card.
 * Min height 56dp by default (touch first); pressed state scales to 97%.
 */
@Composable
fun ForaniyButton(
    text: String,
    onClick: () -> Unit,
    modifier: Modifier = Modifier,
    kind: ButtonKind = ButtonKind.Primary,
    @DrawableRes icon: Int? = null,
    enabled: Boolean = true,
    height: Dp = 56.dp,
) {
    val accent = LocalAccent.current
    val source = remember { MutableInteractionSource() }
    val pressed by source.collectIsPressedAsState()
    val scale by animateFloatAsState(if (pressed && enabled) 0.97f else 1f, tween(120), label = "buttonScale")
    val shape = RoundedCornerShape(16.dp)

    val contentColor = when {
        !enabled -> FxFaint
        kind == ButtonKind.Primary -> Color.White
        kind == ButtonKind.Danger -> FxDanger
        else -> FxSoft
    }
    val decoration: Modifier = when {
        !enabled -> Modifier.clip(shape).background(FxSurface3)
        kind == ButtonKind.Primary -> Modifier
            .shadow(14.dp, shape, ambientColor = accent.main.copy(alpha = 0.4f), spotColor = accent.main)
            .clip(shape)
            .background(Brush.linearGradient(listOf(accent.glow, accent.deep)))
        kind == ButtonKind.Tonal -> Modifier.clip(shape).background(FxSurface3)
        kind == ButtonKind.Outline -> Modifier.clip(shape).border(1.5.dp, FxOutlineStrong, shape)
        else -> Modifier.clip(shape).border(1.5.dp, FxDanger, shape)
    }

    Row(
        modifier = modifier
            .height(height)
            .graphicsLayer {
                scaleX = scale
                scaleY = scale
            }
            .then(decoration)
            .clickable(
                interactionSource = source,
                indication = null,
                enabled = enabled,
                role = Role.Button,
                onClick = onClick,
            )
            .padding(horizontal = 20.dp),
        horizontalArrangement = Arrangement.Center,
        verticalAlignment = Alignment.CenterVertically,
    ) {
        if (icon != null) {
            Icon(painterResource(icon), contentDescription = null, modifier = Modifier.size(22.dp), tint = contentColor)
            Spacer(Modifier.width(10.dp))
        }
        Text(
            text = text,
            color = contentColor,
            style = MaterialTheme.typography.labelLarge.copy(fontSize = 16.sp, fontWeight = FontWeight.Bold),
            maxLines = 1,
            overflow = TextOverflow.Ellipsis,
        )
    }
}

/** 48dp round icon button (the minimum comfortable touch target). */
@Composable
fun IconCircleButton(
    @DrawableRes icon: Int,
    contentDescription: String,
    onClick: () -> Unit,
    modifier: Modifier = Modifier,
    highlighted: Boolean = false,
    enabled: Boolean = true,
) {
    val accent = LocalAccent.current
    val look = if (highlighted) {
        Modifier.background(Brush.linearGradient(listOf(accent.glow, accent.deep)), CircleShape)
    } else {
        Modifier.background(FxSurface2, CircleShape).border(1.dp, FxOutline, CircleShape)
    }
    Box(
        modifier = modifier
            .size(48.dp)
            .then(look)
            .clip(CircleShape)
            .clickable(enabled = enabled, role = Role.Button, onClick = onClick),
        contentAlignment = Alignment.Center,
    ) {
        Icon(
            painter = painterResource(icon),
            contentDescription = contentDescription,
            modifier = Modifier.size(22.dp),
            tint = when {
                !enabled -> FxFaint
                highlighted -> Color.White
                else -> FxSoft
            },
        )
    }
}

/** Compact 40dp icon button for dense lists (rows inside dialogs). */
@Composable
fun SmallIconButton(
    @DrawableRes icon: Int,
    contentDescription: String,
    onClick: () -> Unit,
    modifier: Modifier = Modifier,
    tint: Color = FxSoft,
) {
    Box(
        modifier = modifier
            .size(40.dp)
            .clip(CircleShape)
            .clickable(role = Role.Button, onClick = onClick),
        contentAlignment = Alignment.Center,
    ) {
        Icon(painterResource(icon), contentDescription, Modifier.size(20.dp), tint = tint)
    }
}
