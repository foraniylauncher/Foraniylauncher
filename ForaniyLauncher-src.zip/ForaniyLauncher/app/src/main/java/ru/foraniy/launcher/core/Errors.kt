package ru.foraniy.launcher.core

import java.io.IOException
import java.net.ConnectException
import java.net.SocketTimeoutException
import java.net.UnknownHostException

/** Turns any exception into a short Russian message for the UI. Order matters: specific types first. */
fun Throwable.userMessage(): String = when (this) {
    is LauncherException -> message ?: "Ошибка"
    is HttpException -> if (code in 500..599) "Сервер временно недоступен (HTTP $code)" else "Ошибка запроса (HTTP $code)"
    is UnknownHostException, is SocketTimeoutException, is ConnectException -> "Нет подключения к интернету"
    is IOException -> message ?: "Ошибка сети или диска"
    else -> message ?: javaClass.simpleName
}
