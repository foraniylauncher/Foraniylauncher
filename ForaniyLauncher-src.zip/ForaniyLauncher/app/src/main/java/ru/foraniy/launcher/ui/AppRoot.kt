package ru.foraniy.launcher.ui

import androidx.activity.compose.BackHandler
import androidx.compose.animation.AnimatedContent
import androidx.compose.animation.animateColorAsState
import androidx.compose.animation.core.tween
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.slideInHorizontally
import androidx.compose.animation.slideOutHorizontally
import androidx.compose.animation.togetherWith
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.RowScope
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalConfiguration
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.semantics.Role
import androidx.compose.ui.unit.dp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import ru.foraniy.launcher.AppContainer
import ru.foraniy.launcher.ui.accounts.AccountsScreen
import ru.foraniy.launcher.ui.builds.BuildsScreen
import ru.foraniy.launcher.ui.catalog.CatalogScreen
import ru.foraniy.launcher.ui.components.ForaniyBackground
import ru.foraniy.launcher.ui.play.PlayScreen
import ru.foraniy.launcher.ui.settings.SettingsScreen
import ru.foraniy.launcher.ui.theme.ForaniyTheme
import ru.foraniy.launcher.ui.theme.FxMuted
import ru.foraniy.launcher.ui.theme.FxOutline
import ru.foraniy.launcher.ui.theme.FxSoft
import ru.foraniy.launcher.ui.theme.FxSurface
import ru.foraniy.launcher.ui.theme.LocalAccent

/** Root composable: theme + animated background + navigation (bottom bar on phones, side rail on tablets). */
@Composable
fun AppRoot(container: AppContainer) {
    val settings by container.settings.state.collectAsStateWithLifecycle()

    ForaniyTheme(settings.accentIndex) {
        ForaniyBackground {
            var screen by rememberSaveable { mutableStateOf(Screen.PLAY) }
            BackHandler(enabled = screen != Screen.PLAY) { screen = Screen.PLAY }

            val wide = LocalConfiguration.current.screenWidthDp >= 840
            if (wide) {
                Row(Modifier.fillMaxSize()) {
                    SideRail(screen) { screen = it }
                    ScreenHost(
                        container = container,
                        screen = screen,
                        onNavigate = { screen = it },
                        modifier = Modifier.weight(1f).fillMaxHeight().statusBarsPadding(),
                    )
                }
            } else {
                Column(Modifier.fillMaxSize()) {
                    ScreenHost(
                        container = container,
                        screen = screen,
                        onNavigate = { screen = it },
                        modifier = Modifier.weight(1f).fillMaxWidth().statusBarsPadding(),
                    )
                    BottomBar(screen) { screen = it }
                }
            }
        }
    }
}

@Composable
private fun ScreenHost(
    container: AppContainer,
    screen: Screen,
    onNavigate: (Screen) -> Unit,
    modifier: Modifier,
) {
    Box(modifier, contentAlignment = Alignment.TopCenter) {
        Box(Modifier.widthIn(max = 720.dp).fillMaxSize()) {
            AnimatedContent(
                targetState = screen,
                transitionSpec = {
                    val dir = if (targetState.ordinal >= initialState.ordinal) 1 else -1
                    (fadeIn(tween(280)) + slideInHorizontally(tween(280)) { dir * it / 10 }) togetherWith
                        (fadeOut(tween(150)) + slideOutHorizontally(tween(150)) { -dir * it / 10 })
                },
                label = "screen",
            ) { target ->
                when (target) {
                    Screen.PLAY -> PlayScreen(container, onNavigate)
                    Screen.BUILDS -> BuildsScreen(container, onNavigate)
                    Screen.CATALOG -> CatalogScreen(container, onNavigate)
                    Screen.ACCOUNTS -> AccountsScreen(container, onNavigate)
                    Screen.SETTINGS -> SettingsScreen(container, onNavigate)
                }
            }
        }
    }
}

@Composable
private fun BottomBar(current: Screen, onSelect: (Screen) -> Unit) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .background(FxSurface.copy(alpha = 0.96f))
            .navigationBarsPadding()
            .height(72.dp)
            .padding(horizontal = 4.dp),
        horizontalArrangement = Arrangement.SpaceEvenly,
        verticalAlignment = Alignment.CenterVertically,
    ) {
        Screen.entries.forEach { s ->
            NavItem(s, s == current, Modifier.weight(1f)) { onSelect(s) }
        }
    }
}

@Composable
private fun SideRail(current: Screen, onSelect: (Screen) -> Unit) {
    Column(
        modifier = Modifier
            .fillMaxHeight()
            .width(96.dp)
            .background(FxSurface.copy(alpha = 0.96f))
            .statusBarsPadding()
            .navigationBarsPadding()
            .padding(vertical = 12.dp),
        verticalArrangement = Arrangement.spacedBy(8.dp, Alignment.CenterVertically),
        horizontalAlignment = Alignment.CenterHorizontally,
    ) {
        Screen.entries.forEach { s ->
            NavItem(s, s == current, Modifier.fillMaxWidth()) { onSelect(s) }
        }
    }
}

@Composable
private fun NavItem(screen: Screen, selected: Boolean, modifier: Modifier, onClick: () -> Unit) {
    val accent = LocalAccent.current
    val pill by animateColorAsState(
        if (selected) accent.deep.copy(alpha = 0.40f) else Color.Transparent, tween(200), label = "navPill",
    )
    val tint by animateColorAsState(if (selected) FxSoft else FxMuted, tween(200), label = "navTint")
    Column(
        modifier = modifier
            .clickable(
                interactionSource = remember { MutableInteractionSource() },
                indication = null,
                role = Role.Tab,
                onClick = onClick,
            )
            .padding(vertical = 8.dp),
        horizontalAlignment = Alignment.CenterHorizontally,
    ) {
        Box(
            Modifier
                .width(56.dp)
                .height(30.dp)
                .clip(RoundedCornerShape(15.dp))
                .background(pill),
            contentAlignment = Alignment.Center,
        ) {
            Icon(painterResource(screen.icon), contentDescription = screen.label, modifier = Modifier.size(22.dp), tint = tint)
        }
        Spacer(Modifier.height(2.dp))
        Text(screen.label, style = MaterialTheme.typography.labelMedium, color = tint, maxLines = 1)
    }
}
