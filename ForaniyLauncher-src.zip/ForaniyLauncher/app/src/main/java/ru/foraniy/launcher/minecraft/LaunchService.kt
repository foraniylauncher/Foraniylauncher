package ru.foraniy.launcher.minecraft

import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Job
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.launch
import ru.foraniy.launcher.auth.AccountManager
import ru.foraniy.launcher.core.LauncherException
import ru.foraniy.launcher.data.AccountsRepository
import ru.foraniy.launcher.data.BuildsRepository
import ru.foraniy.launcher.data.PathsProvider
import ru.foraniy.launcher.data.SettingsRepository
import ru.foraniy.launcher.domain.AccountType
import ru.foraniy.launcher.domain.LoaderType
import java.io.BufferedWriter
import java.io.File

sealed interface LaunchState {
    data object Idle : LaunchState
    data class Working(val label: String, val fraction: Float? = null, val bytesPerSecond: Long = 0) : LaunchState
    data class Running(val buildName: String) : LaunchState
    data class Finished(val exitCode: Int) : LaunchState
    data class Failed(val message: String, val needJava: Int? = null) : LaunchState
}

/**
 * Orchestrates "Play": resolve version -> (Fabric) -> install files -> refresh account -> find Java -> run.
 * Lives as long as the app process (own [scope]) so a download keeps going when the user switches screens.
 * UI observes [state] and [log]; it never talks to the installers directly.
 */
class LaunchService(
    private val scope: CoroutineScope,
    private val paths: PathsProvider,
    private val settings: SettingsRepository,
    private val builds: BuildsRepository,
    private val accounts: AccountsRepository,
    private val accountManager: AccountManager,
    private val versions: VersionRepository,
    private val fabric: FabricMeta,
    private val installer: GameInstaller,
    private val javaRuntimes: JavaRuntimeManager,
    private val backend: LaunchBackend,
) {
    private val _state = MutableStateFlow<LaunchState>(LaunchState.Idle)
    val state: StateFlow<LaunchState> = _state.asStateFlow()

    private val _log = MutableStateFlow<List<String>>(emptyList())
    val log: StateFlow<List<String>> = _log.asStateFlow()

    private var job: Job? = null

    val isBusy: Boolean get() = job?.isActive == true

    fun start(buildId: String, accountId: String) {
        if (isBusy) return
        job = scope.launch { execute(buildId, accountId) }
    }

    fun cancel() {
        job?.cancel()
    }

    /** Clears a Finished/Failed banner. */
    fun reset() {
        if (!isBusy) _state.value = LaunchState.Idle
    }

    private suspend fun execute(buildId: String, accountId: String) {
        _log.value = emptyList()
        var writer: BufferedWriter? = null

        fun emit(line: String) {
            _log.update { (it + line).takeLast(MAX_LOG_LINES) }
            runCatching {
                writer?.let { w ->
                    w.appendLine(line)
                    w.flush()
                }
            }
        }

        try {
            val build = builds.state.value.firstOrNull { it.id == buildId }
                ?: throw LauncherException("Сборка не найдена")
            val account = accounts.state.value.firstOrNull { it.id == accountId }
                ?: throw LauncherException("Выберите аккаунт")
            val s = settings.state.value
            val p = paths.current()
            writer = File(p.logs, "latest.log").bufferedWriter()

            _state.value = LaunchState.Working("Загрузка списка версий…")
            val manifest = versions.manifest()

            var versionId = build.mcVersion
            if (build.loader == LoaderType.FABRIC) {
                _state.value = LaunchState.Working("Подготовка Fabric…")
                val loaderVersion = build.loaderVersion
                    ?: fabric.loaderVersions(build.mcVersion).firstOrNull()
                    ?: throw LauncherException("Для Minecraft ${build.mcVersion} нет загрузчика Fabric")
                if (build.loaderVersion == null) builds.update(build.id) { it.copy(loaderVersion = loaderVersion) }
                versionId = fabric.ensureProfile(build.mcVersion, loaderVersion)
            }
            val resolved = versions.resolve(versionId, manifest)
            emit("[Лаунчер] Версия ${resolved.id}, Java ${resolved.javaMajor}, main: ${resolved.mainClass}")

            installer.install(resolved, p, s.verifyBeforeLaunch) { progress ->
                _state.value = LaunchState.Working(progress.label, progress.fraction, progress.bytesPerSecond)
            }

            _state.value = LaunchState.Working("Вход в аккаунт…")
            val session = accountManager.sessionFor(account)

            val runtime = javaRuntimes.resolve(resolved.javaMajor, build.javaPath)
                ?: throw LauncherException(
                    "Не найдена Java ${resolved.javaMajor}. Установите её в Настройках.",
                    needJava = resolved.javaMajor,
                )

            val gameDir = p.buildDir(build.id).also { it.mkdirs() }
            File(p.versionDir(resolved.id), "natives").mkdirs()

            val command = LaunchCommandBuilder.build(
                LaunchRequest(
                    version = resolved,
                    paths = p,
                    gameDir = gameDir,
                    account = session,
                    javaExecutable = runtime.executable.absolutePath,
                    ramMb = build.ramMb ?: s.ramMb,
                    extraJvmArgs = build.extraJvmArgs.trim().split(Regex("\\s+")).filter { it.isNotEmpty() },
                    serverAddress = build.serverAddress.takeIf { it.isNotBlank() },
                ),
            )
            ServerAddress.parse(build.serverAddress)?.let { server ->
                emit("[Лаунчер] Автозаход на сервер ${server.display}")
                if (account.type == AccountType.OFFLINE) {
                    emit("[Лаунчер] Офлайн-аккаунт: сервер примет вас, только если сам разрешает вход без лицензии. Иначе нужен аккаунт Microsoft.")
                }
            }
            val shown = command.joinToString(" ").let { line ->
                if (session.accessToken.length > 1) line.replace(session.accessToken, "***") else line
            }
            emit("[Лаунчер] Запуск через «${backend.title}»")
            emit("[Лаунчер] $shown")

            builds.update(build.id) { it.copy(lastPlayedAtMs = System.currentTimeMillis()) }
            _state.value = LaunchState.Running(build.name)
            val exitCode = backend.run(LaunchSpec(command, gameDir)) { line -> emit(line) }
            emit("[Лаунчер] Игра завершилась с кодом $exitCode")
            _state.value = LaunchState.Finished(exitCode)
        } catch (e: CancellationException) {
            _state.value = LaunchState.Idle
            throw e
        } catch (e: LauncherException) {
            emit("[Лаунчер] Ошибка: ${e.message}")
            _state.value = LaunchState.Failed(e.message ?: "Ошибка", e.needJava)
        } catch (e: Exception) {
            emit("[Лаунчер] Ошибка: ${e.javaClass.simpleName}: ${e.message}")
            _state.value = LaunchState.Failed(e.message ?: e.javaClass.simpleName)
        } finally {
            runCatching { writer?.close() }
        }
    }

    private companion object {
        const val MAX_LOG_LINES = 500
    }
}
