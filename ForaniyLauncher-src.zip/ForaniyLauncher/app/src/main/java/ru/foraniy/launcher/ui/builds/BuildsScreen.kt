package ru.foraniy.launcher.ui.builds

import androidx.compose.animation.AnimatedVisibility
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import kotlinx.coroutines.launch
import ru.foraniy.launcher.AppContainer
import ru.foraniy.launcher.R
import ru.foraniy.launcher.catalog.ContentType
import ru.foraniy.launcher.domain.Build
import ru.foraniy.launcher.domain.LoaderType
import ru.foraniy.launcher.minecraft.ServerAddress
import ru.foraniy.launcher.minecraft.VersionType
import ru.foraniy.launcher.ui.Screen
import ru.foraniy.launcher.ui.appViewModel
import ru.foraniy.launcher.ui.components.ButtonKind
import ru.foraniy.launcher.ui.components.ForaniyButton
import ru.foraniy.launcher.ui.components.ForaniyChip
import ru.foraniy.launcher.ui.components.ForaniyDialog
import ru.foraniy.launcher.ui.components.ForaniySheetDialog
import ru.foraniy.launcher.ui.components.ForaniyTextField
import ru.foraniy.launcher.ui.components.HintText
import ru.foraniy.launcher.ui.components.IconCircleButton
import ru.foraniy.launcher.ui.components.NoticeBox
import ru.foraniy.launcher.ui.components.Panel
import ru.foraniy.launcher.ui.components.ScreenTitle
import ru.foraniy.launcher.ui.components.SectionLabel
import ru.foraniy.launcher.ui.components.SmallIconButton
import ru.foraniy.launcher.ui.components.StatusPill
import ru.foraniy.launcher.ui.components.StepSlider
import ru.foraniy.launcher.ui.components.SwitchRow
import ru.foraniy.launcher.ui.formatAgo
import ru.foraniy.launcher.ui.formatSize
import ru.foraniy.launcher.ui.theme.CoverPalette
import ru.foraniy.launcher.ui.theme.FxDanger
import ru.foraniy.launcher.ui.theme.FxMuted
import ru.foraniy.launcher.ui.theme.FxSoft
import ru.foraniy.launcher.ui.theme.FxSuccess
import ru.foraniy.launcher.ui.theme.FxText
import ru.foraniy.launcher.ui.theme.FxWarning
import ru.foraniy.launcher.ui.theme.LocalAccent

@Composable
fun BuildsScreen(container: AppContainer, onNavigate: (Screen) -> Unit) {
    val vm = appViewModel { BuildsViewModel(container) }
    val builds by vm.builds.collectAsStateWithLifecycle()
    val settings by vm.settings.collectAsStateWithLifecycle()
    val selectedId = settings.selectedBuildId ?: builds.firstOrNull()?.id

    var editorOpen by remember { mutableStateOf(false) }
    var editing by remember { mutableStateOf<Build?>(null) }
    var toDelete by remember { mutableStateOf<Build?>(null) }
    var modsFor by remember { mutableStateOf<Build?>(null) }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .verticalScroll(rememberScrollState())
            .padding(horizontal = 20.dp, vertical = 12.dp),
        verticalArrangement = Arrangement.spacedBy(14.dp),
    ) {
        ScreenTitle("Сборки", "У каждой своя версия, моды и папка игры")
        ForaniyButton(
            "Создать сборку",
            { editing = null; editorOpen = true },
            Modifier.fillMaxWidth(),
            icon = R.drawable.ic_plus,
        )

        if (builds.isEmpty()) {
            NoticeBox("Пока нет ни одной сборки. Создайте первую: выберите версию Minecraft и, если нужны моды, загрузчик Fabric.", FxMuted)
        }
        builds.forEach { b ->
            BuildCard(
                build = b,
                selected = b.id == selectedId,
                onSelect = { vm.select(b.id) },
                onEdit = { editing = b; editorOpen = true },
                onMods = { modsFor = b },
                onCopy = { vm.duplicate(b) },
                onDelete = { toDelete = b },
            )
        }
        Spacer(Modifier.height(8.dp))
    }

    if (editorOpen) {
        BuildEditorDialog(
            vm = vm,
            initial = editing,
            onDismiss = { editorOpen = false },
        )
    }

    modsFor?.let { b -> ContentDialog(vm, b) { modsFor = null } }

    toDelete?.let { b ->
        ForaniyDialog(
            title = "Удалить сборку?",
            onDismiss = { toDelete = null },
            confirmText = "Удалить",
            onConfirm = {
                vm.delete(b)
                toDelete = null
            },
            dismissText = "Отмена",
        ) {
            Text(
                "«${b.name}» будет удалена вместе с папкой игры: сохранениями, модами и настройками. Это нельзя отменить.",
                style = MaterialTheme.typography.bodyMedium,
                color = FxMuted,
            )
        }
    }
}

@Composable
private fun BuildCard(
    build: Build,
    selected: Boolean,
    onSelect: () -> Unit,
    onEdit: () -> Unit,
    onMods: () -> Unit,
    onCopy: () -> Unit,
    onDelete: () -> Unit,
) {
    val accent = LocalAccent.current
    Panel(Modifier.fillMaxWidth(), onClick = onSelect, selected = selected) {
        Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(14.dp)) {
            val (light, dark) = CoverPalette[build.coverIndex.mod(CoverPalette.size)]
            Box(
                Modifier
                    .size(52.dp)
                    .clip(RoundedCornerShape(16.dp))
                    .background(Brush.linearGradient(listOf(light, dark))),
                contentAlignment = Alignment.Center,
            ) {
                Icon(painterResource(R.drawable.ic_builds), null, Modifier.size(26.dp), tint = Color.White)
            }
            Column(Modifier.weight(1f)) {
                Text(build.name, style = MaterialTheme.typography.titleMedium, color = FxText, maxLines = 1, overflow = TextOverflow.Ellipsis)
                val loader = if (build.loader == LoaderType.FABRIC) " · Fabric" else ""
                Text("Minecraft ${build.mcVersion}$loader", style = MaterialTheme.typography.bodyMedium, color = FxMuted)
                Text(formatAgo(build.lastPlayedAtMs), style = MaterialTheme.typography.bodySmall, color = FxMuted)
            }
            if (selected) StatusPill("Выбрана", accent.glow)
        }
        Spacer(Modifier.height(10.dp))
        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.End) {
            SmallIconButton(R.drawable.ic_mod, "Моды и ресурсы", onMods)
            SmallIconButton(R.drawable.ic_edit, "Изменить", onEdit)
            SmallIconButton(R.drawable.ic_copy, "Дублировать", onCopy)
            SmallIconButton(R.drawable.ic_trash, "Удалить", onDelete, tint = FxDanger)
        }
    }
}

@Composable
private fun BuildEditorDialog(vm: BuildsViewModel, initial: Build?, onDismiss: () -> Unit) {
    val versions by vm.versions.collectAsStateWithLifecycle()
    val settings by vm.settings.collectAsStateWithLifecycle()

    var name by remember { mutableStateOf(initial?.name ?: "") }
    var version by remember { mutableStateOf(initial?.mcVersion ?: "") }
    var loader by remember { mutableStateOf(initial?.loader ?: LoaderType.VANILLA) }
    var server by remember { mutableStateOf(initial?.serverAddress ?: "") }
    var customRam by remember { mutableStateOf(initial?.ramMb != null) }
    var ram by remember { mutableStateOf(initial?.ramMb ?: settings.ramMb) }
    var advanced by remember { mutableStateOf(false) }
    var jvmArgs by remember { mutableStateOf(initial?.extraJvmArgs ?: "") }
    var javaPath by remember { mutableStateOf(initial?.javaPath ?: "") }
    var pickVersion by remember { mutableStateOf(false) }

    val serverOk = server.isBlank() || ServerAddress.parse(server) != null
    val canSave = name.isNotBlank() && version.isNotBlank() && serverOk
    val maxRam = remember { vm.maxRamMb() }

    ForaniyDialog(
        title = if (initial == null) "Новая сборка" else "Изменить сборку",
        onDismiss = onDismiss,
        confirmText = if (initial == null) "Создать" else "Сохранить",
        onConfirm = {
            vm.save(
                BuildDraft(
                    id = initial?.id,
                    name = name,
                    mcVersion = version,
                    loader = loader,
                    ramMb = if (customRam) ram else null,
                    javaPath = javaPath,
                    jvmArgs = jvmArgs,
                    serverAddress = server,
                ),
            )
            onDismiss()
        },
        confirmEnabled = canSave,
        dismissText = "Отмена",
    ) {
        ForaniyTextField(name, { name = it }, "Название")

        Panel(Modifier.fillMaxWidth(), onClick = { pickVersion = true }, contentPadding = PaddingValues(14.dp)) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Column(Modifier.weight(1f)) {
                    Text("Версия Minecraft", style = MaterialTheme.typography.bodySmall, color = FxMuted)
                    Text(
                        version.ifEmpty { "Выбрать версию" },
                        style = MaterialTheme.typography.titleMedium,
                        color = if (version.isEmpty()) FxMuted else FxText,
                    )
                }
                Icon(painterResource(R.drawable.ic_chevron_right), null, Modifier.size(20.dp), tint = FxMuted)
            }
        }

        Text("Загрузчик", style = MaterialTheme.typography.bodySmall, color = FxMuted)
        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            LoaderType.entries.forEach { l -> ForaniyChip(l.label, loader == l, { loader = l }) }
        }
        HintText(
            if (loader == LoaderType.FABRIC) "Fabric нужен для модов из каталога. Загрузчик подберётся автоматически."
            else "Чистая игра без модов. Шейдеры и текстуры можно ставить и так.",
        )

        ForaniyTextField(
            value = server,
            onValueChange = { server = it },
            label = "Сервер для автозахода (необязательно)",
            isError = !serverOk,
            supportingText = if (serverOk) "Адрес или адрес:порт" else "Формат: адрес или адрес:порт",
        )

        SwitchRow("Своя память для этой сборки", customRam, { customRam = it })
        AnimatedVisibility(customRam) {
            Column {
                Text("$ram МБ", style = MaterialTheme.typography.labelLarge, color = FxSoft)
                StepSlider(ram, { ram = it }, min = 512, max = maxOf(maxRam, 1024), step = 256)
            }
        }

        ForaniyChip(if (advanced) "Скрыть дополнительное" else "Дополнительно", advanced, { advanced = !advanced })
        AnimatedVisibility(advanced) {
            Column(verticalArrangement = Arrangement.spacedBy(12.dp)) {
                ForaniyTextField(jvmArgs, { jvmArgs = it }, "Аргументы JVM", supportingText = "Через пробел, например -XX:+UseG1GC")
                ForaniyTextField(javaPath, { javaPath = it }, "Свой путь к Java", supportingText = "Пусто = выбирается автоматически")
            }
        }
    }

    if (pickVersion) {
        VersionPickerDialog(
            state = versions,
            showSnapshots = settings.showSnapshots,
            showOld = settings.showOldVersions,
            selected = version,
            isInstalled = vm::isVersionInstalled,
            onPick = {
                version = it
                if (name.isBlank()) name = "Minecraft $it"
                pickVersion = false
            },
            onRetry = vm::loadVersions,
            onDismiss = { pickVersion = false },
        )
    }
}

@Composable
private fun VersionPickerDialog(
    state: VersionsState,
    showSnapshots: Boolean,
    showOld: Boolean,
    selected: String,
    isInstalled: (String) -> Boolean,
    onPick: (String) -> Unit,
    onRetry: () -> Unit,
    onDismiss: () -> Unit,
) {
    val accent = LocalAccent.current
    var query by remember { mutableStateOf("") }
    var snapshots by remember { mutableStateOf(showSnapshots) }
    var old by remember { mutableStateOf(showOld) }

    ForaniySheetDialog(title = "Выбор версии", onDismiss = onDismiss) {
        when (state) {
            VersionsState.Loading -> Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                CircularProgressIndicator(Modifier.size(20.dp), color = accent.main, strokeWidth = 2.dp)
                Text("Загружаем список версий…", color = FxMuted)
            }

            is VersionsState.Failed -> {
                NoticeBox(state.message, FxDanger)
                ForaniyButton("Повторить", onRetry, Modifier.fillMaxWidth(), kind = ButtonKind.Tonal, icon = R.drawable.ic_refresh, height = 48.dp)
            }

            is VersionsState.Ready -> {
                ForaniyTextField(query, { query = it }, "Поиск версии")
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    ForaniyChip("Снапшоты", snapshots, { snapshots = !snapshots })
                    ForaniyChip("Старые", old, { old = !old })
                }
                val list = state.all.filter { v ->
                    val typeOk = when (v.type) {
                        VersionType.RELEASE -> true
                        VersionType.SNAPSHOT -> snapshots
                        VersionType.OLD_BETA, VersionType.OLD_ALPHA -> old
                    }
                    typeOk && (query.isBlank() || v.id.contains(query.trim(), ignoreCase = true))
                }
                if (list.isEmpty()) Text("Ничего не найдено", color = FxMuted)
                LazyColumn(Modifier.heightIn(max = 380.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
                    items(list, key = { it.id }) { v ->
                        Panel(
                            Modifier.fillMaxWidth(),
                            onClick = { onPick(v.id) },
                            selected = v.id == selected,
                            contentPadding = PaddingValues(horizontal = 14.dp, vertical = 10.dp),
                        ) {
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Column(Modifier.weight(1f)) {
                                    Text(v.id, style = MaterialTheme.typography.titleMedium, color = FxText)
                                    Text(v.type.label, style = MaterialTheme.typography.bodySmall, color = FxMuted)
                                }
                                if (isInstalled(v.id)) {
                                    Icon(painterResource(R.drawable.ic_check), "Установлена", Modifier.size(22.dp), tint = FxSuccess)
                                } else {
                                    Icon(painterResource(R.drawable.ic_download), "Будет скачана", Modifier.size(22.dp), tint = FxMuted)
                                }
                            }
                        }
                    }
                }
            }
        }
    }
}

/** Lists installed mods / shaders / resource packs of a build and lets the user delete them. */
@Composable
private fun ContentDialog(vm: BuildsViewModel, build: Build, onDismiss: () -> Unit) {
    var tick by remember { mutableIntStateOf(0) }
    val scope = rememberCoroutineScope()

    ForaniyDialog(title = "Содержимое «${build.name}»", onDismiss = onDismiss) {
        ContentType.entries.forEach { type ->
            val files = remember(tick, build.id, type) { vm.listContent(build, type) }
            SectionLabel("${type.label} (${files.size})")
            if (files.isEmpty()) {
                Text("Пусто. Добавьте из каталога.", style = MaterialTheme.typography.bodySmall, color = FxMuted)
            }
            files.forEach { f ->
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Column(Modifier.weight(1f)) {
                        Text(f.name, style = MaterialTheme.typography.bodyMedium, color = FxText, maxLines = 1, overflow = TextOverflow.Ellipsis)
                        Text(formatSize(f.length()), style = MaterialTheme.typography.bodySmall, color = FxMuted)
                    }
                    SmallIconButton(R.drawable.ic_trash, "Удалить файл", {
                        scope.launch {
                            vm.deleteContent(f)
                            tick++
                        }
                    }, tint = FxDanger)
                }
            }
        }
        if (build.loader != LoaderType.FABRIC) {
            NoticeBox("Моды работают только в сборках с Fabric. Измените загрузчик в настройках сборки.", FxWarning)
        }
    }
}
