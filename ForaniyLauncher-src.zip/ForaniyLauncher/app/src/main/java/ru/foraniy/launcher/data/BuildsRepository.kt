package ru.foraniy.launcher.data

import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import org.json.JSONArray
import org.json.JSONObject
import ru.foraniy.launcher.core.intOrNull
import ru.foraniy.launcher.core.mapObjects
import ru.foraniy.launcher.core.str
import ru.foraniy.launcher.core.writeTextAtomic
import ru.foraniy.launcher.domain.Build
import ru.foraniy.launcher.domain.LoaderType
import java.io.File

/** Persists the list of builds to builds.json (game folders themselves live under builds/<id>/). */
class BuildsRepository(private val file: File) {
    private val _state = MutableStateFlow(read())
    val state: StateFlow<List<Build>> = _state.asStateFlow()

    fun add(build: Build) = edit { it + build }

    fun update(id: String, transform: (Build) -> Build) = edit { list ->
        list.map { if (it.id == id) transform(it) else it }
    }

    fun remove(id: String) = edit { list -> list.filterNot { it.id == id } }

    private fun edit(transform: (List<Build>) -> List<Build>) {
        synchronized(this) {
            val next = transform(_state.value)
            _state.value = next
            runCatching { file.writeTextAtomic(toJson(next).toString(2)) }
        }
    }

    private fun read(): List<Build> = try {
        if (!file.exists()) {
            emptyList()
        } else {
            JSONObject(file.readText()).getJSONArray("builds").mapObjects { j ->
                Build(
                    id = j.getString("id"),
                    name = j.getString("name"),
                    mcVersion = j.getString("mcVersion"),
                    loader = runCatching { LoaderType.valueOf(j.getString("loader")) }.getOrDefault(LoaderType.VANILLA),
                    loaderVersion = j.str("loaderVersion"),
                    ramMb = j.intOrNull("ramMb"),
                    javaPath = j.str("javaPath"),
                    extraJvmArgs = j.optString("extraJvmArgs"),
                    serverAddress = j.optString("serverAddress"),
                    createdAtMs = j.optLong("createdAtMs"),
                    lastPlayedAtMs = j.optLong("lastPlayedAtMs"),
                    coverIndex = j.optInt("coverIndex"),
                )
            }
        }
    } catch (e: Exception) {
        emptyList()
    }

    private fun toJson(list: List<Build>): JSONObject {
        val arr = JSONArray()
        for (b in list) {
            arr.put(
                JSONObject().apply {
                    put("id", b.id)
                    put("name", b.name)
                    put("mcVersion", b.mcVersion)
                    put("loader", b.loader.name)
                    put("loaderVersion", b.loaderVersion ?: JSONObject.NULL)
                    put("ramMb", b.ramMb ?: JSONObject.NULL)
                    put("javaPath", b.javaPath ?: JSONObject.NULL)
                    put("extraJvmArgs", b.extraJvmArgs)
                    put("serverAddress", b.serverAddress)
                    put("createdAtMs", b.createdAtMs)
                    put("lastPlayedAtMs", b.lastPlayedAtMs)
                    put("coverIndex", b.coverIndex)
                },
            )
        }
        return JSONObject().put("builds", arr)
    }
}
