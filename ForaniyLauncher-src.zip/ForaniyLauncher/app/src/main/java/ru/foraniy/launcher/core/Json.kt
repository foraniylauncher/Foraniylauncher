package ru.foraniy.launcher.core

import org.json.JSONArray
import org.json.JSONObject
import java.util.UUID

// Small helpers over org.json (built into Android, so the project has zero JSON dependencies).

/** Null-safe string getter: null when the key is missing or JSON null. */
fun JSONObject.str(key: String): String? = if (has(key) && !isNull(key)) optString(key) else null

fun JSONObject.intOrNull(key: String): Int? = if (has(key) && !isNull(key)) optInt(key) else null

fun JSONObject.obj(key: String): JSONObject? = optJSONObject(key)

fun JSONObject.arr(key: String): JSONArray? = optJSONArray(key)

/** Maps every JSON object element of the array (non-object elements are skipped). */
inline fun <T> JSONArray.mapObjects(transform: (JSONObject) -> T): List<T> {
    val out = ArrayList<T>(length())
    for (i in 0 until length()) {
        val o = optJSONObject(i) ?: continue
        out.add(transform(o))
    }
    return out
}

fun JSONArray.strings(): List<String> {
    val out = ArrayList<String>(length())
    for (i in 0 until length()) out.add(optString(i))
    return out
}

fun jsonObjectOf(vararg pairs: Pair<String, Any?>): JSONObject {
    val o = JSONObject()
    for ((k, v) in pairs) o.put(k, v)
    return o
}

/** Short random id used for builds. */
fun newId(): String = UUID.randomUUID().toString().replace("-", "").take(10)
