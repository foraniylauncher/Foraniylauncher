package ru.foraniy.launcher.minecraft

/** A validated "host[:port]" server address (IPv6 literals are not supported). */
data class ServerAddress(val host: String, val port: Int) {
    /** What to show to the user: the default port is hidden. */
    val display: String get() = if (port == DEFAULT_PORT) host else "$host:$port"

    /** What Minecraft's quick-play argument expects. */
    val hostPort: String get() = "$host:$port"

    companion object {
        const val DEFAULT_PORT = 25565
        private val HOST = Regex("^[A-Za-z0-9]([A-Za-z0-9.-]{0,251}[A-Za-z0-9])?$")

        /** Returns null for blank or malformed input. */
        fun parse(text: String): ServerAddress? {
            val t = text.trim()
            if (t.isEmpty()) return null
            val colon = t.lastIndexOf(':')
            val host: String
            val port: Int
            if (colon >= 0) {
                host = t.substring(0, colon)
                port = t.substring(colon + 1).toIntOrNull() ?: return null
                if (port !in 1..65535) return null
            } else {
                host = t
                port = DEFAULT_PORT
            }
            return if (HOST.matches(host)) ServerAddress(host, port) else null
        }
    }
}
