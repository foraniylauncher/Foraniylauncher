package ru.foraniy.launcher.core

import java.io.File

/**
 * Disk layout (everything under [root], default <external files dir>/ForaniyLauncher):
 *
 *   versions/<id>/<id>.json|.jar   vanilla + Fabric profiles (shared by all builds)
 *   libraries/                     maven-style library cache (shared)
 *   assets/indexes, assets/objects Mojang assets (shared)
 *   runtimes/java<N>/              installed Java runtimes
 *   builds/<buildId>/              GAME DIRECTORY of one build: saves, mods, resourcepacks, config...
 *   cache/                         manifest cache, temporary downloads
 *   logs/latest.log                last game launch log
 */
class LauncherPaths(val root: File) {
    val versions = File(root, "versions")
    val libraries = File(root, "libraries")
    val assets = File(root, "assets")
    val assetIndexes = File(assets, "indexes")
    val assetObjects = File(assets, "objects")
    val runtimes = File(root, "runtimes")
    val builds = File(root, "builds")
    val cache = File(root, "cache")
    val logs = File(root, "logs")

    fun versionDir(id: String) = File(versions, id)
    fun versionJson(id: String) = File(versionDir(id), "$id.json")
    fun versionJar(id: String) = File(versionDir(id), "$id.jar")
    fun buildDir(buildId: String) = File(builds, buildId)
    fun assetObject(hash: String) = File(assetObjects, hash.substring(0, 2) + "/" + hash)
    fun runtimeDir(major: Int) = File(runtimes, "java$major")

    fun ensureDirs() {
        listOf(versions, libraries, assetIndexes, assetObjects, runtimes, builds, cache, logs).forEach { it.mkdirs() }
    }
}
