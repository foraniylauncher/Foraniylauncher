package ru.foraniy.launcher.data

import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import org.json.JSONArray
import org.json.JSONObject
import ru.foraniy.launcher.core.SecretBox
import ru.foraniy.launcher.core.mapObjects
import ru.foraniy.launcher.core.writeTextAtomic
import ru.foraniy.launcher.domain.Account
import ru.foraniy.launcher.domain.AccountType
import java.io.File

/** Persists accounts to accounts.json. Tokens are encrypted with [SecretBox]; in memory they are plain. */
class AccountsRepository(private val file: File) {
    private val _state = MutableStateFlow(read())
    val state: StateFlow<List<Account>> = _state.asStateFlow()

    fun upsert(account: Account) = edit { list ->
        if (list.any { it.id == account.id }) list.map { if (it.id == account.id) account else it } else list + account
    }

    fun remove(id: String) = edit { list -> list.filterNot { it.id == id } }

    private fun edit(transform: (List<Account>) -> List<Account>) {
        synchronized(this) {
            val next = transform(_state.value)
            _state.value = next
            runCatching { file.writeTextAtomic(toJson(next).toString(2)) }
        }
    }

    private fun read(): List<Account> = try {
        if (!file.exists()) {
            emptyList()
        } else {
            JSONObject(file.readText()).getJSONArray("accounts").mapObjects { j ->
                Account(
                    id = j.getString("id"),
                    type = runCatching { AccountType.valueOf(j.getString("type")) }.getOrDefault(AccountType.OFFLINE),
                    name = j.getString("name"),
                    uuid = j.getString("uuid"),
                    msRefreshToken = SecretBox.decrypt(j.optString("refresh")),
                    mcAccessToken = SecretBox.decrypt(j.optString("access")),
                    mcExpiresAtMs = j.optLong("expires"),
                )
            }
        }
    } catch (e: Exception) {
        emptyList()
    }

    private fun toJson(list: List<Account>): JSONObject {
        val arr = JSONArray()
        for (a in list) {
            arr.put(
                JSONObject().apply {
                    put("id", a.id)
                    put("type", a.type.name)
                    put("name", a.name)
                    put("uuid", a.uuid)
                    // If the Keystore is unavailable we store no token: the user just signs in again.
                    put("refresh", runCatching { SecretBox.encrypt(a.msRefreshToken) }.getOrDefault(""))
                    put("access", runCatching { SecretBox.encrypt(a.mcAccessToken) }.getOrDefault(""))
                    put("expires", a.mcExpiresAtMs)
                },
            )
        }
        return JSONObject().put("accounts", arr)
    }
}
