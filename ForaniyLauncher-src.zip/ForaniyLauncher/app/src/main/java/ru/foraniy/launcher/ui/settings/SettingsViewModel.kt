package ru.foraniy.launcher.ui.settings

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.Job
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.launch
import ru.foraniy.launcher.AppContainer
import ru.foraniy.launcher.core.userMessage
import ru.foraniy.launcher.domain.JavaMode
import ru.foraniy.launcher.domain.LauncherSettings

sealed interface JavaInstallState {
    data object Idle : JavaInstallState
    data class Running(val major: Int, val label: String, val fraction: Float?) : JavaInstallState
    data class Failed(val message: String) : JavaInstallState
}

class SettingsViewModel(private val c: AppContainer) : ViewModel() {
    val settings: StateFlow<LauncherSettings> = c.settings.state

    /** Java majors Minecraft versions need: 8 (<=1.16), 17 (1.17-1.20.4), 21 (1.20.5+). */
    val javaMajors = listOf(8, 17, 21)

    private val _installed = MutableStateFlow(javaMajors.filter { c.javaRuntimes.installed(it) != null }.toSet())
    val installed: StateFlow<Set<Int>> = _installed.asStateFlow()

    private val _install = MutableStateFlow<JavaInstallState>(JavaInstallState.Idle)
    val install: StateFlow<JavaInstallState> = _install.asStateFlow()
    private var job: Job? = null

    val maxRamMb: Int get() = ((c.deviceMemoryMb() * 3 / 4) / 256 * 256).coerceIn(1024, 16384)
    val deviceRamMb: Int get() = c.deviceMemoryMb()

    /** Shown path: never creates folders (the user may be mid-typing). */
    fun effectiveRoot(): String =
        c.settings.state.value.gameRootOverride.trim().ifEmpty { c.paths.defaultRoot().path }

    fun edit(transform: (LauncherSettings) -> LauncherSettings) = c.settings.edit(transform)

    fun installJava(major: Int, url: String) {
        if (job?.isActive == true) return
        c.settings.edit { it.copy(runtimeUrls = it.runtimeUrls + (major to url.trim())) }
        job = viewModelScope.launch {
            _install.value = JavaInstallState.Running(major, "Подготовка…", null)
            try {
                c.javaRuntimes.install(major, url.trim()) { label, fraction ->
                    _install.value = JavaInstallState.Running(major, label, fraction)
                }
                refreshInstalled()
                _install.value = JavaInstallState.Idle
            } catch (e: CancellationException) {
                _install.value = JavaInstallState.Idle
                throw e
            } catch (e: Exception) {
                _install.value = JavaInstallState.Failed(e.userMessage())
            }
        }
    }

    fun cancelInstall() {
        job?.cancel()
    }

    fun dismissInstallError() {
        _install.value = JavaInstallState.Idle
    }

    fun uninstallJava(major: Int) {
        c.javaRuntimes.uninstall(major)
        refreshInstalled()
    }

    fun useCustomJava(custom: Boolean) = edit { it.copy(javaMode = if (custom) JavaMode.CUSTOM else JavaMode.AUTO) }

    private fun refreshInstalled() {
        _installed.value = javaMajors.filter { c.javaRuntimes.installed(it) != null }.toSet()
    }
}
