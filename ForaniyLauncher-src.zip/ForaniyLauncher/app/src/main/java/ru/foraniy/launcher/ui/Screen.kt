package ru.foraniy.launcher.ui

import androidx.annotation.DrawableRes
import ru.foraniy.launcher.R

/** Top-level destinations, in bottom-bar order (same structure as Millida: Play, Builds, Catalog, Accounts, Settings). */
enum class Screen(@DrawableRes val icon: Int, val label: String) {
    PLAY(R.drawable.ic_play, "Играть"),
    BUILDS(R.drawable.ic_builds, "Сборки"),
    CATALOG(R.drawable.ic_catalog, "Каталог"),
    ACCOUNTS(R.drawable.ic_user, "Аккаунты"),
    SETTINGS(R.drawable.ic_settings, "Настройки"),
}
