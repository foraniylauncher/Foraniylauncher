package ru.foraniy.launcher.auth

import ru.foraniy.launcher.domain.Account
import ru.foraniy.launcher.domain.AccountType
import java.util.UUID

/** Offline ("play by nickname") accounts: no login, deterministic UUID exactly like the vanilla server does it. */
object OfflineAuth {
    private val NAME = Regex("^[A-Za-z0-9_]{3,16}$")

    /** Returns an error message, or null if [name] is a valid Minecraft nickname. */
    fun validate(name: String): String? =
        if (NAME.matches(name)) null else "Ник: 3–16 символов, латиница, цифры и _"

    fun uuidFor(name: String): String =
        UUID.nameUUIDFromBytes("OfflinePlayer:$name".toByteArray(Charsets.UTF_8)).toString().replace("-", "")

    fun createAccount(name: String): Account =
        Account(id = "offline:$name", type = AccountType.OFFLINE, name = name, uuid = uuidFor(name))
}
