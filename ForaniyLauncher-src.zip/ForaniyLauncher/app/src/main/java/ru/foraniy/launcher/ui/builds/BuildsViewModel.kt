package ru.foraniy.launcher.ui.builds

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import ru.foraniy.launcher.AppContainer
import ru.foraniy.launcher.catalog.ContentType
import ru.foraniy.launcher.core.newId
import ru.foraniy.launcher.core.userMessage
import ru.foraniy.launcher.domain.Build
import ru.foraniy.launcher.domain.LoaderType
import ru.foraniy.launcher.minecraft.VersionEntry
import java.io.File

sealed interface VersionsState {
    data object Loading : VersionsState
    data class Ready(val all: List<VersionEntry>) : VersionsState
    data class Failed(val message: String) : VersionsState
}

/** What the editor dialog produces. [id] == null means "create". */
data class BuildDraft(
    val id: String?,
    val name: String,
    val mcVersion: String,
    val loader: LoaderType,
    val ramMb: Int?,
    val javaPath: String,
    val jvmArgs: String,
    val serverAddress: String,
)

class BuildsViewModel(private val c: AppContainer) : ViewModel() {
    val builds = c.builds.state
    val settings = c.settings.state

    private val _versions = MutableStateFlow<VersionsState>(VersionsState.Loading)
    val versions: StateFlow<VersionsState> = _versions.asStateFlow()

    init {
        loadVersions()
    }

    fun loadVersions() {
        _versions.value = VersionsState.Loading
        viewModelScope.launch {
            _versions.value = try {
                VersionsState.Ready(c.versions.manifest())
            } catch (e: CancellationException) {
                throw e
            } catch (e: Exception) {
                VersionsState.Failed(e.userMessage())
            }
        }
    }

    fun maxRamMb(): Int = ((c.deviceMemoryMb() * 3 / 4) / 256 * 256).coerceIn(1024, 16384)

    fun isVersionInstalled(id: String): Boolean = c.versions.isInstalled(id)

    fun save(d: BuildDraft) {
        val server = d.serverAddress.trim()
        if (d.id == null) {
            val build = Build(
                id = newId(),
                name = d.name.trim(),
                mcVersion = d.mcVersion,
                loader = d.loader,
                ramMb = d.ramMb,
                javaPath = d.javaPath.trim().ifEmpty { null },
                extraJvmArgs = d.jvmArgs.trim(),
                serverAddress = server,
                createdAtMs = System.currentTimeMillis(),
                coverIndex = c.builds.state.value.size,
            )
            c.builds.add(build)
            if (c.settings.state.value.selectedBuildId == null) select(build.id)
        } else {
            c.builds.update(d.id) { old ->
                val changed = old.mcVersion != d.mcVersion || old.loader != d.loader
                old.copy(
                    name = d.name.trim(),
                    mcVersion = d.mcVersion,
                    loader = d.loader,
                    // a different Minecraft version or loader needs a fresh loader version
                    loaderVersion = if (changed) null else old.loaderVersion,
                    ramMb = d.ramMb,
                    javaPath = d.javaPath.trim().ifEmpty { null },
                    extraJvmArgs = d.jvmArgs.trim(),
                    serverAddress = server,
                )
            }
        }
    }

    fun select(id: String) {
        c.settings.edit { it.copy(selectedBuildId = id) }
    }

    fun delete(build: Build) {
        c.builds.remove(build.id)
        if (c.settings.state.value.selectedBuildId == build.id) {
            c.settings.edit { it.copy(selectedBuildId = c.builds.state.value.firstOrNull()?.id) }
        }
        viewModelScope.launch(Dispatchers.IO) { c.paths.current().buildDir(build.id).deleteRecursively() }
    }

    fun duplicate(build: Build) {
        val copy = build.copy(
            id = newId(),
            name = build.name + " (копия)",
            createdAtMs = System.currentTimeMillis(),
            lastPlayedAtMs = 0L,
        )
        c.builds.add(copy)
        viewModelScope.launch(Dispatchers.IO) {
            val p = c.paths.current()
            runCatching { p.buildDir(build.id).copyRecursively(p.buildDir(copy.id), overwrite = true) }
        }
    }

    fun listContent(build: Build, type: ContentType): List<File> = c.content.listInstalled(build, type)

    suspend fun deleteContent(file: File) {
        withContext(Dispatchers.IO) { file.delete() }
    }
}
