package ru.foraniy.launcher.ui.catalog

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.FlowPreview
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.collectLatest
import kotlinx.coroutines.flow.debounce
import kotlinx.coroutines.flow.distinctUntilChanged
import kotlinx.coroutines.flow.map
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.launch
import ru.foraniy.launcher.AppContainer
import ru.foraniy.launcher.catalog.ContentProject
import ru.foraniy.launcher.catalog.ContentType
import ru.foraniy.launcher.core.userMessage
import ru.foraniy.launcher.domain.LoaderType

data class CatalogUi(
    val query: String = "",
    val type: ContentType = ContentType.MOD,
    val targetBuildId: String? = null,
    val loading: Boolean = false,
    val results: List<ContentProject> = emptyList(),
    val error: String? = null,
    val installing: Set<String> = emptySet(),
    val installed: Set<String> = emptySet(),
    val message: String? = null,
)

/** Modrinth search filtered by the target build's Minecraft version and loader; one-tap install into that build. */
@OptIn(FlowPreview::class)
class CatalogViewModel(private val c: AppContainer) : ViewModel() {
    val builds = c.builds.state

    private val _ui = MutableStateFlow(CatalogUi())
    val ui: StateFlow<CatalogUi> = _ui.asStateFlow()

    init {
        val first = c.settings.state.value.selectedBuildId ?: c.builds.state.value.firstOrNull()?.id
        _ui.update { it.copy(targetBuildId = first) }
        viewModelScope.launch {
            _ui.map { Triple(it.query, it.type, it.targetBuildId) }
                .distinctUntilChanged()
                .debounce(350)
                .collectLatest { (q, type, buildId) -> search(q, type, buildId) }
        }
    }

    fun setQuery(q: String) = _ui.update { it.copy(query = q) }
    fun setType(t: ContentType) = _ui.update { it.copy(type = t) }
    fun setTarget(id: String) = _ui.update { it.copy(targetBuildId = id) }
    fun dismissMessage() = _ui.update { it.copy(message = null) }

    private suspend fun search(q: String, type: ContentType, buildId: String?) {
        val build = c.builds.state.value.firstOrNull { it.id == buildId }
        _ui.update { it.copy(loading = true, error = null) }
        try {
            val res = c.modrinth.search(q.trim(), type, build?.mcVersion, build?.loader?.modrinthName)
            _ui.update { it.copy(loading = false, results = res) }
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            _ui.update { it.copy(loading = false, results = emptyList(), error = e.userMessage()) }
        }
    }

    fun install(p: ContentProject) {
        val build = c.builds.state.value.firstOrNull { it.id == _ui.value.targetBuildId }
        if (build == null) {
            _ui.update { it.copy(message = "Сначала создайте сборку и выберите её выше") }
            return
        }
        if (p.type == ContentType.MOD && build.loader != LoaderType.FABRIC) {
            _ui.update { it.copy(message = "Моды работают только в сборках с Fabric. Измените загрузчик сборки «${build.name}».") }
            return
        }
        viewModelScope.launch {
            _ui.update { it.copy(installing = it.installing + p.id) }
            try {
                val files = c.content.install(p, build)
                _ui.update {
                    it.copy(
                        installing = it.installing - p.id,
                        installed = it.installed + p.id,
                        message = "Установлено файлов: ${files.size}. Сборка «${build.name}»",
                    )
                }
            } catch (e: CancellationException) {
                throw e
            } catch (e: Exception) {
                _ui.update { it.copy(installing = it.installing - p.id, message = e.userMessage()) }
            }
        }
    }
}
