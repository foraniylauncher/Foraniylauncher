package ru.foraniy.launcher.ui.components

import androidx.compose.animation.core.LinearEasing
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.BoxScope
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.remember
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.unit.dp
import ru.foraniy.launcher.ui.theme.FxBg
import ru.foraniy.launcher.ui.theme.FxSoft
import ru.foraniy.launcher.ui.theme.LocalAccent
import kotlin.math.cos
import kotlin.math.max
import kotlin.math.sin
import kotlin.random.Random

private class Star(val x: Float, val y: Float, val r: Float, val a: Float)

/**
 * App background: dark gradient, three slowly drifting neon glows (40 s loop, tinted by the accent) and faint stars.
 * Mirrors design/backgrounds/bg-nebula-portrait.svg. Drawn in a Canvas, so there are no bitmaps to ship.
 */
@Composable
fun ForaniyBackground(modifier: Modifier = Modifier, content: @Composable BoxScope.() -> Unit) {
    val accent = LocalAccent.current
    val transition = rememberInfiniteTransition(label = "background")
    val phase by transition.animateFloat(
        initialValue = 0f,
        targetValue = (2 * Math.PI).toFloat(),
        animationSpec = infiniteRepeatable(tween(40_000, easing = LinearEasing)),
        label = "phase",
    )
    val stars = remember {
        val rnd = Random(7)
        List(70) { Star(rnd.nextFloat(), rnd.nextFloat(), 0.5f + rnd.nextFloat() * 1.2f, 0.12f + rnd.nextFloat() * 0.5f) }
    }

    Box(modifier.fillMaxSize().background(FxBg)) {
        Canvas(Modifier.fillMaxSize()) {
            val w = size.width
            val h = size.height
            val big = max(w, h)
            drawRect(Brush.verticalGradient(listOf(Color(0xFF120A24), Color(0xFF07040F))))

            fun glow(cx: Float, cy: Float, radius: Float, color: Color, alpha: Float) {
                val center = Offset(w * cx, h * cy)
                drawCircle(
                    brush = Brush.radialGradient(listOf(color.copy(alpha = alpha), Color.Transparent), center = center, radius = radius),
                    radius = radius,
                    center = center,
                )
            }
            glow(0.15f + 0.04f * sin(phase), 0.10f + 0.03f * cos(phase), big * 0.55f, accent.deep, 0.38f)
            glow(0.90f + 0.03f * cos(phase * 1.3f), 0.55f + 0.04f * sin(phase), big * 0.45f, accent.main, 0.20f)
            glow(0.25f + 0.04f * sin(phase * 0.7f), 0.97f, big * 0.55f, Color(0xFF4C1D95), 0.42f)

            val unit = 1.dp.toPx()
            for (s in stars) {
                drawCircle(FxSoft.copy(alpha = s.a), s.r * unit, Offset(s.x * w, s.y * h))
            }
        }
        content()
    }
}
