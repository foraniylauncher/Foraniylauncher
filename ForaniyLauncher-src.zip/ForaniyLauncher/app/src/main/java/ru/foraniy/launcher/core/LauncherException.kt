package ru.foraniy.launcher.core

/**
 * Expected, user-presentable failure. The message is shown to the user as is (Russian).
 * [needJava] is set when the fix is "install Java N" so the UI can offer a shortcut.
 */
class LauncherException(
    message: String,
    val needJava: Int? = null,
    cause: Throwable? = null,
) : Exception(message, cause)
