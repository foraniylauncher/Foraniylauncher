package ru.foraniy.launcher.data

import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import org.json.JSONObject
import ru.foraniy.launcher.core.str
import ru.foraniy.launcher.core.writeTextAtomic
import ru.foraniy.launcher.domain.JavaMode
import ru.foraniy.launcher.domain.LauncherSettings
import java.io.File

/** Persists [LauncherSettings] to settings.json. Every change is saved immediately (no "Save" button anywhere). */
class SettingsRepository(private val file: File) {
    private val _state = MutableStateFlow(read())
    val state: StateFlow<LauncherSettings> = _state.asStateFlow()

    fun edit(transform: (LauncherSettings) -> LauncherSettings) {
        synchronized(this) {
            val next = transform(_state.value)
            _state.value = next
            runCatching { file.writeTextAtomic(toJson(next).toString(2)) }
        }
    }

    private fun read(): LauncherSettings = try {
        if (file.exists()) fromJson(JSONObject(file.readText())) else LauncherSettings()
    } catch (e: Exception) {
        LauncherSettings()
    }

    private fun toJson(s: LauncherSettings): JSONObject {
        val urls = JSONObject()
        for ((major, url) in s.runtimeUrls) urls.put(major.toString(), url)
        return JSONObject().apply {
            put("ramMb", s.ramMb)
            put("javaMode", s.javaMode.name)
            put("customJavaPath", s.customJavaPath)
            put("runtimeUrls", urls)
            put("gameRootOverride", s.gameRootOverride)
            put("accentIndex", s.accentIndex)
            put("showSnapshots", s.showSnapshots)
            put("showOldVersions", s.showOldVersions)
            put("verifyBeforeLaunch", s.verifyBeforeLaunch)
            put("selectedBuildId", s.selectedBuildId ?: JSONObject.NULL)
            put("selectedAccountId", s.selectedAccountId ?: JSONObject.NULL)
        }
    }

    private fun fromJson(j: JSONObject): LauncherSettings {
        val d = LauncherSettings()
        val urls = HashMap<Int, String>()
        j.optJSONObject("runtimeUrls")?.let { o ->
            o.keys().forEach { k -> k.toIntOrNull()?.let { major -> urls[major] = o.optString(k) } }
        }
        return LauncherSettings(
            ramMb = j.optInt("ramMb", d.ramMb),
            javaMode = runCatching { JavaMode.valueOf(j.optString("javaMode")) }.getOrDefault(d.javaMode),
            customJavaPath = j.optString("customJavaPath", d.customJavaPath),
            runtimeUrls = urls,
            gameRootOverride = j.optString("gameRootOverride", d.gameRootOverride),
            accentIndex = j.optInt("accentIndex", d.accentIndex),
            showSnapshots = j.optBoolean("showSnapshots", d.showSnapshots),
            showOldVersions = j.optBoolean("showOldVersions", d.showOldVersions),
            verifyBeforeLaunch = j.optBoolean("verifyBeforeLaunch", d.verifyBeforeLaunch),
            selectedBuildId = j.str("selectedBuildId"),
            selectedAccountId = j.str("selectedAccountId"),
        )
    }
}
