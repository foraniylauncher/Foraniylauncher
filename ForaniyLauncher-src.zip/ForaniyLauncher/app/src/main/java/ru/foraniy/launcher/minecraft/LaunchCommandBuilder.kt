package ru.foraniy.launcher.minecraft

import ru.foraniy.launcher.core.LauncherPaths
import java.io.File

data class LaunchAccount(
    val name: String,
    /** UUID without dashes. */
    val uuid: String,
    val accessToken: String,
    /** "msa" for Microsoft accounts, "legacy" for offline. */
    val userType: String,
)

class LaunchRequest(
    val version: ResolvedVersion,
    val paths: LauncherPaths,
    val gameDir: File,
    val account: LaunchAccount,
    val javaExecutable: String,
    val ramMb: Int,
    val extraJvmArgs: List<String> = emptyList(),
    val windowWidth: Int? = null,
    val windowHeight: Int? = null,
    /** "host[:port]" to join automatically, blank/invalid = none. */
    val serverAddress: String? = null,
)

/** Builds the full `java ...` command line. Pure function: same input, same output, nothing touches the disk. */
object LaunchCommandBuilder {
    const val LAUNCHER_NAME = "ForaniyLauncher"
    const val LAUNCHER_VERSION = "0.1.0"

    private val PLACEHOLDER = Regex("""\$\{([A-Za-z0-9_]+)\}""")

    fun build(r: LaunchRequest): List<String> {
        val v = r.version
        val separator = ":"

        val libraryFiles = v.libraries.map { File(r.paths.libraries, it.path) }.filter { it.isFile }.map { it.absolutePath }
        val classpath = (libraryFiles + r.paths.versionJar(v.clientJarId).absolutePath).distinct().joinToString(separator)

        val baseVars = mapOf(
            "auth_player_name" to r.account.name,
            "auth_uuid" to r.account.uuid,
            "auth_access_token" to r.account.accessToken,
            "auth_session" to "token:${r.account.accessToken}:${r.account.uuid}",
            "auth_xuid" to "0",
            "clientid" to "",
            "user_type" to r.account.userType,
            "user_properties" to "{}",
            "version_name" to v.id,
            "version_type" to v.type,
            "game_directory" to r.gameDir.absolutePath,
            "assets_root" to r.paths.assets.absolutePath,
            "game_assets" to File(r.paths.assets, "virtual/legacy").absolutePath,
            "assets_index_name" to (v.assetIndex?.id ?: v.id),
            "natives_directory" to File(r.paths.versionDir(v.id), "natives").absolutePath,
            "launcher_name" to LAUNCHER_NAME,
            "launcher_version" to LAUNCHER_VERSION,
            "classpath" to classpath,
            "classpath_separator" to separator,
            "library_directory" to r.paths.libraries.absolutePath,
            "resolution_width" to (r.windowWidth ?: 854).toString(),
            "resolution_height" to (r.windowHeight ?: 480).toString(),
        )

        // Auto-join: Minecraft 1.20+ declares a quick-play argument in its version JSON; older versions
        // understand the classic --server/--port pair.
        val server = r.serverAddress?.let { ServerAddress.parse(it) }
        val supportsQuickPlay = v.gameArgs.any { item ->
            item.rules.any { rule -> rule.features.containsKey("is_quick_play_multiplayer") }
        }
        val vars = if (server != null) baseVars + ("quickPlayMultiplayer" to server.hostPort) else baseVars

        val features = mapOf(
            "has_custom_resolution" to (r.windowWidth != null && r.windowHeight != null),
            "is_demo_user" to false,
            "has_quick_plays_support" to false,
            "is_quick_play_singleplayer" to false,
            "is_quick_play_multiplayer" to (server != null && supportsQuickPlay),
            "is_quick_play_realms" to false,
        )

        fun expand(items: List<ArgItem>): List<String> = items
            .filter { VersionJson.rulesAllow(it.rules, features) }
            .flatMap { it.values }
            .map { substitute(it, vars) }

        val command = ArrayList<String>()
        command += r.javaExecutable
        command += "-Xmx${r.ramMb}M"
        command += "-Xms${minOf(r.ramMb, 512)}M"
        command += expand(v.jvmArgs)
        command += r.extraJvmArgs
        command += v.mainClass
        command += expand(v.gameArgs)
        if (server != null && !supportsQuickPlay) {
            command += listOf("--server", server.host, "--port", server.port.toString())
        }
        return command
    }

    private fun substitute(s: String, vars: Map<String, String>): String =
        PLACEHOLDER.replace(s) { m -> vars[m.groupValues[1]] ?: m.value }
}
