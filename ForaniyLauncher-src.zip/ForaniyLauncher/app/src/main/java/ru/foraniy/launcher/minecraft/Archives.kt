package ru.foraniy.launcher.minecraft

import java.io.EOFException
import java.io.File
import java.io.IOException
import java.io.InputStream
import java.io.OutputStream
import java.nio.file.Files
import java.nio.file.Paths
import java.util.zip.GZIPInputStream
import java.util.zip.ZipInputStream

/** Safe .zip and .tar.gz extraction (no extra dependencies) used to install Java runtimes. */
object Archives {
    enum class Kind { ZIP, TAR_GZ, UNKNOWN }

    /** Detects the format by magic bytes, because download urls often have no extension. */
    fun sniff(file: File): Kind {
        val head = ByteArray(2)
        val n = file.inputStream().use { it.read(head) }
        if (n < 2) return Kind.UNKNOWN
        return when {
            head[0] == 0x1f.toByte() && head[1] == 0x8b.toByte() -> Kind.TAR_GZ
            head[0] == 'P'.code.toByte() && head[1] == 'K'.code.toByte() -> Kind.ZIP
            else -> Kind.UNKNOWN
        }
    }

    fun unzip(archive: File, dest: File) {
        val root = dest.canonicalFile
        ZipInputStream(archive.inputStream().buffered()).use { zip ->
            var entry = zip.nextEntry
            while (entry != null) {
                val out = safeChild(root, entry.name)
                if (entry.isDirectory) {
                    out.mkdirs()
                } else {
                    out.parentFile?.mkdirs()
                    out.outputStream().use { zip.copyTo(it) }
                    if (looksExecutable(entry.name)) out.setExecutable(true, false)
                }
                entry = zip.nextEntry
            }
        }
    }

    fun untarGz(archive: File, dest: File) {
        val root = dest.canonicalFile
        GZIPInputStream(archive.inputStream().buffered(), 64 * 1024).use { input ->
            val header = ByteArray(512)
            var pendingName: String? = null
            while (readFully(input, header)) {
                if (header.all { it == 0.toByte() }) break
                val size = octal(header, 124, 12)
                val padding = (512 - size % 512) % 512
                val type = (header[156].toInt() and 0xff).toChar()

                // Long-name / PAX extension headers carry data for the NEXT entry.
                if (type == 'L') {
                    pendingName = String(readN(input, size), Charsets.UTF_8).trimEnd('\u0000')
                    skipFully(input, padding)
                    continue
                }
                if (type == 'x') {
                    val pax = String(readN(input, size), Charsets.UTF_8)
                    skipFully(input, padding)
                    paxPath(pax)?.let { pendingName = it }
                    continue
                }
                if (type == 'g') {
                    skipFully(input, size + padding)
                    continue
                }

                var name = cString(header, 0, 100)
                if (cString(header, 257, 6).startsWith("ustar")) {
                    val prefix = cString(header, 345, 155)
                    if (prefix.isNotEmpty()) name = "$prefix/$name"
                }
                pendingName?.let {
                    name = it
                    pendingName = null
                }
                val mode = octal(header, 100, 8).toInt()
                val link = cString(header, 157, 100)
                val out = safeChild(root, name)

                when (type) {
                    '5' -> out.mkdirs()
                    '2' -> {
                        skipFully(input, size + padding)
                        symlink(root, out, link)
                    }
                    '0', '\u0000', '7' -> {
                        out.parentFile?.mkdirs()
                        out.outputStream().use { copyN(input, it, size) }
                        skipFully(input, padding)
                        if ((mode and 0b001001001) != 0) out.setExecutable(true, false)
                    }
                    else -> skipFully(input, size + padding)
                }
            }
        }
    }

    private fun looksExecutable(name: String) = name.contains("/bin/") || name.endsWith("/jspawnhelper")

    /** Zip-slip guard: the resolved path must stay inside [root]. */
    private fun safeChild(root: File, name: String): File {
        val f = File(root, name).canonicalFile
        if (f.path != root.path && !f.path.startsWith(root.path + File.separator)) {
            throw IOException("Небезопасный путь в архиве: $name")
        }
        return f
    }

    private fun symlink(root: File, out: File, link: String) {
        if (link.isEmpty()) return
        val parent = out.parentFile ?: return
        val resolved = parent.toPath().resolve(link).normalize()
        if (!resolved.startsWith(root.toPath())) return // never link outside the runtime folder
        parent.mkdirs()
        Files.deleteIfExists(out.toPath())
        Files.createSymbolicLink(out.toPath(), Paths.get(link))
    }

    private fun paxPath(pax: String): String? {
        for (line in pax.split('\n')) {
            val space = line.indexOf(' ')
            if (space < 0) continue
            val kv = line.substring(space + 1)
            if (kv.startsWith("path=")) return kv.removePrefix("path=")
        }
        return null
    }

    private fun octal(b: ByteArray, off: Int, len: Int): Long {
        val s = String(b, off, len, Charsets.US_ASCII).trim { it == '\u0000' || it == ' ' }
        return if (s.isEmpty()) 0L else s.toLong(8)
    }

    private fun cString(b: ByteArray, off: Int, len: Int): String {
        var end = off
        while (end < off + len && b[end] != 0.toByte()) end++
        return String(b, off, end - off, Charsets.UTF_8)
    }

    private fun readFully(input: InputStream, buf: ByteArray): Boolean {
        var read = 0
        while (read < buf.size) {
            val n = input.read(buf, read, buf.size - read)
            if (n < 0) return false
            read += n
        }
        return true
    }

    private fun readN(input: InputStream, count: Long): ByteArray {
        val out = ByteArray(count.toInt())
        if (!readFully(input, out)) throw EOFException("Архив обрезан")
        return out
    }

    private fun skipFully(input: InputStream, count: Long) {
        var left = count
        while (left > 0) {
            val s = input.skip(left)
            if (s > 0) {
                left -= s
            } else {
                if (input.read() < 0) break
                left--
            }
        }
    }

    private fun copyN(input: InputStream, out: OutputStream, count: Long) {
        val buf = ByteArray(64 * 1024)
        var left = count
        while (left > 0) {
            val n = input.read(buf, 0, minOf(buf.size.toLong(), left).toInt())
            if (n < 0) throw EOFException("Архив обрезан")
            out.write(buf, 0, n)
            left -= n
        }
    }
}
