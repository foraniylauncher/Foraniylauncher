package ru.foraniy.launcher.minecraft

import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import org.json.JSONArray
import org.json.JSONObject
import ru.foraniy.launcher.core.Http
import ru.foraniy.launcher.core.Http.enc
import ru.foraniy.launcher.core.mapObjects
import ru.foraniy.launcher.core.writeTextAtomic
import ru.foraniy.launcher.data.PathsProvider

/** Fabric support through meta.fabricmc.net: loader versions and the launcher profile JSON (inherits vanilla). */
class FabricMeta(private val paths: PathsProvider) {

    /** Newest first. */
    suspend fun loaderVersions(mcVersion: String): List<String> {
        val body = Http.get("$BASE/versions/loader/${enc(mcVersion)}").requireOk().body
        return JSONArray(body).mapObjects { it.getJSONObject("loader").getString("version") }
    }

    fun profileId(mcVersion: String, loaderVersion: String) = "fabric-loader-$loaderVersion-$mcVersion"

    /** Makes sure versions/<profileId>/<profileId>.json exists; returns the profile id. No network if already present. */
    suspend fun ensureProfile(mcVersion: String, loaderVersion: String): String = withContext(Dispatchers.IO) {
        val id = profileId(mcVersion, loaderVersion)
        val file = paths.current().versionJson(id)
        if (!file.exists()) {
            val body = Http.get("$BASE/versions/loader/${enc(mcVersion)}/${enc(loaderVersion)}/profile/json").requireOk().body
            // Trust the id inside the JSON, it is what the launcher folder must be called.
            val realId = JSONObject(body).getString("id")
            val target = paths.current().versionJson(realId)
            target.writeTextAtomic(body)
            return@withContext realId
        }
        id
    }

    private companion object {
        const val BASE = "https://meta.fabricmc.net/v2"
    }
}
