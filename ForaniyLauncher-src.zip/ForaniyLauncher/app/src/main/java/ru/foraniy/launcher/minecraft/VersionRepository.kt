package ru.foraniy.launcher.minecraft

import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import org.json.JSONObject
import ru.foraniy.launcher.core.Http
import ru.foraniy.launcher.core.LauncherException
import ru.foraniy.launcher.core.mapObjects
import ru.foraniy.launcher.core.str
import ru.foraniy.launcher.core.writeTextAtomic
import ru.foraniy.launcher.data.PathsProvider
import java.io.File
import java.io.IOException

/** Mojang version manifest (with an offline disk cache) and resolving a version id to a [ResolvedVersion]. */
class VersionRepository(private val paths: PathsProvider) {

    /** Network first; if offline, falls back to the last cached manifest. */
    suspend fun manifest(): List<VersionEntry> = withContext(Dispatchers.IO) {
        val cache = File(paths.current().cache, "version_manifest_v2.json")
        val text = try {
            Http.get(MANIFEST_URL).requireOk().body.also { cache.writeTextAtomic(it) }
        } catch (e: IOException) {
            if (cache.exists()) cache.readText() else throw LauncherException("Нет подключения к интернету", cause = e)
        }
        JSONObject(text).getJSONArray("versions").mapObjects {
            VersionEntry(
                id = it.getString("id"),
                type = VersionType.parse(it.str("type")),
                url = it.getString("url"),
                sha1 = it.optString("sha1"),
                releaseTime = it.optString("releaseTime"),
            )
        }
    }

    /**
     * Loads versions/<id>/<id>.json (downloading vanilla JSON from the manifest if it is not on disk yet)
     * and follows `inheritsFrom` recursively.
     */
    suspend fun resolve(versionId: String, manifest: List<VersionEntry>): ResolvedVersion = withContext(Dispatchers.IO) {
        val file = paths.current().versionJson(versionId)
        val json = if (file.exists()) {
            JSONObject(file.readText())
        } else {
            val entry = manifest.firstOrNull { it.id == versionId }
                ?: throw LauncherException("Версия $versionId не найдена в списке Mojang")
            val text = Http.get(entry.url).requireOk().body
            file.writeTextAtomic(text)
            JSONObject(text)
        }
        val raw = VersionJson.parse(json)
        val parentId = raw.inheritsFrom
        if (parentId == null) VersionJson.toResolved(raw) else VersionJson.merge(resolve(parentId, manifest), raw)
    }

    fun isInstalled(versionId: String): Boolean = paths.current().versionJson(versionId).exists()

    companion object {
        const val MANIFEST_URL = "https://piston-meta.mojang.com/mc/game/version_manifest_v2.json"
    }
}
