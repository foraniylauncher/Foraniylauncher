package ru.foraniy.launcher.ui.settings

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.unit.dp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import ru.foraniy.launcher.AppContainer
import ru.foraniy.launcher.R
import ru.foraniy.launcher.domain.JavaMode
import ru.foraniy.launcher.ui.Screen
import ru.foraniy.launcher.ui.appViewModel
import ru.foraniy.launcher.ui.components.ButtonKind
import ru.foraniy.launcher.ui.components.ForaniyButton
import ru.foraniy.launcher.ui.components.ForaniyChip
import ru.foraniy.launcher.ui.components.ForaniyDialog
import ru.foraniy.launcher.ui.components.ForaniyProgressBar
import ru.foraniy.launcher.ui.components.ForaniyTextField
import ru.foraniy.launcher.ui.components.HintText
import ru.foraniy.launcher.ui.components.NoticeBox
import ru.foraniy.launcher.ui.components.Panel
import ru.foraniy.launcher.ui.components.ScreenTitle
import ru.foraniy.launcher.ui.components.SectionLabel
import ru.foraniy.launcher.ui.components.SmallIconButton
import ru.foraniy.launcher.ui.components.StatusPill
import ru.foraniy.launcher.ui.components.StepSlider
import ru.foraniy.launcher.ui.components.SwitchRow
import ru.foraniy.launcher.ui.theme.AccentPresets
import ru.foraniy.launcher.ui.theme.FxDanger
import ru.foraniy.launcher.ui.theme.FxGlow
import ru.foraniy.launcher.ui.theme.FxInfo
import ru.foraniy.launcher.ui.theme.FxMuted
import ru.foraniy.launcher.ui.theme.FxSoft
import ru.foraniy.launcher.ui.theme.FxSuccess
import ru.foraniy.launcher.ui.theme.FxText
import ru.foraniy.launcher.ui.theme.FxWarning

@Composable
fun SettingsScreen(container: AppContainer, onNavigate: (Screen) -> Unit) {
    val vm = appViewModel { SettingsViewModel(container) }
    val s by vm.settings.collectAsStateWithLifecycle()
    val installed by vm.installed.collectAsStateWithLifecycle()
    val install by vm.install.collectAsStateWithLifecycle()

    var folderText by remember { mutableStateOf(s.gameRootOverride) }
    var javaDialog by remember { mutableStateOf<Int?>(null) }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .verticalScroll(rememberScrollState())
            .padding(horizontal = 20.dp, vertical = 12.dp),
        verticalArrangement = Arrangement.spacedBy(14.dp),
    ) {
        ScreenTitle("Настройки", "Всё сохраняется автоматически")

        // ---- memory
        SectionLabel("Память")
        Panel(Modifier.fillMaxWidth()) {
            Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                Icon(painterResource(R.drawable.ic_memory), null, Modifier.size(22.dp), tint = FxGlow)
                Text("Выделено ОЗУ", style = MaterialTheme.typography.titleMedium, color = FxText, modifier = Modifier.weight(1f))
                Text("${s.ramMb} МБ", style = MaterialTheme.typography.titleMedium, color = FxGlow)
            }
            StepSlider(s.ramMb, { v -> vm.edit { it.copy(ramMb = v) } }, min = 512, max = vm.maxRamMb, step = 256)
            HintText("Память устройства: ${vm.deviceRamMb} МБ. Не выделяйте больше ~70%, иначе Android закроет игру.")
        }

        // ---- java
        SectionLabel("Java")
        Panel(Modifier.fillMaxWidth()) {
            Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                Icon(painterResource(R.drawable.ic_java), null, Modifier.size(22.dp), tint = FxGlow)
                Text("Среда выполнения", style = MaterialTheme.typography.titleMedium, color = FxText)
            }
            Spacer(Modifier.height(10.dp))
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                ForaniyChip("Авто", s.javaMode == JavaMode.AUTO, { vm.useCustomJava(false) })
                ForaniyChip("Свой путь", s.javaMode == JavaMode.CUSTOM, { vm.useCustomJava(true) })
            }
            Spacer(Modifier.height(12.dp))
            if (s.javaMode == JavaMode.CUSTOM) {
                ForaniyTextField(
                    value = s.customJavaPath,
                    onValueChange = { v -> vm.edit { it.copy(customJavaPath = v) } },
                    label = "Путь к java или папке Java",
                )
            } else {
                vm.javaMajors.forEach { major ->
                    val isInstalled = major in installed
                    Row(Modifier.fillMaxWidth().padding(vertical = 4.dp), verticalAlignment = Alignment.CenterVertically) {
                        Column(Modifier.weight(1f)) {
                            Text("Java $major", style = MaterialTheme.typography.bodyLarge, color = FxText)
                            Text(javaHint(major), style = MaterialTheme.typography.bodySmall, color = FxMuted)
                        }
                        if (isInstalled) StatusPill("Установлена", FxSuccess) else StatusPill("Нет", FxWarning)
                        if (isInstalled) {
                            SmallIconButton(R.drawable.ic_trash, "Удалить Java $major", { vm.uninstallJava(major) }, tint = FxMuted)
                        }
                        SmallIconButton(R.drawable.ic_download, "Установить Java $major", { javaDialog = major })
                    }
                }
            }

            when (val st = install) {
                JavaInstallState.Idle -> Unit
                is JavaInstallState.Running -> {
                    Spacer(Modifier.height(10.dp))
                    Text(st.label, style = MaterialTheme.typography.labelLarge, color = FxText)
                    Spacer(Modifier.height(8.dp))
                    ForaniyProgressBar(st.fraction)
                    Spacer(Modifier.height(10.dp))
                    ForaniyButton("Отмена", vm::cancelInstall, Modifier.fillMaxWidth(), kind = ButtonKind.Outline, height = 44.dp)
                }
                is JavaInstallState.Failed -> {
                    Spacer(Modifier.height(10.dp))
                    NoticeBox(st.message, FxDanger, onClick = vm::dismissInstallError)
                }
            }
            Spacer(Modifier.height(8.dp))
            HintText("Нужна Java, собранная под Android. Обычные JDK для Linux/Windows на телефоне не запустятся.")
        }

        // ---- game folder
        SectionLabel("Папка игры")
        Panel(Modifier.fillMaxWidth()) {
            Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                Icon(painterResource(R.drawable.ic_folder), null, Modifier.size(22.dp), tint = FxGlow)
                Text("Расположение", style = MaterialTheme.typography.titleMedium, color = FxText)
            }
            Spacer(Modifier.height(6.dp))
            Text(vm.effectiveRoot(), style = MaterialTheme.typography.bodySmall, color = FxMuted)
            Spacer(Modifier.height(12.dp))
            ForaniyTextField(folderText, { folderText = it }, "Своя папка (пусто = по умолчанию)")
            Spacer(Modifier.height(10.dp))
            Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                ForaniyButton(
                    "Применить",
                    { vm.edit { it.copy(gameRootOverride = folderText.trim()) } },
                    Modifier.weight(1f),
                    kind = ButtonKind.Tonal,
                    height = 48.dp,
                )
                ForaniyButton(
                    "Сбросить",
                    {
                        folderText = ""
                        vm.edit { it.copy(gameRootOverride = "") }
                    },
                    Modifier.weight(1f),
                    kind = ButtonKind.Outline,
                    height = 48.dp,
                )
            }
            HintText("Уже скачанные файлы в новую папку не переносятся. Папка должна быть доступна приложению для записи.")
        }

        // ---- general
        SectionLabel("Общее")
        Panel(Modifier.fillMaxWidth()) {
            SwitchRow("Показывать снапшоты", s.showSnapshots, { v -> vm.edit { it.copy(showSnapshots = v) } })
            SwitchRow("Старые версии (alpha/beta)", s.showOldVersions, { v -> vm.edit { it.copy(showOldVersions = v) } })
            SwitchRow(
                "Проверять файлы перед запуском",
                s.verifyBeforeLaunch,
                { v -> vm.edit { it.copy(verifyBeforeLaunch = v) } },
                subtitle = "Повреждённые файлы докачиваются сами",
            )
        }

        // ---- appearance
        SectionLabel("Внешний вид")
        Panel(Modifier.fillMaxWidth()) {
            Text("Акцентный цвет", style = MaterialTheme.typography.titleMedium, color = FxText)
            Spacer(Modifier.height(12.dp))
            Row(horizontalArrangement = Arrangement.spacedBy(14.dp)) {
                AccentPresets.forEachIndexed { index, preset ->
                    val selected = index == s.accentIndex
                    Box(
                        Modifier
                            .size(44.dp)
                            .clip(CircleShape)
                            .background(preset.color)
                            .then(if (selected) Modifier.border(3.dp, Color.White, CircleShape) else Modifier)
                            .clickable { vm.edit { it.copy(accentIndex = index) } },
                        contentAlignment = Alignment.Center,
                    ) {
                        if (selected) Icon(painterResource(R.drawable.ic_check), preset.name, Modifier.size(22.dp), tint = Color.White)
                    }
                }
            }
        }

        // ---- about
        SectionLabel("О программе")
        Panel(Modifier.fillMaxWidth()) {
            Text("ForaniyLauncher 0.1.0", style = MaterialTheme.typography.titleMedium, color = FxText)
            Spacer(Modifier.height(6.dp))
            Text(
                "Лаунчер скачивает игру и запускает Java-процесс. Чтобы картинка игры шла на экран телефона, " +
                    "нужен отдельный графический бэкенд (OpenGL-мост). Подробности: docs/ARCHITECTURE.md.",
                style = MaterialTheme.typography.bodySmall,
                color = FxMuted,
            )
        }
        Spacer(Modifier.height(8.dp))
    }

    javaDialog?.let { major ->
        var url by remember(major) { mutableStateOf(s.runtimeUrls[major] ?: "") }
        ForaniyDialog(
            title = "Установить Java $major",
            onDismiss = { javaDialog = null },
            confirmText = "Скачать",
            onConfirm = {
                vm.installJava(major, url)
                javaDialog = null
            },
            confirmEnabled = url.trim().startsWith("https://"),
            dismissText = "Отмена",
        ) {
            Text(
                "Вставьте ссылку на архив .zip или .tar.gz с Android-совместимой Java $major. " +
                    "Ссылка сохранится, чтобы не вводить её снова.",
                style = MaterialTheme.typography.bodyMedium,
                color = FxMuted,
            )
            ForaniyTextField(url, { url = it }, "Ссылка (https://…)", singleLine = false)
            NoticeBox("Лаунчер не содержит готовых ссылок: источник Java выбираете вы.", FxInfo)
        }
    }
}

private fun javaHint(major: Int) = when (major) {
    8 -> "Для Minecraft 1.16.5 и старше"
    17 -> "Для 1.17 – 1.20.4"
    else -> "Для 1.20.5 и новее"
}
