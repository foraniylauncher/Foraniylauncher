package ru.foraniy.launcher.ui.play

import androidx.lifecycle.ViewModel
import ru.foraniy.launcher.AppContainer
import ru.foraniy.launcher.domain.Account
import ru.foraniy.launcher.domain.Build

/** Thin adapter: the real work lives in LaunchService (it must outlive this screen). */
class PlayViewModel(private val c: AppContainer) : ViewModel() {
    val builds = c.builds.state
    val accounts = c.accounts.state
    val settings = c.settings.state
    val launchState = c.launch.state
    val log = c.launch.log

    fun selectBuild(id: String) {
        c.settings.edit { it.copy(selectedBuildId = id) }
    }

    fun play(build: Build, account: Account) {
        c.settings.edit { it.copy(selectedBuildId = build.id, selectedAccountId = account.id) }
        c.launch.start(build.id, account.id)
    }

    fun cancel() = c.launch.cancel()

    fun dismissResult() = c.launch.reset()

    /** Blank clears the auto-join server. The text is validated in the dialog before it gets here. */
    fun setServer(build: Build, text: String) {
        c.builds.update(build.id) { it.copy(serverAddress = text.trim()) }
    }
}
