package ru.foraniy.launcher.catalog

import org.json.JSONArray
import ru.foraniy.launcher.core.Http
import ru.foraniy.launcher.core.Http.enc
import ru.foraniy.launcher.core.mapObjects
import ru.foraniy.launcher.core.str

enum class ContentType(val apiName: String, val folder: String, val label: String) {
    MOD("mod", "mods", "Моды"),
    SHADER("shader", "shaderpacks", "Шейдеры"),
    RESOURCEPACK("resourcepack", "resourcepacks", "Текстуры"),
}

data class ContentProject(
    val id: String,
    val title: String,
    val author: String,
    val description: String,
    val downloads: Long,
    val type: ContentType,
)

data class ContentFile(
    val url: String,
    val fileName: String,
    val sha1: String?,
    val size: Long,
    /** Modrinth project ids of REQUIRED dependencies. */
    val requiredDeps: List<String>,
)

/** Modrinth public API v2 (no key needed; a descriptive User-Agent is required and set by [Http]). */
class ModrinthApi {

    suspend fun search(
        query: String,
        type: ContentType,
        mcVersion: String?,
        loader: String?,
        offset: Int = 0,
    ): List<ContentProject> {
        val facets = JSONArray().put(JSONArray().put("project_type:${type.apiName}"))
        if (mcVersion != null) facets.put(JSONArray().put("versions:$mcVersion"))
        if (type == ContentType.MOD && loader != null) facets.put(JSONArray().put("categories:$loader"))
        val index = if (query.isBlank()) "downloads" else "relevance"
        val url = "$BASE/search?query=${enc(query)}&limit=20&offset=$offset&index=$index&facets=${enc(facets.toString())}"
        val hits = Http.get(url).requireOk().json().getJSONArray("hits")
        return hits.mapObjects {
            ContentProject(
                id = it.getString("project_id"),
                title = it.getString("title"),
                author = it.optString("author"),
                description = it.optString("description"),
                downloads = it.optLong("downloads"),
                type = type,
            )
        }
    }

    /** Newest release version of the project for [mcVersion] (and [loader] for mods), or null if none exists. */
    suspend fun bestFile(projectId: String, mcVersion: String, loader: String?): ContentFile? {
        val sb = StringBuilder("$BASE/project/${enc(projectId)}/version?game_versions=${enc(JSONArray().put(mcVersion).toString())}")
        if (loader != null) sb.append("&loaders=").append(enc(JSONArray().put(loader).toString()))
        val versions = JSONArray(Http.get(sb.toString()).requireOk().body).mapObjects { it }
        val version = versions.firstOrNull { it.optString("version_type") == "release" } ?: versions.firstOrNull() ?: return null

        val files = version.getJSONArray("files").mapObjects { it }
        val file = files.firstOrNull { it.optBoolean("primary") } ?: files.firstOrNull() ?: return null

        val deps = version.optJSONArray("dependencies")?.mapObjects { it }
            ?.filter { it.optString("dependency_type") == "required" && !it.isNull("project_id") }
            ?.map { it.getString("project_id") }
            ?: emptyList()

        return ContentFile(
            url = file.getString("url"),
            fileName = file.getString("filename"),
            sha1 = file.optJSONObject("hashes")?.str("sha1"),
            size = file.optLong("size"),
            requiredDeps = deps,
        )
    }

    private companion object {
        const val BASE = "https://api.modrinth.com/v2"
    }
}
