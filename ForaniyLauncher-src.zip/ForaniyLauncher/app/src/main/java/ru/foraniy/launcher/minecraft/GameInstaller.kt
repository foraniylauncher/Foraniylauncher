package ru.foraniy.launcher.minecraft

import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.async
import kotlinx.coroutines.awaitAll
import kotlinx.coroutines.coroutineScope
import kotlinx.coroutines.sync.Semaphore
import kotlinx.coroutines.sync.withPermit
import kotlinx.coroutines.withContext
import org.json.JSONObject
import ru.foraniy.launcher.core.Hashing
import ru.foraniy.launcher.core.Http
import ru.foraniy.launcher.core.LauncherPaths
import java.io.File
import java.util.concurrent.atomic.AtomicLong

data class InstallProgress(val label: String, val fraction: Float, val bytesPerSecond: Long)

/**
 * Downloads everything a [ResolvedVersion] needs: client jar, libraries, asset index and asset objects.
 * Existing valid files are skipped, so calling this before every launch is cheap and doubles as "repair".
 */
class GameInstaller {

    private class Task(val url: String, val file: File, val sha1: String?, val size: Long)

    suspend fun install(
        version: ResolvedVersion,
        paths: LauncherPaths,
        verify: Boolean,
        onProgress: (InstallProgress) -> Unit,
    ) = withContext(Dispatchers.IO) {
        onProgress(InstallProgress("Проверка файлов…", 0f, 0))

        val all = ArrayList<Task>()
        version.client?.let { all += Task(it.url, paths.versionJar(version.clientJarId), it.sha1, it.size) }
        for (lib in version.libraries) all += Task(lib.url, File(paths.libraries, lib.path), lib.sha1, lib.size)

        version.assetIndex?.let { index ->
            val indexFile = File(paths.assetIndexes, index.id + ".json")
            if (!isValid(indexFile, index.size, index.sha1, verify)) Http.download(index.url, indexFile, index.sha1)
            val objects = JSONObject(indexFile.readText()).getJSONObject("objects")
            for (name in objects.keys()) {
                val o = objects.getJSONObject(name)
                val hash = o.getString("hash")
                all += Task(ASSET_BASE_URL + hash.substring(0, 2) + "/" + hash, paths.assetObject(hash), null, o.optLong("size"))
            }
        }

        val todo = all.distinctBy { it.file.path }.filterNot { isValid(it.file, it.size, it.sha1, verify) }
        if (todo.isEmpty()) {
            onProgress(InstallProgress("Файлы готовы", 1f, 0))
            return@withContext
        }

        val total = todo.sumOf { it.size.coerceAtLeast(1L) }
        val done = AtomicLong(0)
        val lastReportNs = AtomicLong(0)
        val startNs = System.nanoTime()
        val label = "Скачивание файлов (${todo.size})"
        val limit = Semaphore(8)

        coroutineScope {
            todo.map { task ->
                async {
                    limit.withPermit {
                        Http.download(task.url, task.file, task.sha1) { n ->
                            val d = done.addAndGet(n)
                            val now = System.nanoTime()
                            val last = lastReportNs.get()
                            if (now - last > 120_000_000L && lastReportNs.compareAndSet(last, now)) {
                                val seconds = ((now - startNs) / 1e9).coerceAtLeast(0.1)
                                onProgress(InstallProgress(label, (d.toFloat() / total).coerceIn(0f, 1f), (d / seconds).toLong()))
                            }
                        }
                    }
                }
            }.awaitAll()
        }
        onProgress(InstallProgress("Файлы скачаны", 1f, 0))
    }

    /** Size is always checked; SHA-1 only when [verify] is on and a hash is known (assets are size-checked only). */
    private fun isValid(file: File, size: Long, sha1: String?, verify: Boolean): Boolean {
        if (!file.isFile) return false
        if (size > 0 && file.length() != size) return false
        if (verify && sha1 != null && !Hashing.sha1(file).equals(sha1, ignoreCase = true)) return false
        return true
    }

    companion object {
        const val ASSET_BASE_URL = "https://resources.download.minecraft.net/"
    }
}
