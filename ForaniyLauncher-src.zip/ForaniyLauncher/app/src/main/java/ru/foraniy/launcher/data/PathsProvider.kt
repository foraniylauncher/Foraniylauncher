package ru.foraniy.launcher.data

import android.content.Context
import ru.foraniy.launcher.core.LauncherPaths
import java.io.File

/**
 * Resolves the current [LauncherPaths]. Always call [current] when you need a path (do not cache the result):
 * the user can change the game folder in Settings at any time.
 */
class PathsProvider(
    private val context: Context,
    private val settings: SettingsRepository,
) {
    /** App-specific external storage: needs no permission and survives app updates. */
    fun defaultRoot(): File = File(context.getExternalFilesDir(null) ?: context.filesDir, "ForaniyLauncher")

    fun current(): LauncherPaths {
        val override = settings.state.value.gameRootOverride.trim()
        val root = if (override.isNotEmpty()) File(override) else defaultRoot()
        return LauncherPaths(root).also { it.ensureDirs() }
    }
}
