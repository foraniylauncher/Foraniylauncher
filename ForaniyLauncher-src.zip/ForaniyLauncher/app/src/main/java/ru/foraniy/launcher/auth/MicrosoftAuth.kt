package ru.foraniy.launcher.auth

import kotlinx.coroutines.delay
import org.json.JSONArray
import org.json.JSONObject
import ru.foraniy.launcher.core.Http
import ru.foraniy.launcher.core.jsonObjectOf

class AuthException(message: String) : Exception(message)

data class DeviceCode(
    val deviceCode: String,
    val userCode: String,
    val verificationUri: String,
    val expiresInSec: Int,
    val intervalSec: Int,
)

data class MicrosoftLogin(
    val refreshToken: String,
    val mcAccessToken: String,
    val mcExpiresAtMs: Long,
    val name: String,
    /** UUID without dashes. */
    val uuid: String,
)

/**
 * Microsoft -> Xbox Live -> XSTS -> Minecraft Services, using the OAuth2 DEVICE CODE flow:
 * the user opens microsoft.com/link on any device and types a short code, so no WebView, no redirect URI
 * and the launcher never sees the password.
 *
 * [clientId] is YOUR Azure app registration (see README, "Microsoft sign-in").
 */
class MicrosoftAuth(private val clientId: String) {

    val isConfigured: Boolean get() = clientId.isNotBlank()

    suspend fun startDeviceCode(): DeviceCode {
        requireConfigured()
        val r = Http.postForm("$LOGIN/devicecode", mapOf("client_id" to clientId, "scope" to SCOPE))
        val j = r.json()
        if (!r.ok) throw AuthException(j.optString("error_description").ifBlank { "Не удалось начать вход (HTTP ${r.code})" })
        return DeviceCode(
            deviceCode = j.getString("device_code"),
            userCode = j.getString("user_code"),
            verificationUri = j.optString("verification_uri", "https://www.microsoft.com/link"),
            expiresInSec = j.optInt("expires_in", 900),
            intervalSec = j.optInt("interval", 5),
        )
    }

    /** Polls until the user confirms the code. Cancellable. */
    suspend fun awaitSignIn(code: DeviceCode): MicrosoftLogin {
        var interval = code.intervalSec.coerceAtLeast(2)
        val deadline = System.currentTimeMillis() + code.expiresInSec * 1000L
        while (System.currentTimeMillis() < deadline) {
            delay(interval * 1000L)
            val r = Http.postForm(
                "$LOGIN/token",
                mapOf(
                    "grant_type" to "urn:ietf:params:oauth:grant-type:device_code",
                    "client_id" to clientId,
                    "device_code" to code.deviceCode,
                ),
            )
            val j = r.json()
            if (r.ok) return completeLogin(j.getString("access_token"), j.getString("refresh_token"))
            when (j.optString("error")) {
                "authorization_pending" -> Unit
                "slow_down" -> interval += 5
                "authorization_declined" -> throw AuthException("Вход отменён")
                "expired_token" -> throw AuthException("Код истёк. Попробуйте ещё раз")
                else -> throw AuthException(
                    j.optString("error_description").ifBlank { "Ошибка входа: ${j.optString("error")}" },
                )
            }
        }
        throw AuthException("Время ожидания входа истекло")
    }

    suspend fun refresh(refreshToken: String): MicrosoftLogin {
        requireConfigured()
        val r = Http.postForm(
            "$LOGIN/token",
            mapOf(
                "grant_type" to "refresh_token",
                "refresh_token" to refreshToken,
                "client_id" to clientId,
                "scope" to SCOPE,
            ),
        )
        if (!r.ok) throw AuthException("Сессия Microsoft устарела. Войдите в аккаунт заново")
        val j = r.json()
        return completeLogin(j.getString("access_token"), j.optString("refresh_token", refreshToken))
    }

    private suspend fun completeLogin(msAccessToken: String, msRefreshToken: String): MicrosoftLogin {
        // 1) Xbox Live
        val xbl = Http.postJson(
            "https://user.auth.xboxlive.com/user/authenticate",
            jsonObjectOf(
                "Properties" to jsonObjectOf(
                    "AuthMethod" to "RPS",
                    "SiteName" to "user.auth.xboxlive.com",
                    "RpsTicket" to "d=$msAccessToken",
                ),
                "RelyingParty" to "http://auth.xboxlive.com",
                "TokenType" to "JWT",
            ),
        )
        if (!xbl.ok) throw AuthException("Xbox Live отклонил вход (HTTP ${xbl.code})")
        val xblJson = xbl.json()
        val xblToken = xblJson.getString("Token")
        val userHash = xblJson.getJSONObject("DisplayClaims").getJSONArray("xui").getJSONObject(0).getString("uhs")

        // 2) XSTS
        val xsts = Http.postJson(
            "https://xsts.auth.xboxlive.com/xsts/authorize",
            jsonObjectOf(
                "Properties" to jsonObjectOf("SandboxId" to "RETAIL", "UserTokens" to JSONArray().put(xblToken)),
                "RelyingParty" to "rp://api.minecraftservices.com/",
                "TokenType" to "JWT",
            ),
        )
        if (!xsts.ok) throw AuthException(xstsError(xsts.json(), xsts.code))
        val xstsToken = xsts.json().getString("Token")

        // 3) Minecraft services
        val mc = Http.postJson(
            "https://api.minecraftservices.com/authentication/login_with_xbox",
            jsonObjectOf("identityToken" to "XBL3.0 x=$userHash;$xstsToken"),
        )
        if (!mc.ok) {
            throw AuthException(
                if (mc.code == 403) {
                    "Minecraft Services отклонил вход (403). Приложению Azure нужно одобрение Mojang, см. README"
                } else {
                    "Minecraft Services: HTTP ${mc.code}"
                },
            )
        }
        val mcJson = mc.json()
        val mcToken = mcJson.getString("access_token")
        val expiresAt = System.currentTimeMillis() + mcJson.optLong("expires_in", 86_400L) * 1000L

        // 4) Profile (also proves that the account owns Java Edition)
        val profile = Http.get("https://api.minecraftservices.com/minecraft/profile", mapOf("Authorization" to "Bearer $mcToken"))
        if (profile.code == 404) throw AuthException("На этом аккаунте нет Minecraft: Java Edition")
        if (!profile.ok) throw AuthException("Не удалось получить профиль (HTTP ${profile.code})")
        val pj = profile.json()
        return MicrosoftLogin(msRefreshToken, mcToken, expiresAt, pj.getString("name"), pj.getString("id"))
    }

    private fun xstsError(j: JSONObject, httpCode: Int): String = when (j.optLong("XErr")) {
        2148916233L -> "К аккаунту Microsoft не привязан профиль Xbox. Создайте его на xbox.com и повторите"
        2148916235L -> "Xbox Live недоступен в вашей стране"
        2148916236L, 2148916237L -> "Для этого аккаунта нужна проверка возраста на xbox.com"
        2148916238L -> "Детский аккаунт: добавьте его в семью Microsoft и разрешите онлайн-игру"
        else -> "Ошибка Xbox (HTTP $httpCode)"
    }

    private fun requireConfigured() {
        if (!isConfigured) throw AuthException("Вход через Microsoft не настроен: нужен msClientId (см. README)")
    }

    private companion object {
        const val LOGIN = "https://login.microsoftonline.com/consumers/oauth2/v2.0"
        const val SCOPE = "XboxLive.signin offline_access"
    }
}
