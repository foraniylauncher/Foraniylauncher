package ru.foraniy.launcher.ui.accounts

import androidx.compose.animation.AnimatedContent
import androidx.compose.animation.core.tween
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.togetherWith
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.platform.LocalClipboardManager
import androidx.compose.ui.platform.LocalUriHandler
import androidx.compose.ui.text.AnnotatedString
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import ru.foraniy.launcher.AppContainer
import ru.foraniy.launcher.R
import ru.foraniy.launcher.ui.appViewModel
import ru.foraniy.launcher.ui.components.ButtonKind
import ru.foraniy.launcher.ui.components.ForaniyButton
import ru.foraniy.launcher.ui.components.ForaniyChip
import ru.foraniy.launcher.ui.components.ForaniyDialog
import ru.foraniy.launcher.ui.components.ForaniyTextField
import ru.foraniy.launcher.ui.components.NoticeBox
import ru.foraniy.launcher.ui.components.Panel
import ru.foraniy.launcher.ui.theme.ForaniyFonts
import ru.foraniy.launcher.ui.theme.FxDanger
import ru.foraniy.launcher.ui.theme.FxMuted
import ru.foraniy.launcher.ui.theme.FxSoft
import ru.foraniy.launcher.ui.theme.FxSurface2
import ru.foraniy.launcher.ui.theme.FxText
import ru.foraniy.launcher.ui.theme.FxWarning
import ru.foraniy.launcher.ui.theme.LocalAccent

/**
 * The one place where the user picks HOW to sign in:
 *  - Microsoft: official login (works everywhere, needs a Minecraft: Java Edition license);
 *  - Offline: just a nickname. Works in singleplayer and on servers that allow unlicensed players.
 * Used on the Play screen (first run) and on the Accounts screen.
 */
@Composable
fun AuthChoicePanel(
    container: AppContainer,
    modifier: Modifier = Modifier,
    title: String = "Как войти?",
) {
    val vm = appViewModel { AccountsViewModel(container) }
    val ms by vm.ms.collectAsStateWithLifecycle()
    var mode by rememberSaveable { mutableStateOf(AuthMode.MICROSOFT) }

    Panel(modifier.fillMaxWidth()) {
        Text(title, style = MaterialTheme.typography.titleMedium, color = FxText)
        Spacer(Modifier.height(12.dp))
        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            ForaniyChip("Microsoft", mode == AuthMode.MICROSOFT, { mode = AuthMode.MICROSOFT })
            ForaniyChip("Офлайн (по нику)", mode == AuthMode.OFFLINE, { mode = AuthMode.OFFLINE })
        }
        Spacer(Modifier.height(16.dp))
        AnimatedContent(
            targetState = mode,
            transitionSpec = { fadeIn(tween(200)) togetherWith fadeOut(tween(120)) },
            label = "authMode",
        ) { current ->
            if (current == AuthMode.MICROSOFT) {
                MicrosoftOption(configured = vm.microsoftConfigured, onSignIn = vm::startMicrosoft)
            } else {
                OfflineOption(onSubmit = vm::addOffline)
            }
        }
    }

    MicrosoftSignInDialog(
        state = ms,
        onCancel = vm::cancelMicrosoft,
        onRetry = vm::startMicrosoft,
        onDismissError = vm::dismissMicrosoftError,
    )
}

@Composable
private fun MicrosoftOption(configured: Boolean, onSignIn: () -> Unit) {
    Column(verticalArrangement = Arrangement.spacedBy(12.dp)) {
        Text(
            "Официальный вход. Нужна лицензия Minecraft: Java Edition. Подходит для любых серверов, " +
                "в том числе с проверкой лицензии. Пароль лаунчер не видит: код вводится на сайте Microsoft.",
            style = MaterialTheme.typography.bodyMedium,
            color = FxMuted,
        )
        if (!configured) {
            NoticeBox(
                "В этой сборке не указан msClientId, поэтому вход через Microsoft пока не работает " +
                    "(инструкция в README). Офлайн-режим доступен без него.",
                FxWarning,
            )
        }
        ForaniyButton("Войти через Microsoft", onSignIn, Modifier.fillMaxWidth(), icon = R.drawable.ic_user)
    }
}

@Composable
private fun OfflineOption(onSubmit: (String) -> String?) {
    var nick by rememberSaveable { mutableStateOf("") }
    var error by remember { mutableStateOf<String?>(null) }

    Column(verticalArrangement = Arrangement.spacedBy(12.dp)) {
        Text(
            "Играть без входа: достаточно придумать ник. Подходит для одиночной игры и для серверов, " +
                "которые сами разрешают вход без лицензии.",
            style = MaterialTheme.typography.bodyMedium,
            color = FxMuted,
        )
        ForaniyTextField(
            value = nick,
            onValueChange = {
                nick = it.take(16)
                error = null
            },
            label = "Ник",
            isError = error != null,
            supportingText = error ?: "3–16 символов: латиница, цифры, _",
        )
        NoticeBox(
            "Это не обход защиты. Если сервер требует лицензионный аккаунт, с ником он вас не пустит: " +
                "для такого сервера войдите через Microsoft.",
            FxWarning,
        )
        ForaniyButton(
            text = "Продолжить по нику",
            onClick = {
                val result = onSubmit(nick)
                if (result == null) nick = "" else error = result
            },
            modifier = Modifier.fillMaxWidth(),
            icon = R.drawable.ic_play,
        )
    }
}

/** Device-code dialog: "open the page, type this code". Also shows progress and errors. */
@Composable
fun MicrosoftSignInDialog(
    state: MsFlow,
    onCancel: () -> Unit,
    onRetry: () -> Unit,
    onDismissError: () -> Unit,
) {
    val accent = LocalAccent.current
    val uriHandler = LocalUriHandler.current
    val clipboard = LocalClipboardManager.current

    when (state) {
        MsFlow.Idle -> Unit

        MsFlow.Starting -> ForaniyDialog(
            title = "Вход через Microsoft",
            onDismiss = onCancel,
            dismissText = "Отмена",
        ) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                CircularProgressIndicator(Modifier.size(20.dp), color = accent.main, strokeWidth = 2.dp)
                Spacer(Modifier.width(12.dp))
                Text("Получаем код входа…", color = FxSoft)
            }
        }

        is MsFlow.Waiting -> ForaniyDialog(
            title = "Введите код",
            onDismiss = onCancel,
            dismissText = "Отмена",
        ) {
            Text(
                "1. Откройте страницу входа Microsoft на этом или любом другом устройстве.",
                style = MaterialTheme.typography.bodyMedium,
                color = FxMuted,
            )
            ForaniyButton(
                text = "Открыть страницу",
                onClick = { uriHandler.openUri(state.code.verificationUri) },
                modifier = Modifier.fillMaxWidth(),
                icon = R.drawable.ic_external,
            )
            Text("2. Введите этот код:", style = MaterialTheme.typography.bodyMedium, color = FxMuted)
            Box(
                Modifier
                    .fillMaxWidth()
                    .clip(RoundedCornerShape(16.dp))
                    .background(FxSurface2)
                    .clickable { clipboard.setText(AnnotatedString(state.code.userCode)) }
                    .padding(vertical = 18.dp),
                contentAlignment = Alignment.Center,
            ) {
                Text(
                    text = state.code.userCode,
                    fontFamily = ForaniyFonts.mono,
                    fontWeight = FontWeight.ExtraBold,
                    fontSize = 30.sp,
                    letterSpacing = 4.sp,
                    color = accent.glow,
                    textAlign = TextAlign.Center,
                )
            }
            ForaniyButton(
                text = "Скопировать код",
                onClick = { clipboard.setText(AnnotatedString(state.code.userCode)) },
                modifier = Modifier.fillMaxWidth(),
                kind = ButtonKind.Tonal,
                icon = R.drawable.ic_copy,
                height = 48.dp,
            )
            Row(verticalAlignment = Alignment.CenterVertically) {
                CircularProgressIndicator(Modifier.size(18.dp), color = accent.main, strokeWidth = 2.dp)
                Spacer(Modifier.width(10.dp))
                Text("Ждём подтверждения…", style = MaterialTheme.typography.bodyMedium, color = FxMuted)
            }
        }

        is MsFlow.Failed -> ForaniyDialog(
            title = "Не удалось войти",
            onDismiss = onDismissError,
            confirmText = "Повторить",
            onConfirm = onRetry,
        ) {
            Text(state.message, style = MaterialTheme.typography.bodyMedium, color = FxDanger)
        }
    }
}
