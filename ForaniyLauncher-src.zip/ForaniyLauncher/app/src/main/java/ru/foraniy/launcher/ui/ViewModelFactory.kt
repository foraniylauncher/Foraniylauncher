package ru.foraniy.launcher.ui

import androidx.compose.runtime.Composable
import androidx.lifecycle.ViewModel
import androidx.lifecycle.ViewModelProvider
import androidx.lifecycle.viewmodel.compose.viewModel

class SimpleFactory(private val make: () -> ViewModel) : ViewModelProvider.Factory {
    @Suppress("UNCHECKED_CAST")
    override fun <T : ViewModel> create(modelClass: Class<T>): T = make() as T
}

/**
 * ViewModel scoped to the Activity (so it survives screen switches and rotation).
 * Usage:  val vm = appViewModel { PlayViewModel(container) }
 */
@Composable
inline fun <reified VM : ViewModel> appViewModel(noinline make: () -> VM): VM =
    viewModel<VM>(factory = SimpleFactory(make))
