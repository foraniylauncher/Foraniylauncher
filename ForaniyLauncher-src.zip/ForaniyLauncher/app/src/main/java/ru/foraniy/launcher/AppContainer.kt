package ru.foraniy.launcher

import android.app.ActivityManager
import android.content.Context
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob
import ru.foraniy.launcher.auth.AccountManager
import ru.foraniy.launcher.auth.MicrosoftAuth
import ru.foraniy.launcher.catalog.ContentInstaller
import ru.foraniy.launcher.catalog.ModrinthApi
import ru.foraniy.launcher.data.AccountsRepository
import ru.foraniy.launcher.data.BuildsRepository
import ru.foraniy.launcher.data.PathsProvider
import ru.foraniy.launcher.data.SettingsRepository
import ru.foraniy.launcher.minecraft.FabricMeta
import ru.foraniy.launcher.minecraft.GameInstaller
import ru.foraniy.launcher.minecraft.JavaRuntimeManager
import ru.foraniy.launcher.minecraft.LaunchBackend
import ru.foraniy.launcher.minecraft.LaunchService
import ru.foraniy.launcher.minecraft.ProcessLaunchBackend
import ru.foraniy.launcher.minecraft.VersionRepository
import java.io.File

/**
 * Manual dependency container (no DI framework): the single place where every service is wired together.
 * Created once in [App]. UI code receives it and builds its ViewModels from it.
 *
 * To plug in a different way of running the game, change [backend] (see minecraft/LaunchBackend.kt).
 */
class AppContainer(context: Context) {
    private val appContext: Context = context.applicationContext

    /** Lives as long as the process; used by services that must outlive screens (downloads, the game). */
    val appScope: CoroutineScope = CoroutineScope(SupervisorJob() + Dispatchers.Default)

    // data
    val settings = SettingsRepository(File(appContext.filesDir, "settings.json"))
    val accounts = AccountsRepository(File(appContext.filesDir, "accounts.json"))
    val builds = BuildsRepository(File(appContext.filesDir, "builds.json"))
    val paths = PathsProvider(appContext, settings)

    // auth
    val microsoft = MicrosoftAuth(BuildConfig.MS_CLIENT_ID)
    val accountManager = AccountManager(accounts, microsoft)

    // minecraft
    val versions = VersionRepository(paths)
    val fabric = FabricMeta(paths)
    val installer = GameInstaller()
    val javaRuntimes = JavaRuntimeManager(paths, settings)
    val backend: LaunchBackend = ProcessLaunchBackend()
    val launch = LaunchService(
        scope = appScope,
        paths = paths,
        settings = settings,
        builds = builds,
        accounts = accounts,
        accountManager = accountManager,
        versions = versions,
        fabric = fabric,
        installer = installer,
        javaRuntimes = javaRuntimes,
        backend = backend,
    )

    // catalog
    val modrinth = ModrinthApi()
    val content = ContentInstaller(modrinth, paths)

    /** Total device RAM in MB (used to bound the RAM slider). */
    fun deviceMemoryMb(): Int {
        val am = appContext.getSystemService(Context.ACTIVITY_SERVICE) as ActivityManager
        val info = ActivityManager.MemoryInfo()
        am.getMemoryInfo(info)
        return (info.totalMem / (1024L * 1024L)).toInt()
    }
}
