package ru.foraniy.launcher.ui.catalog

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.horizontalScroll
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import ru.foraniy.launcher.AppContainer
import ru.foraniy.launcher.R
import ru.foraniy.launcher.catalog.ContentProject
import ru.foraniy.launcher.catalog.ContentType
import ru.foraniy.launcher.ui.Screen
import ru.foraniy.launcher.ui.appViewModel
import ru.foraniy.launcher.ui.components.ButtonKind
import ru.foraniy.launcher.ui.components.ForaniyButton
import ru.foraniy.launcher.ui.components.ForaniyChip
import ru.foraniy.launcher.ui.components.ForaniyProgressBar
import ru.foraniy.launcher.ui.components.ForaniyTextField
import ru.foraniy.launcher.ui.components.NoticeBox
import ru.foraniy.launcher.ui.components.Panel
import ru.foraniy.launcher.ui.components.ScreenTitle
import ru.foraniy.launcher.ui.formatCount
import ru.foraniy.launcher.ui.theme.FxDanger
import ru.foraniy.launcher.ui.theme.FxInfo
import ru.foraniy.launcher.ui.theme.FxMuted
import ru.foraniy.launcher.ui.theme.FxSoft
import ru.foraniy.launcher.ui.theme.FxText
import ru.foraniy.launcher.ui.theme.LocalAccent

@Composable
fun CatalogScreen(container: AppContainer, onNavigate: (Screen) -> Unit) {
    val vm = appViewModel { CatalogViewModel(container) }
    val ui by vm.ui.collectAsStateWithLifecycle()
    val builds by vm.builds.collectAsStateWithLifecycle()
    val target = builds.firstOrNull { it.id == ui.targetBuildId }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .padding(horizontal = 20.dp, vertical = 12.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp),
    ) {
        ScreenTitle("Каталог", "Моды, шейдеры и текстуры с Modrinth")

        ForaniyTextField(ui.query, vm::setQuery, "Поиск: Sodium, Iris, JourneyMap…")

        Row(Modifier.horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            ContentType.entries.forEach { t -> ForaniyChip(t.label, ui.type == t, { vm.setType(t) }) }
        }

        if (builds.isEmpty()) {
            NoticeBox("Чтобы устанавливать содержимое, сначала создайте сборку.", FxInfo)
            ForaniyButton("К сборкам", { onNavigate(Screen.BUILDS) }, Modifier.fillMaxWidth(), kind = ButtonKind.Tonal, height = 48.dp)
        } else {
            Text("Установить в сборку", style = MaterialTheme.typography.bodySmall, color = FxMuted)
            Row(Modifier.horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                builds.forEach { b -> ForaniyChip(b.name, b.id == ui.targetBuildId, { vm.setTarget(b.id) }) }
            }
            if (target != null) {
                Text(
                    "Показано то, что подходит для Minecraft ${target.mcVersion}" +
                        (target.loader.modrinthName?.let { " и $it" } ?: ""),
                    style = MaterialTheme.typography.bodySmall,
                    color = FxMuted,
                )
            }
        }

        ui.message?.let { NoticeBox(it, FxInfo, onClick = vm::dismissMessage) }

        if (ui.loading) ForaniyProgressBar(null)
        ui.error?.let { NoticeBox(it, FxDanger) }
        if (!ui.loading && ui.error == null && ui.results.isEmpty()) {
            Text("Ничего не найдено", style = MaterialTheme.typography.bodyMedium, color = FxMuted)
        }

        LazyColumn(Modifier.weight(1f), verticalArrangement = Arrangement.spacedBy(10.dp)) {
            items(ui.results, key = { it.id }) { p ->
                ProjectCard(
                    project = p,
                    installing = p.id in ui.installing,
                    installed = p.id in ui.installed,
                    onInstall = { vm.install(p) },
                )
            }
            item { Spacer(Modifier.height(8.dp)) }
        }
    }
}

@Composable
private fun ProjectCard(project: ContentProject, installing: Boolean, installed: Boolean, onInstall: () -> Unit) {
    val accent = LocalAccent.current
    val icon = when (project.type) {
        ContentType.MOD -> R.drawable.ic_mod
        ContentType.SHADER -> R.drawable.ic_shader
        ContentType.RESOURCEPACK -> R.drawable.ic_texture
    }
    Panel(Modifier.fillMaxWidth()) {
        Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(12.dp)) {
            Box(
                Modifier
                    .size(48.dp)
                    .clip(RoundedCornerShape(14.dp))
                    .background(Brush.linearGradient(listOf(accent.glow, accent.deep))),
                contentAlignment = Alignment.Center,
            ) {
                Icon(painterResource(icon), null, Modifier.size(24.dp), tint = Color.White)
            }
            Column(Modifier.weight(1f)) {
                Text(project.title, style = MaterialTheme.typography.titleMedium, color = FxText, maxLines = 1, overflow = TextOverflow.Ellipsis)
                Text(
                    "${project.author} · ${formatCount(project.downloads)} загрузок",
                    style = MaterialTheme.typography.bodySmall,
                    color = FxMuted,
                    maxLines = 1,
                    overflow = TextOverflow.Ellipsis,
                )
            }
        }
        Spacer(Modifier.height(8.dp))
        Text(project.description, style = MaterialTheme.typography.bodyMedium, color = FxSoft, maxLines = 3, overflow = TextOverflow.Ellipsis)
        Spacer(Modifier.height(12.dp))
        ForaniyButton(
            text = when {
                installing -> "Устанавливаем…"
                installed -> "Установлено"
                else -> "Установить"
            },
            onClick = onInstall,
            modifier = Modifier.fillMaxWidth(),
            kind = ButtonKind.Tonal,
            icon = if (installed) R.drawable.ic_check else R.drawable.ic_download,
            enabled = !installing && !installed,
            height = 48.dp,
        )
    }
}
