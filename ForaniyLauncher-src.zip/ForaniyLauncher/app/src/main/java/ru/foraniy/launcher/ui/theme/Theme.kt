package ru.foraniy.launcher.ui.theme

import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.runtime.CompositionLocalProvider
import androidx.compose.runtime.remember
import androidx.compose.ui.graphics.Color

/** The launcher is dark-only by design. [accentIndex] indexes [AccentPresets]. */
@Composable
fun ForaniyTheme(accentIndex: Int, content: @Composable () -> Unit) {
    val accent = remember(accentIndex) {
        AccentColors.from((AccentPresets.getOrNull(accentIndex) ?: AccentPresets[0]).color)
    }
    val scheme = darkColorScheme(
        primary = accent.main,
        onPrimary = Color.White,
        primaryContainer = FxSurface3,
        onPrimaryContainer = FxSoft,
        secondary = accent.glow,
        onSecondary = Color.White,
        background = FxBg,
        onBackground = FxText,
        surface = FxSurface,
        onSurface = FxText,
        surfaceVariant = FxSurface2,
        onSurfaceVariant = FxMuted,
        outline = FxOutlineStrong,
        outlineVariant = FxOutline,
        error = FxDanger,
    )
    CompositionLocalProvider(LocalAccent provides accent) {
        MaterialTheme(
            colorScheme = scheme,
            typography = ForaniyTypography,
            shapes = ForaniyShapes,
            content = content,
        )
    }
}
