package ru.foraniy.launcher.minecraft

import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.currentCoroutineContext
import kotlinx.coroutines.withContext
import ru.foraniy.launcher.core.LauncherException
import java.io.File
import java.io.IOException

data class LaunchSpec(
    val command: List<String>,
    val workDir: File,
    val environment: Map<String, String> = emptyMap(),
)

/**
 * The ONE seam between "what to run" (command line built by [LaunchCommandBuilder]) and "how to run it on Android".
 *
 * Minecraft needs a JVM, LWJGL and an OpenGL surface. Android has none of them out of the box, so a real
 * on-device runner (a JVM loaded in-process plus a GLFW/OpenGL bridge) belongs in its own [LaunchBackend]
 * implementation. Everything else in the launcher (versions, downloads, accounts, UI) is independent of it.
 */
interface LaunchBackend {
    val title: String

    /** Runs the game, streams its output lines to [onLine], returns the exit code. Must stop when cancelled. */
    suspend fun run(spec: LaunchSpec, onLine: (String) -> Unit): Int
}

/**
 * Default backend: starts `java` as a child process. Works with a Java binary that Android allows to execute.
 * It does NOT provide a display, so the game window cannot appear without a bridge: see [LaunchBackend].
 */
class ProcessLaunchBackend : LaunchBackend {
    override val title = "Java-процесс"

    override suspend fun run(spec: LaunchSpec, onLine: (String) -> Unit): Int = withContext(Dispatchers.IO) {
        val builder = ProcessBuilder(spec.command)
            .directory(spec.workDir)
            .redirectErrorStream(true)
        builder.environment().putAll(spec.environment)

        val process = try {
            builder.start()
        } catch (e: IOException) {
            throw LauncherException("Не удалось запустить Java: ${e.message}", cause = e)
        }

        // Cancelling the coroutine kills the process, which also ends the blocking read below.
        val handle = currentCoroutineContext()[Job]?.invokeOnCompletion {
            if (process.isAlive) process.destroyForcibly()
        }
        try {
            process.inputStream.bufferedReader().useLines { lines -> lines.forEach(onLine) }
            process.waitFor()
        } finally {
            handle?.dispose()
            if (process.isAlive) process.destroyForcibly()
        }
    }
}
