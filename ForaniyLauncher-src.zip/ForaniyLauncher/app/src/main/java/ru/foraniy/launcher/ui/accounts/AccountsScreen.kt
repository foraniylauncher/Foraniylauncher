package ru.foraniy.launcher.ui.accounts

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import ru.foraniy.launcher.AppContainer
import ru.foraniy.launcher.R
import ru.foraniy.launcher.domain.Account
import ru.foraniy.launcher.domain.AccountType
import ru.foraniy.launcher.ui.Screen
import ru.foraniy.launcher.ui.appViewModel
import ru.foraniy.launcher.ui.components.Avatar
import ru.foraniy.launcher.ui.components.ForaniyDialog
import ru.foraniy.launcher.ui.components.HintText
import ru.foraniy.launcher.ui.components.Panel
import ru.foraniy.launcher.ui.components.ScreenTitle
import ru.foraniy.launcher.ui.components.SectionLabel
import ru.foraniy.launcher.ui.components.SmallIconButton
import ru.foraniy.launcher.ui.components.StatusPill
import ru.foraniy.launcher.ui.theme.FxMuted
import ru.foraniy.launcher.ui.theme.FxSuccess
import ru.foraniy.launcher.ui.theme.FxText
import ru.foraniy.launcher.ui.theme.FxWarning
import ru.foraniy.launcher.ui.theme.LocalAccent

@Composable
fun AccountsScreen(container: AppContainer, onNavigate: (Screen) -> Unit) {
    val vm = appViewModel { AccountsViewModel(container) }
    val accounts by vm.accounts.collectAsStateWithLifecycle()
    val settings by vm.settings.collectAsStateWithLifecycle()
    val selectedId = settings.selectedAccountId ?: accounts.firstOrNull()?.id
    var toDelete by remember { mutableStateOf<Account?>(null) }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .verticalScroll(rememberScrollState())
            .padding(horizontal = 20.dp, vertical = 12.dp),
        verticalArrangement = Arrangement.spacedBy(14.dp),
    ) {
        ScreenTitle("Аккаунты", "Официальный вход или игра по нику")

        if (accounts.isNotEmpty()) {
            SectionLabel("Ваши аккаунты")
            accounts.forEach { account ->
                AccountCard(
                    account = account,
                    selected = account.id == selectedId,
                    onSelect = { vm.select(account.id) },
                    onDelete = { toDelete = account },
                )
            }
        }

        SectionLabel(if (accounts.isEmpty()) "Вход" else "Добавить аккаунт")
        AuthChoicePanel(container, title = "Способ входа")
        Spacer(Modifier.height(8.dp))
    }

    toDelete?.let { account ->
        ForaniyDialog(
            title = "Удалить аккаунт?",
            onDismiss = { toDelete = null },
            confirmText = "Удалить",
            onConfirm = {
                vm.remove(account)
                toDelete = null
            },
            dismissText = "Отмена",
        ) {
            Text(
                if (account.type == AccountType.MICROSOFT) {
                    "Аккаунт «${account.name}» будет удалён из лаунчера. Сам аккаунт Microsoft не затрагивается."
                } else {
                    "Офлайн-ник «${account.name}» будет удалён из лаунчера."
                },
                style = MaterialTheme.typography.bodyMedium,
                color = FxMuted,
            )
        }
    }
}

@Composable
private fun AccountCard(account: Account, selected: Boolean, onSelect: () -> Unit, onDelete: () -> Unit) {
    val accent = LocalAccent.current
    Panel(Modifier.fillMaxWidth(), onClick = onSelect, selected = selected) {
        Row(
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.spacedBy(12.dp),
        ) {
            Avatar(account.name)
            Column(Modifier.weight(1f)) {
                Text(
                    account.name,
                    style = MaterialTheme.typography.titleMedium,
                    color = FxText,
                    maxLines = 1,
                    overflow = TextOverflow.Ellipsis,
                )
                Spacer(Modifier.height(4.dp))
                Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                    if (account.type == AccountType.MICROSOFT) {
                        StatusPill("Microsoft", FxSuccess)
                    } else {
                        StatusPill("Офлайн", FxWarning)
                    }
                    if (selected) StatusPill("Выбран", accent.glow)
                }
            }
            SmallIconButton(R.drawable.ic_trash, "Удалить аккаунт", onDelete, tint = FxMuted)
        }
        if (account.type == AccountType.OFFLINE) {
            HintText("Одиночная игра и серверы без лицензионной проверки.")
        }
    }
}
