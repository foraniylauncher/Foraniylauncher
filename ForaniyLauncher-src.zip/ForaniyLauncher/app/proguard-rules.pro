# Release minification is off by default (see app/build.gradle.kts).
# The project uses org.json + HttpURLConnection only, so no reflection-based libraries need keep rules.
