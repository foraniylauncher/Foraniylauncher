#!/usr/bin/env python3
"""Generates design SVG assets for ForaniyLauncher (backgrounds + UI kit boards).

Run:  python3 tools/generate_design.py
Outputs (all under design/):
  backgrounds/bg-nebula-portrait.svg    1080x2400 phone portrait
  backgrounds/bg-nebula-landscape.svg   2400x1080 phone/tablet landscape
  backgrounds/bg-grid-glow.svg          1080x1080 tileable-ish technical grid
  ui-kit/buttons-and-controls.svg       buttons, chips, slider, toggles, progress, touch targets
  ui-kit/panels.svg                     version picker / catalog / settings panels
Colors come from design/tokens.json (mirrored in ui/theme/Color.kt).
"""
import random
from pathlib import Path
from xml.sax.saxutils import escape

from generate_icons import ICONS

ROOT = Path(__file__).resolve().parent.parent
OUT = ROOT / "design"
FONT = "Inter, 'Segoe UI', Roboto, sans-serif"

C = {
    "bg": "#0B0714", "surface": "#130D21", "surface2": "#1B1230", "surface3": "#241A3D",
    "outline": "#2A1F45", "outline_strong": "#3B2D63",
    "primary": "#A855F7", "glow": "#C084FC", "deep": "#7C3AED", "soft": "#E9D5FF",
    "text": "#F3EEFF", "muted": "#9A8FB8", "faint": "#6B6188",
    "success": "#4ADE80", "warning": "#FBBF24", "danger": "#FB7185", "info": "#60A5FA",
}


def write(rel: str, content: str) -> None:
    p = OUT / rel
    p.parent.mkdir(parents=True, exist_ok=True)
    p.write_text(content, encoding="utf-8")


# ---------------------------------------------------------------- backgrounds
def stars(w, h, n, seed):
    rng = random.Random(seed)
    out = []
    for _ in range(n):
        x, y = rng.uniform(0, w), rng.uniform(0, h)
        r = rng.choice([0.8, 1.0, 1.2, 1.6, 2.2])
        o = rng.uniform(0.12, 0.65)
        out.append(f'<circle cx="{x:.0f}" cy="{y:.0f}" r="{r}" fill="{C["soft"]}" opacity="{o:.2f}"/>')
    return "\n".join(out)


def nebula(w, h, seed, blobs):
    grads, rects = [], []
    for i, (cx, cy, r, color, a) in enumerate(blobs):
        grads.append(
            f'<radialGradient id="b{i}" cx="{cx}" cy="{cy}" r="{r}">'
            f'<stop offset="0" stop-color="{color}" stop-opacity="{a}"/>'
            f'<stop offset="1" stop-color="{color}" stop-opacity="0"/></radialGradient>'
        )
        rects.append(f'<rect width="{w}" height="{h}" fill="url(#b{i})"/>')
    return (
        f'<svg xmlns="http://www.w3.org/2000/svg" width="{w}" height="{h}" viewBox="0 0 {w} {h}">\n'
        f'<defs><linearGradient id="base" x1="0" y1="0" x2="0" y2="1">'
        f'<stop offset="0" stop-color="#120A24"/><stop offset="1" stop-color="#07040F"/></linearGradient>\n'
        + "\n".join(grads)
        + f'</defs>\n<rect width="{w}" height="{h}" fill="url(#base)"/>\n'
        + "\n".join(rects)
        + "\n"
        + stars(w, h, 70, seed)
        + "\n</svg>\n"
    )


def grid_glow(s=1080):
    return (
        f'<svg xmlns="http://www.w3.org/2000/svg" width="{s}" height="{s}" viewBox="0 0 {s} {s}">\n'
        f'<defs><pattern id="g" width="60" height="60" patternUnits="userSpaceOnUse">'
        f'<path d="M60 0H0V60" fill="none" stroke="{C["primary"]}" stroke-opacity="0.10"/></pattern>\n'
        f'<radialGradient id="fade" cx="0.5" cy="0.38" r="0.65">'
        f'<stop offset="0" stop-color="{C["primary"]}" stop-opacity="0.28"/>'
        f'<stop offset="1" stop-color="{C["bg"]}" stop-opacity="1"/></radialGradient></defs>\n'
        f'<rect width="{s}" height="{s}" fill="{C["bg"]}"/>\n'
        f'<rect width="{s}" height="{s}" fill="url(#fade)"/>\n'
        f'<rect width="{s}" height="{s}" fill="url(#g)"/>\n</svg>\n'
    )


# ---------------------------------------------------------------- ui-kit helpers
def rect(x, y, w, h, r=16, fill="none", stroke=None, sw=1, extra=""):
    s = f'<rect x="{x}" y="{y}" width="{w}" height="{h}" rx="{r}" fill="{fill}"'
    if stroke:
        s += f' stroke="{stroke}" stroke-width="{sw}"'
    return s + (f" {extra}" if extra else "") + "/>"


def text(x, y, t, size=14, fill=None, weight=400, anchor="start", mono=False):
    fam = "monospace" if mono else FONT
    return (
        f'<text x="{x}" y="{y}" fill="{fill or C["text"]}" font-family="{fam}" font-size="{size}" '
        f'font-weight="{weight}" text-anchor="{anchor}">{escape(t)}</text>'
    )


def icon(name, x, y, size=24, color=None):
    color = color or C["glow"]
    return (
        f'<g transform="translate({x},{y}) scale({size / 24:.3f})" fill="none" stroke="{color}" '
        f'stroke-width="1.75" stroke-linecap="round" stroke-linejoin="round"><path d="{ICONS[name]}"/></g>'
    )


def kit_defs():
    return (
        '<defs>'
        f'<linearGradient id="btn" x1="0" y1="0" x2="1" y2="1"><stop offset="0" stop-color="#B06CF8"/>'
        f'<stop offset="1" stop-color="{C["deep"]}"/></linearGradient>'
        f'<linearGradient id="prog" x1="0" y1="0" x2="1" y2="0"><stop offset="0" stop-color="{C["deep"]}"/>'
        f'<stop offset="1" stop-color="{C["glow"]}"/></linearGradient>'
        '<filter id="blur" x="-30%" y="-60%" width="160%" height="220%"><feGaussianBlur stdDeviation="9"/></filter>'
        '</defs>'
    )


def button(x, y, w, h, label, kind="primary", icon_name=None):
    parts = []
    tc = "#FFFFFF"
    if kind == "primary":
        parts.append(rect(x, y + 6, w, h, 16, C["primary"], extra='opacity="0.45" filter="url(#blur)"'))
        parts.append(rect(x, y, w, h, 16, "url(#btn)"))
    elif kind == "pressed":
        parts.append(rect(x, y, w, h, 16, "#6D28D9"))
    elif kind == "disabled":
        parts.append(rect(x, y, w, h, 16, C["surface3"]))
        tc = C["faint"]
    elif kind == "secondary":
        parts.append(rect(x, y, w, h, 16, "none", C["outline_strong"], 1.5))
        tc = C["soft"]
    elif kind == "tonal":
        parts.append(rect(x, y, w, h, 16, C["surface3"]))
        tc = C["soft"]
    elif kind == "danger":
        parts.append(rect(x, y, w, h, 16, "none", C["danger"], 1.5))
        tc = C["danger"]
    cx = x + w / 2
    if icon_name:
        parts.append(icon(icon_name, cx - 56, y + h / 2 - 11, 22, tc))
        parts.append(text(cx - 26, y + h / 2 + 6, label, 17, tc, 700))
    else:
        parts.append(text(cx, y + h / 2 + 6, label, 17, tc, 700, "middle"))
    return "\n".join(parts)


def chip(x, y, label, selected=False):
    w = 24 + len(label) * 9
    if selected:
        return rect(x, y, w, 36, 18, "#3B1D6B", C["primary"], 1.2) + text(x + w / 2, y + 23, label, 14, C["soft"], 600, "middle")
    return rect(x, y, w, 36, 18, C["surface2"], C["outline"], 1) + text(x + w / 2, y + 23, label, 14, C["muted"], 500, "middle")


def toggle(x, y, on):
    if on:
        return rect(x, y, 52, 30, 15, "url(#btn)") + f'<circle cx="{x + 37}" cy="{y + 15}" r="11" fill="#FFFFFF"/>'
    return rect(x, y, 52, 30, 15, C["surface3"], C["outline_strong"], 1) + f'<circle cx="{x + 15}" cy="{y + 15}" r="11" fill="{C["muted"]}"/>'


def slider(x, y, w, frac):
    kx = x + w * frac
    return (
        rect(x, y - 3, w, 6, 3, C["surface3"])
        + rect(x, y - 3, w * frac, 6, 3, "url(#prog)")
        + f'<circle cx="{kx:.0f}" cy="{y}" r="16" fill="{C["primary"]}" opacity="0.30"/>'
        + f'<circle cx="{kx:.0f}" cy="{y}" r="10" fill="#FFFFFF" stroke="{C["primary"]}" stroke-width="3"/>'
    )


def progress(x, y, w, frac):
    return (
        rect(x, y, w, 10, 5, C["surface3"])
        + rect(x, y - 2, w * frac, 14, 7, C["primary"], extra='opacity="0.35" filter="url(#blur)"')
        + rect(x, y, w * frac, 10, 5, "url(#prog)")
    )


def card(x, y, w, h, r=20, fill=None):
    return rect(x, y, w, h, r, fill or C["surface"], C["outline"], 1)


# ---------------------------------------------------------------- boards
def buttons_board():
    W, H = 1200, 940
    o = [f'<svg xmlns="http://www.w3.org/2000/svg" width="{W}" height="{H}" viewBox="0 0 {W} {H}">', kit_defs(),
         rect(0, 0, W, H, 0, C["bg"])]
    o.append(text(48, 70, "ForaniyLauncher / Buttons & controls", 28, C["text"], 800))
    o.append(text(48, 98, "Touch first: min target 48dp, primary action 56dp, radius 16, glow only on the single main action.", 14, C["muted"]))

    o.append(text(48, 150, "PRIMARY", 12, C["faint"], 700))
    o.append(button(48, 166, 320, 56, "Играть", "primary", "play"))
    o.append(button(400, 166, 320, 56, "Играть", "pressed", "play"))
    o.append(button(752, 166, 320, 56, "Играть", "disabled", "play"))
    o.append(text(48, 252, "default", 12, C["muted"], mono=True))
    o.append(text(400, 252, "pressed", 12, C["muted"], mono=True))
    o.append(text(752, 252, "disabled", 12, C["muted"], mono=True))

    o.append(text(48, 306, "SECONDARY", 12, C["faint"], 700))
    o.append(button(48, 322, 250, 52, "Создать сборку", "secondary"))
    o.append(button(318, 322, 250, 52, "Скачать", "tonal", "download"))
    o.append(button(588, 322, 250, 52, "Удалить", "danger", "trash"))

    o.append(text(48, 430, "ICON BUTTONS  (48dp)", 12, C["faint"], 700))
    for i, (name, hot) in enumerate([("play", True), ("settings", False), ("refresh", False), ("trash", False), ("folder", False)]):
        cx = 48 + 24 + i * 72
        if hot:
            o.append(f'<circle cx="{cx}" cy="486" r="30" fill="{C["primary"]}" opacity="0.4" filter="url(#blur)"/>')
            o.append(f'<circle cx="{cx}" cy="480" r="24" fill="url(#btn)"/>')
            o.append(icon(name, cx - 11, 469, 22, "#FFFFFF"))
        else:
            o.append(f'<circle cx="{cx}" cy="480" r="24" fill="{C["surface2"]}" stroke="{C["outline"]}"/>')
            o.append(icon(name, cx - 11, 469, 22, C["soft"]))

    o.append(text(48, 560, "CHIPS", 12, C["faint"], 700))
    o.append(chip(48, 576, "Release", True))
    o.append(chip(170, 576, "Snapshot"))
    o.append(chip(298, 576, "Fabric", True))
    o.append(chip(396, 576, "Vanilla"))

    o.append(text(48, 664, "PROGRESS", 12, C["faint"], 700))
    o.append(progress(48, 684, 520, 0.62))
    o.append(text(48, 722, "Скачивание библиотек  62%   ·   18.4 МБ/с", 13, C["muted"]))

    o.append(text(640, 664, "SLIDER / TOGGLES", 12, C["faint"], 700))
    o.append(slider(652, 692, 320, 0.5))
    o.append(toggle(652, 724, True))
    o.append(toggle(724, 724, False))

    o.append(text(48, 800, "TOUCH TARGET", 12, C["faint"], 700))
    o.append(rect(48, 816, 48, 48, 12, "none", C["primary"], 1.5, 'stroke-dasharray="5 4"'))
    o.append(icon("settings", 60, 828, 24, C["soft"]))
    o.append(text(112, 846, "48 x 48dp minimum. Visual icon 24dp, padding 12dp. Gap between targets: 8dp or more.", 14, C["muted"]))
    o.append("</svg>\n")
    return "\n".join(o)


def panels_board():
    W, H = 1200, 1180
    o = [f'<svg xmlns="http://www.w3.org/2000/svg" width="{W}" height="{H}" viewBox="0 0 {W} {H}">', kit_defs(),
         rect(0, 0, W, H, 0, C["bg"])]
    o.append(text(36, 56, "ForaniyLauncher / Panels", 28, C["text"], 800))
    px, pw, ph, py = [36, 420, 804], 360, 1040, 100

    # --- panel 1: version picker
    x = px[0]
    o.append(card(x, py, pw, ph, 28))
    o.append(text(x + 24, py + 48, "Выбор версии", 20, C["text"], 800))
    o.append(rect(x + 24, py + 68, pw - 48, 48, 14, C["surface2"], C["outline"], 1))
    o.append(icon("search", x + 38, py + 80, 24, C["muted"]))
    o.append(text(x + 74, py + 98, "Поиск версии", 15, C["faint"]))
    o.append(chip(x + 24, py + 132, "Релизы", True))
    o.append(chip(x + 124, py + 132, "Снапшоты"))
    o.append(chip(x + 232, py + 132, "Старые"))
    rows = [("1.21.4", "Release", "installed", True), ("1.21.3", "Release", "installed", False),
            ("1.20.6", "Release", "download", False), ("1.20.1", "Release", "installed", False),
            ("24w46a", "Snapshot", "download", False), ("1.19.4", "Release", "download", False),
            ("1.18.2", "Release", "download", False), ("1.16.5", "Release", "installed", False),
            ("1.12.2", "Release", "download", False), ("1.8.9", "Release", "download", False)]
    for i, (v, t, st, sel) in enumerate(rows):
        ry = py + 188 + i * 68
        if sel:
            o.append(rect(x + 16, ry, pw - 32, 58, 16, "#2B1650", C["primary"], 1.2))
        else:
            o.append(rect(x + 16, ry, pw - 32, 58, 16, "none"))
        o.append(text(x + 36, ry + 26, v, 17, C["text"], 700))
        o.append(text(x + 36, ry + 46, t, 12, C["muted"]))
        if st == "installed":
            o.append(icon("check", x + pw - 60, ry + 17, 24, C["success"]))
        else:
            o.append(icon("download", x + pw - 60, ry + 17, 24, C["muted"]))

    # --- panel 2: catalog
    x = px[1]
    o.append(card(x, py, pw, ph, 28))
    o.append(text(x + 24, py + 48, "Каталог", 20, C["text"], 800))
    o.append(rect(x + 24, py + 68, pw - 48, 48, 14, C["surface2"], C["outline"], 1))
    o.append(icon("search", x + 38, py + 80, 24, C["muted"]))
    o.append(text(x + 74, py + 98, "Sodium, Iris, JourneyMap...", 15, C["faint"]))
    o.append(chip(x + 24, py + 132, "Моды", True))
    o.append(chip(x + 104, py + 132, "Шейдеры"))
    o.append(chip(x + 206, py + 132, "Текстуры"))
    cards = [("Sodium", "jellysquid3  ·  48 млн", "Современный движок отрисовки, FPS x2", "mod"),
             ("Iris Shaders", "coderbot  ·  29 млн", "Поддержка шейдеров для Fabric", "shader"),
             ("Fabric API", "modmuss50  ·  120 млн", "Базовая библиотека для модов", "mod"),
             ("Faithful 32x", "Faithful Team  ·  8 млн", "Чуть чётче ванильных текстур", "texture")]
    for i, (n, a, d, ic) in enumerate(cards):
        cy = py + 188 + i * 208
        o.append(rect(x + 16, cy, pw - 32, 192, 20, C["surface2"], C["outline"], 1))
        o.append(rect(x + 32, cy + 16, 56, 56, 16, "url(#btn)"))
        o.append(icon(ic, x + 48, cy + 32, 24, "#FFFFFF"))
        o.append(text(x + 104, cy + 40, n, 17, C["text"], 700))
        o.append(text(x + 104, cy + 62, a, 12, C["muted"]))
        o.append(text(x + 32, cy + 104, d, 14, C["soft"]))
        o.append(button(x + 32, cy + 128, pw - 64, 44, "Установить", "tonal", "download"))

    # --- panel 3: settings
    x = px[2]
    o.append(card(x, py, pw, ph, 28))
    o.append(text(x + 24, py + 48, "Настройки", 20, C["text"], 800))
    o.append(text(x + 24, py + 96, "ПАМЯТЬ", 12, C["faint"], 700))
    o.append(rect(x + 16, py + 108, pw - 32, 108, 20, C["surface2"], C["outline"], 1))
    o.append(icon("memory", x + 34, py + 124, 24, C["glow"]))
    o.append(text(x + 70, py + 142, "Выделено ОЗУ", 15, C["text"], 600))
    o.append(text(x + pw - 32, py + 142, "4096 МБ", 15, C["glow"], 700, "end"))
    o.append(slider(x + 36, py + 186, pw - 72, 0.5))
    o.append(text(x + 24, py + 252, "JAVA", 12, C["faint"], 700))
    o.append(rect(x + 16, py + 264, pw - 32, 128, 20, C["surface2"], C["outline"], 1))
    o.append(icon("java", x + 34, py + 282, 24, C["glow"]))
    o.append(text(x + 70, py + 300, "Среда выполнения", 15, C["text"], 600))
    o.append(text(x + 70, py + 322, "Авто · Java 21 · установлена", 13, C["muted"]))
    o.append(button(x + 32, py + 340, pw - 64, 36, "Сменить или установить", "tonal"))
    o.append(text(x + 24, py + 428, "ПАПКА ИГРЫ", 12, C["faint"], 700))
    o.append(rect(x + 16, py + 440, pw - 32, 88, 20, C["surface2"], C["outline"], 1))
    o.append(icon("folder", x + 34, py + 458, 24, C["glow"]))
    o.append(text(x + 70, py + 476, "Расположение", 15, C["text"], 600))
    o.append(text(x + 70, py + 500, ".../files/ForaniyLauncher", 13, C["muted"], mono=True))
    o.append(text(x + 24, py + 566, "ОБЩЕЕ", 12, C["faint"], 700))
    o.append(rect(x + 16, py + 578, pw - 32, 208, 20, C["surface2"], C["outline"], 1))
    for i, (lbl, on) in enumerate([("Показывать снапшоты", False), ("Старые версии (alpha/beta)", False), ("Проверять файлы", True)]):
        ry = py + 578 + 20 + i * 62
        o.append(text(x + 34, ry + 26, lbl, 14, C["text"], 500))
        o.append(toggle(x + pw - 84, ry + 4, on))
    o.append(button(x + 16, py + ph - 76, pw - 32, 56, "Автосохранение", "disabled", "check"))

    o.append("</svg>\n")
    return "\n".join(o)


def main():
    write("backgrounds/bg-nebula-portrait.svg", nebula(1080, 2400, 7, [
        (0.15, 0.10, 0.45, "#6D28D9", 0.40), (0.90, 0.55, 0.40, "#A855F7", 0.22), (0.25, 0.97, 0.50, "#4C1D95", 0.45)]))
    write("backgrounds/bg-nebula-landscape.svg", nebula(2400, 1080, 11, [
        (0.12, 0.20, 0.40, "#6D28D9", 0.40), (0.80, 0.30, 0.35, "#A855F7", 0.20), (0.55, 1.00, 0.45, "#4C1D95", 0.45)]))
    write("backgrounds/bg-grid-glow.svg", grid_glow())
    write("ui-kit/buttons-and-controls.svg", buttons_board())
    write("ui-kit/panels.svg", panels_board())
    print("design assets generated in", OUT)


if __name__ == "__main__":
    main()
